// app/page.tsx
// Ini adalah halaman utama yang akan menjadi aplikasi CRUD Catatan Anda.
// Saya mengganti konten file ini sepenuhnya.

"use client";

import { useState, useEffect, FormEvent } from 'react';

// Tipe data untuk Catatan
interface Note {
  id: number;
  title: string;
  content: string | null;
  createdAt: string;
}

export default function Home() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // State untuk form
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  
  // State untuk mode edit
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);

  // Fungsi untuk mengambil semua catatan
  const fetchNotes = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/notes');
      const data: Note[] = await res.json();
      setNotes(data);
    } catch (error) {
      console.error('Gagal mengambil catatan:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Mengambil catatan saat komponen di-mount
  useEffect(() => {
    fetchNotes();
  }, []);

  // Reset form
  const resetForm = () => {
    setTitle('');
    setContent('');
    setEditingNoteId(null);
  };

  // Handle submit form (Create & Update)
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    const noteData = { title, content };

    try {
      let response;
      if (editingNoteId) {
        // Mode Edit (UPDATE)
        response = await fetch(`/api/notes/${editingNoteId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(noteData),
        });
      } else {
        // Mode Create (CREATE)
        response = await fetch('/api/notes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(noteData),
        });
      }

      if (!response.ok) {
        throw new Error('Gagal menyimpan catatan');
      }

      resetForm();
      fetchNotes(); // Ambil ulang data terbaru
      
    } catch (error) {
      console.error(error);
    }
  };

  // Handle Delete
  const handleDelete = async (id: number) => {
    if (confirm('Apakah Anda yakin ingin menghapus catatan ini?')) {
      try {
        const response = await fetch(`/api/notes/${id}`, {
          method: 'DELETE',
        });

        if (!response.ok) {
          throw new Error('Gagal menghapus catatan');
        }
        
        fetchNotes(); // Ambil ulang data terbaru
      } catch (error) {
        console.error(error);
      }
    }
  };

  // Handle Edit (mengisi form dengan data yang ada)
  const handleEdit = (note: Note) => {
    setEditingNoteId(note.id);
    setTitle(note.title);
    setContent(note.content || '');
  };

  return (
    <main className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Aplikasi Catatan Saya</h1>
      
      {/* Form untuk Create / Edit */}
      <form onSubmit={handleSubmit} className="mb-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-semibold mb-4">
          {editingNoteId ? 'Edit Catatan' : 'Tambah Catatan Baru'}
        </h2>
        <div className="mb-4">
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            Judul
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>
        <div className="mb-4">
          <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
            Isi (Opsional)
          </label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <div className="flex items-center gap-4">
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            {editingNoteId ? 'Simpan Perubahan' : 'Simpan Catatan'}
          </button>
          {editingNoteId && (
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400"
            >
              Batal
            </button>
          )}
        </div>
      </form>

      {/* Daftar Catatan */}
      <h2 className="text-2xl font-semibold mb-4">Daftar Catatan</h2>
      {isLoading ? (
        <p>Memuat catatan...</p>
      ) : (
        <div className="space-y-4">
          {notes.length > 0 ? (
            notes.map((note) => (
              <div key={note.id} className="p-6 bg-white rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-2">{note.title}</h3>
                <p className="text-gray-700 mb-4 whitespace-pre-wrap">{note.content}</p>
                <small className="text-gray-500">
                  Dibuat: {new Date(note.createdAt).toLocaleString()}
                </small>
                <div className="mt-4 flex gap-4">
                  <button
                    onClick={() => handleEdit(note)}
                    className="px-3 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 text-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(note.id)}
                    className="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p>Belum ada catatan. Silakan tambahkan satu!</p>
          )}
        </div>
      )}
    </main>
  );
}