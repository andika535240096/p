(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/ /* global define */ (function() {
    'use strict';
    var hasOwn = {}.hasOwnProperty;
    function classNames() {
        var classes = '';
        for(var i = 0; i < arguments.length; i++){
            var arg = arguments[i];
            if (arg) {
                classes = appendClass(classes, parseValue(arg));
            }
        }
        return classes;
    }
    function parseValue(arg) {
        if (typeof arg === 'string' || typeof arg === 'number') {
            return arg;
        }
        if (typeof arg !== 'object') {
            return '';
        }
        if (Array.isArray(arg)) {
            return classNames.apply(null, arg);
        }
        if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes('[native code]')) {
            return arg.toString();
        }
        var classes = '';
        for(var key in arg){
            if (hasOwn.call(arg, key) && arg[key]) {
                classes = appendClass(classes, key);
            }
        }
        return classes;
    }
    function appendClass(value, newClass) {
        if (!newClass) {
            return value;
        }
        if (value) {
            return value + ' ' + newClass;
        }
        return value + newClass;
    }
    if (("TURBOPACK compile-time value", "object") !== 'undefined' && module.exports) {
        classNames.default = classNames;
        module.exports = classNames;
    } else if (typeof define === 'function' && typeof define.amd === 'object' && define.amd) {
        // register as 'classnames', consistent with npm package name
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return classNames;
        }());
    } else {
        window.classNames = classNames;
    }
})();
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_BREAKPOINTS",
    ()=>DEFAULT_BREAKPOINTS,
    "DEFAULT_MIN_BREAKPOINT",
    ()=>DEFAULT_MIN_BREAKPOINT,
    "ThemeConsumer",
    ()=>Consumer,
    "createBootstrapComponent",
    ()=>createBootstrapComponent,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useBootstrapBreakpoints",
    ()=>useBootstrapBreakpoints,
    "useBootstrapMinBreakpoint",
    ()=>useBootstrapMinBreakpoint,
    "useBootstrapPrefix",
    ()=>useBootstrapPrefix,
    "useIsRTL",
    ()=>useIsRTL
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
const DEFAULT_BREAKPOINTS = [
    'xxl',
    'xl',
    'lg',
    'md',
    'sm',
    'xs'
];
const DEFAULT_MIN_BREAKPOINT = 'xs';
const ThemeContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    prefixes: {},
    breakpoints: DEFAULT_BREAKPOINTS,
    minBreakpoint: DEFAULT_MIN_BREAKPOINT
});
const { Consumer, Provider } = ThemeContext;
function ThemeProvider({ prefixes = {}, breakpoints = DEFAULT_BREAKPOINTS, minBreakpoint = DEFAULT_MIN_BREAKPOINT, dir, children }) {
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ThemeProvider.useMemo[contextValue]": ()=>({
                prefixes: {
                    ...prefixes
                },
                breakpoints,
                minBreakpoint,
                dir
            })
    }["ThemeProvider.useMemo[contextValue]"], [
        prefixes,
        breakpoints,
        minBreakpoint,
        dir
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Provider, {
        value: contextValue,
        children: children
    });
}
function useBootstrapPrefix(prefix, defaultPrefix) {
    const { prefixes } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    return prefix || prefixes[defaultPrefix] || defaultPrefix;
}
function useBootstrapBreakpoints() {
    const { breakpoints } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    return breakpoints;
}
function useBootstrapMinBreakpoint() {
    const { minBreakpoint } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    return minBreakpoint;
}
function useIsRTL() {
    const { dir } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    return dir === 'rtl';
}
function createBootstrapComponent(Component, opts) {
    if (typeof opts === 'string') opts = {
        prefix: opts
    };
    const isClassy = Component.prototype && Component.prototype.isReactComponent;
    // If it's a functional component make sure we don't break it with a ref
    const { prefix, forwardRefAs = isClassy ? 'ref' : 'innerRef' } = opts;
    const Wrapped = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ ...props }, ref)=>{
        props[forwardRefAs] = ref;
        const bsPrefix = useBootstrapPrefix(props.bsPrefix, prefix);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
            ...props,
            bsPrefix: bsPrefix
        });
    });
    Wrapped.displayName = `Bootstrap(${Component.displayName || Component.name})`;
    return Wrapped;
}
;
const __TURBOPACK__default__export__ = ThemeProvider;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const Container = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, fluid = false, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'div', className, ...props }, ref)=>{
    const prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'container');
    const suffix = typeof fluid === 'string' ? `-${fluid}` : '-fluid';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, fluid ? `${prefix}${suffix}` : prefix)
    });
});
Container.displayName = 'Container';
const __TURBOPACK__default__export__ = Container;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Container",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_extends
]);
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", _extends.apply(null, arguments);
}
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_objectWithoutPropertiesLoose
]);
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
    }
    return t;
}
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/invariant/browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */ var invariant = function(condition, format, a, b, c, d, e, f) {
    if ("TURBOPACK compile-time truthy", 1) {
        if (format === undefined) {
            throw new Error('invariant requires an error message argument');
        }
    }
    if (!condition) {
        var error;
        if (format === undefined) {
            error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
        } else {
            var args = [
                a,
                b,
                c,
                d,
                e,
                f
            ];
            var argIndex = 0;
            error = new Error(format.replace(/%s/g, function() {
                return args[argIndex++];
            }));
            error.name = 'Invariant Violation';
        }
        error.framesToPop = 1; // we don't care about invariant's own frame
        throw error;
    }
};
module.exports = invariant;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "canAcceptRef",
    ()=>canAcceptRef,
    "defaultKey",
    ()=>defaultKey,
    "isProp",
    ()=>isProp,
    "uncontrolledPropTypes",
    ()=>uncontrolledPropTypes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$invariant$2f$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/invariant/browser.js [app-client] (ecmascript)");
;
var noop = function noop() {};
function readOnlyPropType(handler, name) {
    return function(props, propName) {
        if (props[propName] !== undefined) {
            if (!props[handler]) {
                return new Error("You have provided a `" + propName + "` prop to `" + name + "` " + ("without an `" + handler + "` handler prop. This will render a read-only field. ") + ("If the field should be mutable use `" + defaultKey(propName) + "`. ") + ("Otherwise, set `" + handler + "`."));
            }
        }
    };
}
function uncontrolledPropTypes(controlledValues, displayName) {
    var propTypes = {};
    Object.keys(controlledValues).forEach(function(prop) {
        // add default propTypes for folks that use runtime checks
        propTypes[defaultKey(prop)] = noop;
        if ("TURBOPACK compile-time truthy", 1) {
            var handler = controlledValues[prop];
            !(typeof handler === 'string' && handler.trim().length) ? ("TURBOPACK compile-time truthy", 1) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$invariant$2f$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, 'Uncontrollable - [%s]: the prop `%s` needs a valid handler key name in order to make it uncontrollable', displayName, prop) : "TURBOPACK unreachable" : void 0;
            propTypes[prop] = readOnlyPropType(handler, displayName);
        }
    });
    return propTypes;
}
function isProp(props, prop) {
    return props[prop] !== undefined;
}
function defaultKey(key) {
    return 'default' + key.charAt(0).toUpperCase() + key.substr(1);
}
function canAcceptRef(component) {
    return !!component && (typeof component !== 'function' || component.prototype && component.prototype.isReactComponent);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useUncontrolled,
    "useUncontrolledProp",
    ()=>useUncontrolledProp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/utils.js [app-client] (ecmascript)");
;
;
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return typeof key === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (typeof res !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
;
;
function useUncontrolledProp(propValue, defaultValue, handler) {
    var wasPropRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(propValue !== undefined);
    var _useState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue), stateValue = _useState[0], setState = _useState[1];
    var isProp = propValue !== undefined;
    var wasProp = wasPropRef.current;
    wasPropRef.current = isProp;
    /**
   * If a prop switches from controlled to Uncontrolled
   * reset its value to the defaultValue
   */ if (!isProp && wasProp && stateValue !== defaultValue) {
        setState(defaultValue);
    }
    return [
        isProp ? propValue : stateValue,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "useUncontrolledProp.useCallback": function(value) {
                for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
                    args[_key - 1] = arguments[_key];
                }
                if (handler) handler.apply(void 0, [
                    value
                ].concat(args));
                setState(value);
            }
        }["useUncontrolledProp.useCallback"], [
            handler
        ])
    ];
}
;
function useUncontrolled(props, config) {
    return Object.keys(config).reduce(function(result, fieldName) {
        var _extends2;
        var _ref = result, defaultValue = _ref[__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultKey"](fieldName)], propsValue = _ref[fieldName], rest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_ref, [
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultKey"](fieldName),
            fieldName
        ].map(_toPropertyKey));
        var handlerName = config[fieldName];
        var _useUncontrolledProp = useUncontrolledProp(propsValue, defaultValue, props[handlerName]), value = _useUncontrolledProp[0], handler = _useUncontrolledProp[1];
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, rest, (_extends2 = {}, _extends2[fieldName] = value, _extends2[handlerName] = handler, _extends2));
    }, props);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_setPrototypeOf
]);
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/inheritsLoose.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_inheritsLoose
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$setPrototypeOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js [app-client] (ecmascript)");
;
function _inheritsLoose(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$setPrototypeOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t, o);
}
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "polyfill",
    ()=>polyfill
]);
function componentWillMount() {
    // Call this.constructor.gDSFP to support sub-classes.
    var state = this.constructor.getDerivedStateFromProps(this.props, this.state);
    if (state !== null && state !== undefined) {
        this.setState(state);
    }
}
function componentWillReceiveProps(nextProps) {
    // Call this.constructor.gDSFP to support sub-classes.
    // Use the setState() updater to ensure state isn't stale in certain edge cases.
    function updater(prevState) {
        var state = this.constructor.getDerivedStateFromProps(nextProps, prevState);
        return state !== null && state !== undefined ? state : null;
    }
    // Binding "this" is important for shallow renderer support.
    this.setState(updater.bind(this));
}
function componentWillUpdate(nextProps, nextState) {
    try {
        var prevProps = this.props;
        var prevState = this.state;
        this.props = nextProps;
        this.state = nextState;
        this.__reactInternalSnapshotFlag = true;
        this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(prevProps, prevState);
    } finally{
        this.props = prevProps;
        this.state = prevState;
    }
}
// React may warn about cWM/cWRP/cWU methods being deprecated.
// Add a flag to suppress these warnings for this special case.
componentWillMount.__suppressDeprecationWarning = true;
componentWillReceiveProps.__suppressDeprecationWarning = true;
componentWillUpdate.__suppressDeprecationWarning = true;
function polyfill(Component) {
    var prototype = Component.prototype;
    if (!prototype || !prototype.isReactComponent) {
        throw new Error('Can only polyfill class components');
    }
    if (typeof Component.getDerivedStateFromProps !== 'function' && typeof prototype.getSnapshotBeforeUpdate !== 'function') {
        return Component;
    }
    // If new component APIs are defined, "unsafe" lifecycles won't be called.
    // Error if any of these lifecycles are present,
    // Because they would work differently between older and newer (16.3+) versions of React.
    var foundWillMountName = null;
    var foundWillReceivePropsName = null;
    var foundWillUpdateName = null;
    if (typeof prototype.componentWillMount === 'function') {
        foundWillMountName = 'componentWillMount';
    } else if (typeof prototype.UNSAFE_componentWillMount === 'function') {
        foundWillMountName = 'UNSAFE_componentWillMount';
    }
    if (typeof prototype.componentWillReceiveProps === 'function') {
        foundWillReceivePropsName = 'componentWillReceiveProps';
    } else if (typeof prototype.UNSAFE_componentWillReceiveProps === 'function') {
        foundWillReceivePropsName = 'UNSAFE_componentWillReceiveProps';
    }
    if (typeof prototype.componentWillUpdate === 'function') {
        foundWillUpdateName = 'componentWillUpdate';
    } else if (typeof prototype.UNSAFE_componentWillUpdate === 'function') {
        foundWillUpdateName = 'UNSAFE_componentWillUpdate';
    }
    if (foundWillMountName !== null || foundWillReceivePropsName !== null || foundWillUpdateName !== null) {
        var componentName = Component.displayName || Component.name;
        var newApiName = typeof Component.getDerivedStateFromProps === 'function' ? 'getDerivedStateFromProps()' : 'getSnapshotBeforeUpdate()';
        throw Error('Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' + componentName + ' uses ' + newApiName + ' but also contains the following legacy lifecycles:' + (foundWillMountName !== null ? '\n  ' + foundWillMountName : '') + (foundWillReceivePropsName !== null ? '\n  ' + foundWillReceivePropsName : '') + (foundWillUpdateName !== null ? '\n  ' + foundWillUpdateName : '') + '\n\nThe above lifecycles should be removed. Learn more about this warning here:\n' + 'https://fb.me/react-async-component-lifecycle-hooks');
    }
    // React <= 16.2 does not support static getDerivedStateFromProps.
    // As a workaround, use cWM and cWRP to invoke the new static lifecycle.
    // Newer versions of React will ignore these lifecycles if gDSFP exists.
    if (typeof Component.getDerivedStateFromProps === 'function') {
        prototype.componentWillMount = componentWillMount;
        prototype.componentWillReceiveProps = componentWillReceiveProps;
    }
    // React <= 16.2 does not support getSnapshotBeforeUpdate.
    // As a workaround, use cWU to invoke the new lifecycle.
    // Newer versions of React will ignore that lifecycle if gSBU exists.
    if (typeof prototype.getSnapshotBeforeUpdate === 'function') {
        if (typeof prototype.componentDidUpdate !== 'function') {
            throw new Error('Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype');
        }
        prototype.componentWillUpdate = componentWillUpdate;
        var componentDidUpdate = prototype.componentDidUpdate;
        prototype.componentDidUpdate = function componentDidUpdatePolyfill(prevProps, prevState, maybeSnapshot) {
            // 16.3+ will not execute our will-update method;
            // It will pass a snapshot value to did-update though.
            // Older versions will require our polyfilled will-update value.
            // We need to handle both cases, but can't just check for the presence of "maybeSnapshot",
            // Because for <= 15.x versions this might be a "prevContext" object.
            // We also can't just check "__reactInternalSnapshot",
            // Because get-snapshot might return a falsy value.
            // So check for the explicit __reactInternalSnapshotFlag flag to determine behavior.
            var snapshot = this.__reactInternalSnapshotFlag ? this.__reactInternalSnapshot : maybeSnapshot;
            componentDidUpdate.call(this, prevProps, prevState, snapshot);
        };
    }
    return Component;
}
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/uncontrollable.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>uncontrollable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/inheritsLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$lifecycles$2d$compat$2f$react$2d$lifecycles$2d$compat$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$invariant$2f$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/invariant/browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/utils.js [app-client] (ecmascript)");
;
;
;
var _jsxFileName = "/Users/jquense/src/uncontrollable/src/uncontrollable.js";
;
;
;
;
function uncontrollable(Component, controlledValues, methods) {
    if (methods === void 0) {
        methods = [];
    }
    var displayName = Component.displayName || Component.name || 'Component';
    var canAcceptRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAcceptRef"](Component);
    var controlledProps = Object.keys(controlledValues);
    var PROPS_TO_OMIT = controlledProps.map(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultKey"]);
    !(canAcceptRef || !methods.length) ? ("TURBOPACK compile-time truthy", 1) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$invariant$2f$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, '[uncontrollable] stateless function components cannot pass through methods ' + 'because they have no associated instances. Check component: ' + displayName + ', ' + 'attempting to pass through methods: ' + methods.join(', ')) : "TURBOPACK unreachable" : void 0;
    var UncontrolledComponent = /*#__PURE__*/ function(_React$Component) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(UncontrolledComponent, _React$Component);
        function UncontrolledComponent() {
            var _this;
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            _this = _React$Component.call.apply(_React$Component, [
                this
            ].concat(args)) || this;
            _this.handlers = Object.create(null);
            controlledProps.forEach(function(propName) {
                var handlerName = controlledValues[propName];
                var handleChange = function handleChange(value) {
                    if (_this.props[handlerName]) {
                        var _this$props;
                        _this._notifying = true;
                        for(var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++){
                            args[_key2 - 1] = arguments[_key2];
                        }
                        (_this$props = _this.props)[handlerName].apply(_this$props, [
                            value
                        ].concat(args));
                        _this._notifying = false;
                    }
                    if (!_this.unmounted) _this.setState(function(_ref) {
                        var _extends2;
                        var values = _ref.values;
                        return {
                            values: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Object.create(null), values, (_extends2 = {}, _extends2[propName] = value, _extends2))
                        };
                    });
                };
                _this.handlers[handlerName] = handleChange;
            });
            if (methods.length) _this.attachRef = function(ref) {
                _this.inner = ref;
            };
            var values = Object.create(null);
            controlledProps.forEach(function(key) {
                values[key] = _this.props[__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultKey"](key)];
            });
            _this.state = {
                values: values,
                prevProps: {}
            };
            return _this;
        }
        var _proto = UncontrolledComponent.prototype;
        _proto.shouldComponentUpdate = function shouldComponentUpdate() {
            //let setState trigger the update
            return !this._notifying;
        };
        UncontrolledComponent.getDerivedStateFromProps = function getDerivedStateFromProps(props, _ref2) {
            var values = _ref2.values, prevProps = _ref2.prevProps;
            var nextState = {
                values: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Object.create(null), values),
                prevProps: {}
            };
            controlledProps.forEach(function(key) {
                /**
         * If a prop switches from controlled to Uncontrolled
         * reset its value to the defaultValue
         */ nextState.prevProps[key] = props[key];
                if (!__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isProp"](props, key) && __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isProp"](prevProps, key)) {
                    nextState.values[key] = props[__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultKey"](key)];
                }
            });
            return nextState;
        };
        _proto.componentWillUnmount = function componentWillUnmount() {
            this.unmounted = true;
        };
        _proto.render = function render() {
            var _this2 = this;
            var _this$props2 = this.props, innerRef = _this$props2.innerRef, props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this$props2, [
                "innerRef"
            ]);
            PROPS_TO_OMIT.forEach(function(prop) {
                delete props[prop];
            });
            var newProps = {};
            controlledProps.forEach(function(propName) {
                var propValue = _this2.props[propName];
                newProps[propName] = propValue !== undefined ? propValue : _this2.state.values[propName];
            });
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Component, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props, newProps, this.handlers, {
                ref: innerRef || this.attachRef
            }));
        };
        return UncontrolledComponent;
    }(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Component);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$lifecycles$2d$compat$2f$react$2d$lifecycles$2d$compat$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polyfill"])(UncontrolledComponent);
    UncontrolledComponent.displayName = "Uncontrolled(" + displayName + ")";
    UncontrolledComponent.propTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        innerRef: function innerRef() {}
    }, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uncontrolledPropTypes"](controlledValues, displayName));
    methods.forEach(function(method) {
        UncontrolledComponent.prototype[method] = function $proxiedMethod() {
            var _this$inner;
            return (_this$inner = this.inner)[method].apply(_this$inner, arguments);
        };
    });
    var WrappedComponent = UncontrolledComponent;
    if (__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef) {
        WrappedComponent = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(function(props, ref) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(UncontrolledComponent, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props, {
                innerRef: ref,
                __source: {
                    fileName: _jsxFileName,
                    lineNumber: 128
                },
                __self: this
            }));
        });
        WrappedComponent.propTypes = UncontrolledComponent.propTypes;
    }
    WrappedComponent.ControlledComponent = Component;
    /**
   * useful when wrapping a Component and you want to control
   * everything
   */ WrappedComponent.deferControlTo = function(newComponent, additions, nextMethods) {
        if (additions === void 0) {
            additions = {};
        }
        return uncontrollable(newComponent, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, controlledValues, additions), nextMethods);
    };
    return WrappedComponent;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$uncontrollable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/uncontrollable.js [app-client] (ecmascript)");
;
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript) <export default as useUncontrolled>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useUncontrolled",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/querySelectorAll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>qsa
]);
var toArray = Function.prototype.bind.call(Function.prototype.call, [].slice);
function qsa(element, selector) {
    return toArray(element.querySelectorAll(selector));
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useForceUpdate.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useForceUpdate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useForceUpdate() {
    // The toggling state value is designed to defeat React optimizations for skipping
    // updates when they are strictly equal to the last state value
    const [, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])({
        "useForceUpdate.useReducer": (revision)=>revision + 1
    }["useForceUpdate.useReducer"], 0);
    return dispatch;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "mergeRefs",
    ()=>mergeRefs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const toFnRef = (ref)=>!ref || typeof ref === 'function' ? ref : (value)=>{
        ref.current = value;
    };
function mergeRefs(refA, refB) {
    const a = toFnRef(refA);
    const b = toFnRef(refB);
    return (value)=>{
        if (a) a(value);
        if (b) b(value);
    };
}
/**
 * Create and returns a single callback ref composed from two other Refs.
 *
 * ```tsx
 * const Button = React.forwardRef((props, ref) => {
 *   const [element, attachRef] = useCallbackRef<HTMLButtonElement>();
 *   const mergedRef = useMergedRefs(ref, attachRef);
 *
 *   return <button ref={mergedRef} {...props}/>
 * })
 * ```
 *
 * @param refA A Callback or mutable Ref
 * @param refB A Callback or mutable Ref
 * @category refs
 */ function useMergedRefs(refA, refB) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMergedRefs.useMemo": ()=>mergeRefs(refA, refB)
    }["useMergedRefs.useMemo"], [
        refA,
        refB
    ]);
}
const __TURBOPACK__default__export__ = useMergedRefs;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const NavContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
NavContext.displayName = 'NavContext';
const __TURBOPACK__default__export__ = NavContext;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/SelectableContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "makeEventKey",
    ()=>makeEventKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const SelectableContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
const makeEventKey = (eventKey, href = null)=>{
    if (eventKey != null) return String(eventKey);
    return href || null;
};
const __TURBOPACK__default__export__ = SelectableContext;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/TabContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const TabContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
const __TURBOPACK__default__export__ = TabContext;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/DataKey.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ATTRIBUTE_PREFIX",
    ()=>ATTRIBUTE_PREFIX,
    "PROPERTY_PREFIX",
    ()=>PROPERTY_PREFIX,
    "dataAttr",
    ()=>dataAttr,
    "dataProp",
    ()=>dataProp
]);
const ATTRIBUTE_PREFIX = `data-rr-ui-`;
const PROPERTY_PREFIX = `rrUi`;
function dataAttr(property) {
    return `${ATTRIBUTE_PREFIX}${property}`;
}
function dataProp(property) {
    return `${PROPERTY_PREFIX}${property}`;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
/**
 * Creates a `Ref` whose value is updated in an effect, ensuring the most recent
 * value is the one rendered with. Generally only required for Concurrent mode usage
 * where previous work in `render()` may be discarded before being used.
 *
 * This is safe to access in an event handler.
 *
 * @param value The `Ref` value
 */ function useCommittedRef(value) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCommittedRef.useEffect": ()=>{
            ref.current = value;
        }
    }["useCommittedRef.useEffect"], [
        value
    ]);
    return ref;
}
const __TURBOPACK__default__export__ = useCommittedRef;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useEventCallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)");
;
;
function useEventCallback(fn) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useEventCallback.useCallback": function(...args) {
            return ref.current && ref.current(...args);
        }
    }["useEventCallback.useCallback"], [
        ref
    ]);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Button.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isTrivialHref",
    ()=>isTrivialHref,
    "useButtonProps",
    ()=>useButtonProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "as",
    "disabled"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
function isTrivialHref(href) {
    return !href || href.trim() === '#';
}
function useButtonProps({ tagName, disabled, href, target, rel, role, onClick, tabIndex = 0, type }) {
    if (!tagName) {
        if (href != null || target != null || rel != null) {
            tagName = 'a';
        } else {
            tagName = 'button';
        }
    }
    const meta = {
        tagName
    };
    if (tagName === 'button') {
        return [
            {
                type: type || 'button',
                disabled
            },
            meta
        ];
    }
    const handleClick = (event)=>{
        if (disabled || tagName === 'a' && isTrivialHref(href)) {
            event.preventDefault();
        }
        if (disabled) {
            event.stopPropagation();
            return;
        }
        onClick == null ? void 0 : onClick(event);
    };
    const handleKeyDown = (event)=>{
        if (event.key === ' ') {
            event.preventDefault();
            handleClick(event);
        }
    };
    if (tagName === 'a') {
        // Ensure there's a href so Enter can trigger anchor button.
        href || (href = '#');
        if (disabled) {
            href = undefined;
        }
    }
    return [
        {
            role: role != null ? role : 'button',
            // explicitly undefined so that it overrides the props disabled in a spread
            // e.g. <Tag {...props} {...hookProps} />
            disabled: undefined,
            tabIndex: disabled ? undefined : tabIndex,
            href,
            target: tagName === 'a' ? target : undefined,
            'aria-disabled': !disabled ? undefined : disabled,
            rel: tagName === 'a' ? rel : undefined,
            onClick: handleClick,
            onKeyDown: handleKeyDown
        },
        meta
    ];
}
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((_ref, ref)=>{
    let { as: asProp, disabled } = _ref, props = _objectWithoutPropertiesLoose(_ref, _excluded);
    const [buttonProps, { tagName: Component }] = useButtonProps(Object.assign({
        tagName: asProp,
        disabled
    }, props));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, Object.assign({}, props, buttonProps, {
        ref: ref
    }));
});
Button.displayName = 'Button';
const __TURBOPACK__default__export__ = Button;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useNavItem",
    ()=>useNavItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/SelectableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/DataKey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$TabContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/TabContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "as",
    "active",
    "eventKey"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
;
;
;
;
;
;
function useNavItem({ key, onClick, active, id, role, disabled }) {
    const parentOnSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const navContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const tabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$TabContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let isActive = active;
    const props = {
        role
    };
    if (navContext) {
        if (!role && navContext.role === 'tablist') props.role = 'tab';
        const contextControllerId = navContext.getControllerId(key != null ? key : null);
        const contextControlledId = navContext.getControlledId(key != null ? key : null);
        // @ts-ignore
        props[(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataAttr"])('event-key')] = key;
        props.id = contextControllerId || id;
        isActive = active == null && key != null ? navContext.activeKey === key : active;
        /**
     * Simplified scenario for `mountOnEnter`.
     *
     * While it would make sense to keep 'aria-controls' for tabs that have been mounted at least
     * once, it would also complicate the code quite a bit, for very little gain.
     * The following implementation is probably good enough.
     *
     * @see https://github.com/react-restart/ui/pull/40#issuecomment-1009971561
     */ if (isActive || !(tabContext != null && tabContext.unmountOnExit) && !(tabContext != null && tabContext.mountOnEnter)) props['aria-controls'] = contextControlledId;
    }
    if (props.role === 'tab') {
        props['aria-selected'] = isActive;
        if (!isActive) {
            props.tabIndex = -1;
        }
        if (disabled) {
            props.tabIndex = -1;
            props['aria-disabled'] = true;
        }
    }
    props.onClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useNavItem.useEventCallback": (e)=>{
            if (disabled) return;
            onClick == null ? void 0 : onClick(e);
            if (key == null) {
                return;
            }
            if (parentOnSelect && !e.isPropagationStopped()) {
                parentOnSelect(key, e);
            }
        }
    }["useNavItem.useEventCallback"]);
    return [
        props,
        {
            isActive
        }
    ];
}
const NavItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((_ref, ref)=>{
    let { as: Component = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], active, eventKey } = _ref, options = _objectWithoutPropertiesLoose(_ref, _excluded);
    const [props, meta] = useNavItem(Object.assign({
        key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeEventKey"])(eventKey, options.href),
        active
    }, options));
    // @ts-ignore
    props[(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataAttr"])('active')] = meta.isActive;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, Object.assign({}, options, props, {
        ref: ref
    }));
});
NavItem.displayName = 'NavItem';
const __TURBOPACK__default__export__ = NavItem;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Nav.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/querySelectorAll.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useForceUpdate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useForceUpdate.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/SelectableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$TabContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/TabContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/DataKey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "as",
    "onSelect",
    "activeKey",
    "role",
    "onKeyDown"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
;
;
;
;
;
;
;
;
// eslint-disable-next-line @typescript-eslint/no-empty-function
const noop = ()=>{};
const EVENT_KEY_ATTR = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataAttr"])('event-key');
const Nav = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((_ref, ref)=>{
    let { // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
    as: Component = 'div', onSelect, activeKey, role, onKeyDown } = _ref, props = _objectWithoutPropertiesLoose(_ref, _excluded);
    // A ref and forceUpdate for refocus, b/c we only want to trigger when needed
    // and don't want to reset the set in the effect
    const forceUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useForceUpdate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const needsRefocusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const parentOnSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const tabContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$TabContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    let getControlledId, getControllerId;
    if (tabContext) {
        role = role || 'tablist';
        activeKey = tabContext.activeKey;
        // TODO: do we need to duplicate these?
        getControlledId = tabContext.getControlledId;
        getControllerId = tabContext.getControllerId;
    }
    const listNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const getNextActiveTab = (offset)=>{
        const currentListNode = listNode.current;
        if (!currentListNode) return null;
        const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(currentListNode, `[${EVENT_KEY_ATTR}]:not([aria-disabled=true])`);
        const activeChild = currentListNode.querySelector('[aria-selected=true]');
        if (!activeChild || activeChild !== document.activeElement) return null;
        const index = items.indexOf(activeChild);
        if (index === -1) return null;
        let nextIndex = index + offset;
        if (nextIndex >= items.length) nextIndex = 0;
        if (nextIndex < 0) nextIndex = items.length - 1;
        return items[nextIndex];
    };
    const handleSelect = (key, event)=>{
        if (key == null) return;
        onSelect == null ? void 0 : onSelect(key, event);
        parentOnSelect == null ? void 0 : parentOnSelect(key, event);
    };
    const handleKeyDown = (event)=>{
        onKeyDown == null ? void 0 : onKeyDown(event);
        if (!tabContext) {
            return;
        }
        let nextActiveChild;
        switch(event.key){
            case 'ArrowLeft':
            case 'ArrowUp':
                nextActiveChild = getNextActiveTab(-1);
                break;
            case 'ArrowRight':
            case 'ArrowDown':
                nextActiveChild = getNextActiveTab(1);
                break;
            default:
                return;
        }
        if (!nextActiveChild) return;
        event.preventDefault();
        handleSelect(nextActiveChild.dataset[(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataProp"])('EventKey')] || null, event);
        needsRefocusRef.current = true;
        forceUpdate();
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            if (listNode.current && needsRefocusRef.current) {
                const activeChild = listNode.current.querySelector(`[${EVENT_KEY_ATTR}][aria-selected=true]`);
                activeChild == null ? void 0 : activeChild.focus();
            }
            needsRefocusRef.current = false;
        }
    }["Nav.useEffect"]);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ref, listNode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: handleSelect,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: {
                role,
                // used by NavLink to determine it's role
                activeKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeEventKey"])(activeKey),
                getControlledId: getControlledId || noop,
                getControllerId: getControllerId || noop
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, Object.assign({}, props, {
                onKeyDown: handleKeyDown,
                ref: mergedRef,
                role: role
            }))
        })
    });
});
Nav.displayName = 'Nav';
const __TURBOPACK__default__export__ = Object.assign(Nav, {
    Item: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
// TODO: check
const context = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
context.displayName = 'NavbarContext';
const __TURBOPACK__default__export__ = context;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardHeaderContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
const context = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
context.displayName = 'CardHeaderContext';
const __TURBOPACK__default__export__ = context;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const NavItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'div', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'nav-item');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
NavItem.displayName = 'NavItem';
const __TURBOPACK__default__export__ = NavItem;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCallbackRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useCallbackRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useCallbackRef() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventListener.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useEventListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
;
;
function useEventListener(eventTarget, event, listener, capture = false) {
    const handler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(listener);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useEventListener.useEffect": ()=>{
            const target = typeof eventTarget === 'function' ? eventTarget() : eventTarget;
            target.addEventListener(event, handler, capture);
            return ({
                "useEventListener.useEffect": ()=>target.removeEventListener(event, handler, capture)
            })["useEventListener.useEffect"];
        }
    }["useEventListener.useEffect"], [
        eventTarget
    ]);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useGlobalListener.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useGlobalListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function useGlobalListener(event, handler, capture = false) {
    const documentTarget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useGlobalListener.useCallback[documentTarget]": ()=>document
    }["useGlobalListener.useCallback[documentTarget]"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(documentTarget, event, handler, capture);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useInterval.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)");
;
;
/**
 * Creates a `setInterval` that is properly cleaned up when a component unmounted
 *
 * ```tsx
 *  function Timer() {
 *    const [timer, setTimer] = useState(0)
 *    useInterval(() => setTimer(i => i + 1), 1000)
 *
 *    return <span>{timer} seconds past</span>
 *  }
 * ```
 *
 * @param fn an function run on each interval
 * @param ms The milliseconds duration of the interval
 */ /**
 * Creates a pausable `setInterval` that is properly cleaned up when a component unmounted
 *
 * ```tsx
 *  const [paused, setPaused] = useState(false)
 *  const [timer, setTimer] = useState(0)
 *
 *  useInterval(() => setTimer(i => i + 1), 1000, paused)
 *
 *  return (
 *    <span>
 *      {timer} seconds past
 *
 *      <button onClick={() => setPaused(p => !p)}>{paused ? 'Play' : 'Pause' }</button>
 *    </span>
 * )
 * ```
 *
 * @param fn an function run on each interval
 * @param ms The milliseconds duration of the interval
 * @param paused Whether or not the interval is currently running
 */ /**
 * Creates a pausable `setInterval` that _fires_ immediately and is
 * properly cleaned up when a component unmounted
 *
 * ```tsx
 *  const [timer, setTimer] = useState(-1)
 *  useInterval(() => setTimer(i => i + 1), 1000, false, true)
 *
 *  // will update to 0 on the first effect
 *  return <span>{timer} seconds past</span>
 * ```
 *
 * @param fn an function run on each interval
 * @param ms The milliseconds duration of the interval
 * @param paused Whether or not the interval is currently running
 * @param runImmediately Whether to run the function immediately on mount or unpause
 * rather than waiting for the first interval to elapse
 *

 */ function useInterval(fn, ms, paused = false, runImmediately = false) {
    let handle;
    const fnRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn);
    // this ref is necessary b/c useEffect will sometimes miss a paused toggle
    // orphaning a setTimeout chain in the aether, so relying on it's refresh logic is not reliable.
    const pausedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(paused);
    const tick = ()=>{
        if (pausedRef.current) return;
        fnRef.current();
        schedule(); // eslint-disable-line no-use-before-define
    };
    const schedule = ()=>{
        clearTimeout(handle);
        handle = setTimeout(tick, ms);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useInterval.useEffect": ()=>{
            if (runImmediately) {
                tick();
            } else {
                schedule();
            }
            return ({
                "useInterval.useEffect": ()=>clearTimeout(handle)
            })["useInterval.useEffect"];
        }
    }["useInterval.useEffect"], [
        paused,
        runImmediately
    ]);
}
const __TURBOPACK__default__export__ = useInterval;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useRafInterval.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)");
;
;
function useRafInterval(fn, ms, paused = false) {
    let handle;
    let start = new Date().getTime();
    const fnRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn);
    // this ref is necessary b/c useEffect will sometimes miss a paused toggle
    // orphaning a setTimeout chain in the aether, so relying on it's refresh logic is not reliable.
    const pausedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(paused);
    function loop() {
        const current = new Date().getTime();
        const delta = current - start;
        if (pausedRef.current) return;
        if (delta >= ms && fnRef.current) {
            fnRef.current();
            start = new Date().getTime();
        }
        cancelAnimationFrame(handle);
        handle = requestAnimationFrame(loop);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRafInterval.useEffect": ()=>{
            handle = requestAnimationFrame(loop);
            return ({
                "useRafInterval.useEffect": ()=>cancelAnimationFrame(handle)
            })["useRafInterval.useEffect"];
        }
    }["useRafInterval.useEffect"], []);
}
const __TURBOPACK__default__export__ = useRafInterval;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergeState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useMergeState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useMergeState(initialState) {
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialState);
    const updater = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMergeState.useCallback[updater]": (update)=>{
            if (update === null) return;
            if (typeof update === 'function') {
                setState({
                    "useMergeState.useCallback[updater]": (state)=>{
                        const nextState = update(state);
                        return nextState == null ? state : Object.assign({}, state, nextState);
                    }
                }["useMergeState.useCallback[updater]"]);
            } else {
                setState({
                    "useMergeState.useCallback[updater]": (state)=>Object.assign({}, state, update)
                }["useMergeState.useCallback[updater]"]);
            }
        }
    }["useMergeState.useCallback[updater]"], [
        setState
    ]);
    return [
        state,
        updater
    ];
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergeStateFromProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useMergeStateFromProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergeState.js [app-client] (ecmascript)");
;
function useMergeStateFromProps(props, gDSFP, initialState) {
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(initialState);
    const nextState = gDSFP(props, state);
    if (nextState !== null) setState(nextState);
    return [
        state,
        setState
    ];
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMounted.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useMounted
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useMounted() {
    const mounted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    const isMounted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        "useMounted.useRef[isMounted]": ()=>mounted.current
    }["useMounted.useRef[isMounted]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMounted.useEffect": ()=>{
            mounted.current = true;
            return ({
                "useMounted.useEffect": ()=>{
                    mounted.current = false;
                }
            })["useMounted.useEffect"];
        }
    }["useMounted.useEffect"], []);
    return isMounted.current;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/usePrevious.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>usePrevious
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function usePrevious(value) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePrevious.useEffect": ()=>{
            ref.current = value;
        }
    }["usePrevious.useEffect"]);
    return ref.current;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useImage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useImage(imageOrUrl, crossOrigin) {
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        image: null,
        error: null
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useImage.useEffect": ()=>{
            if (!imageOrUrl) return undefined;
            let image;
            if (typeof imageOrUrl === 'string') {
                image = new Image();
                if (crossOrigin) image.crossOrigin = crossOrigin;
                image.src = imageOrUrl;
            } else {
                image = imageOrUrl;
                if (image.complete && image.naturalHeight > 0) {
                    setState({
                        image,
                        error: null
                    });
                    return;
                }
            }
            function onLoad() {
                setState({
                    image,
                    error: null
                });
            }
            function onError(error) {
                setState({
                    image,
                    error
                });
            }
            image.addEventListener('load', onLoad);
            image.addEventListener('error', onError);
            return ({
                "useImage.useEffect": ()=>{
                    image.removeEventListener('load', onLoad);
                    image.removeEventListener('error', onError);
                }
            })["useImage.useEffect"];
        }
    }["useImage.useEffect"], [
        imageOrUrl,
        crossOrigin
    ]);
    return state;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useIsomorphicEffect.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const isReactNative = ("TURBOPACK compile-time value", "object") !== 'undefined' && // @ts-ignore
/*TURBOPACK member replacement*/ __turbopack_context__.g.navigator && // @ts-ignore
/*TURBOPACK member replacement*/ __turbopack_context__.g.navigator.product === 'ReactNative';
const isDOM = typeof document !== 'undefined';
const __TURBOPACK__default__export__ = isDOM || isReactNative ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useResizeObserver.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useResizeObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useIsomorphicEffect.js [app-client] (ecmascript)");
;
;
const targetMap = new WeakMap();
let resizeObserver;
function getResizeObserver() {
    // eslint-disable-next-line no-return-assign
    return resizeObserver = resizeObserver || new window.ResizeObserver((entries)=>{
        entries.forEach((entry)=>{
            const handler = targetMap.get(entry.target);
            if (handler) handler(entry.contentRect);
        });
    });
}
function useResizeObserver(element) {
    const [rect, setRect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useResizeObserver.useEffect": ()=>{
            if (!element) return;
            getResizeObserver().observe(element);
            setRect(element.getBoundingClientRect());
            targetMap.set(element, {
                "useResizeObserver.useEffect": (rect)=>{
                    setRect(rect);
                }
            }["useResizeObserver.useEffect"]);
            return ({
                "useResizeObserver.useEffect": ()=>{
                    targetMap.delete(element);
                }
            })["useResizeObserver.useEffect"];
        }
    }["useResizeObserver.useEffect"], [
        element
    ]);
    return rect;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCallbackRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCallbackRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useGlobalListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useGlobalListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useInterval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useInterval.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useRafInterval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useRafInterval.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergeState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergeStateFromProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergeStateFromProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMounted$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMounted.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/usePrevious.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useImage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useImage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useResizeObserver.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript) <export default as useEventCallback>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useEventCallback",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Anchor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isTrivialHref",
    ()=>isTrivialHref
]);
/* eslint-disable jsx-a11y/no-static-element-interactions */ /* eslint-disable jsx-a11y/anchor-has-content */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useEventCallback$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript) <export default as useEventCallback>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "onKeyDown"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
;
function isTrivialHref(href) {
    return !href || href.trim() === '#';
}
/**
 * An generic `<a>` component that covers a few A11y cases, ensuring that
 * cases where the `href` is missing or trivial like "#" are treated like buttons.
 */ const Anchor = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((_ref, ref)=>{
    let { onKeyDown } = _ref, props = _objectWithoutPropertiesLoose(_ref, _excluded);
    const [buttonProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButtonProps"])(Object.assign({
        tagName: 'a'
    }, props));
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useEventCallback$3e$__["useEventCallback"])({
        "Anchor.useEventCallback[handleKeyDown]": (e)=>{
            buttonProps.onKeyDown(e);
            onKeyDown == null ? void 0 : onKeyDown(e);
        }
    }["Anchor.useEventCallback[handleKeyDown]"]);
    if (isTrivialHref(props.href) || props.role === 'button') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", Object.assign({
            ref: ref
        }, props, buttonProps, {
            onKeyDown: handleKeyDown
        }));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", Object.assign({
        ref: ref
    }, props, {
        onKeyDown: onKeyDown
    }));
});
Anchor.displayName = 'Anchor';
const __TURBOPACK__default__export__ = Anchor;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavLink.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Anchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Anchor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NavItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/SelectableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const NavLink = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, as: Component = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Anchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], active, eventKey, disabled = false, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'nav-link');
    const [navItemProps, meta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNavItem"])({
        key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeEventKey"])(eventKey, props.href),
        active,
        disabled,
        ...props
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...props,
        ...navItemProps,
        ref: ref,
        disabled: disabled,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix, disabled && 'disabled', meta.isActive && 'active')
    });
});
NavLink.displayName = 'NavLink';
const __TURBOPACK__default__export__ = NavLink;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Nav.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useUncontrolled$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript) <export default as useUncontrolled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Nav.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeaderContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardHeaderContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavLink.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
const Nav = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((uncontrolledProps, ref)=>{
    const { as = 'div', bsPrefix: initialBsPrefix, variant, fill = false, justify = false, navbar, navbarScroll, className, activeKey, ...props } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useUncontrolled$3e$__["useUncontrolled"])(uncontrolledProps, {
        activeKey: 'onSelect'
    });
    const bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(initialBsPrefix, 'nav');
    let navbarBsPrefix;
    let cardHeaderBsPrefix;
    let isNavbar = false;
    const navbarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const cardHeaderContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeaderContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    if (navbarContext) {
        navbarBsPrefix = navbarContext.bsPrefix;
        isNavbar = navbar == null ? true : navbar;
    } else if (cardHeaderContext) {
        ({ cardHeaderBsPrefix } = cardHeaderContext);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        as: as,
        ref: ref,
        activeKey: activeKey,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, {
            [bsPrefix]: !isNavbar,
            [`${navbarBsPrefix}-nav`]: isNavbar,
            [`${navbarBsPrefix}-nav-scroll`]: isNavbar && navbarScroll,
            [`${cardHeaderBsPrefix}-${variant}`]: !!cardHeaderBsPrefix,
            [`${bsPrefix}-${variant}`]: !!variant,
            [`${bsPrefix}-fill`]: fill,
            [`${bsPrefix}-justified`]: justify
        }),
        ...props
    });
});
Nav.displayName = 'Nav';
const __TURBOPACK__default__export__ = Object.assign(Nav, {
    Item: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Link: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Nav.js [app-client] (ecmascript) <export default as Nav>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Nav",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Nav$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Nav.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarBrand.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const NavbarBrand = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, as, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'navbar-brand');
    const Component = as || (props.href ? 'a' : 'span');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...props,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix)
    });
});
NavbarBrand.displayName = 'NavbarBrand';
const __TURBOPACK__default__export__ = NavbarBrand;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerDocument.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Returns the owner document of a given element.
 * 
 * @param node the element
 */ __turbopack_context__.s([
    "default",
    ()=>ownerDocument
]);
function ownerDocument(node) {
    return node && node.ownerDocument || document;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerWindow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ownerWindow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerDocument.js [app-client] (ecmascript)");
;
function ownerWindow(node) {
    var doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node);
    return doc && doc.defaultView || window;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/getComputedStyle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getComputedStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerWindow.js [app-client] (ecmascript)");
;
function getComputedStyle(node, psuedoElement) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node).getComputedStyle(node, psuedoElement);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hyphenate.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>hyphenate
]);
var rUpper = /([A-Z])/g;
function hyphenate(string) {
    return string.replace(rUpper, '-$1').toLowerCase();
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hyphenateStyle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Copyright 2013-2014, Facebook, Inc.
 * All rights reserved.
 * https://github.com/facebook/react/blob/2aeb8a2a6beb00617a4217f7f8284924fa2ad819/src/vendor/core/hyphenateStyleName.js
 */ __turbopack_context__.s([
    "default",
    ()=>hyphenateStyleName
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hyphenate.js [app-client] (ecmascript)");
;
var msPattern = /^ms-/;
function hyphenateStyleName(string) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string).replace(msPattern, '-ms-');
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/isTransform.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isTransform
]);
var supportedTransforms = /^((translate|rotate|scale)(X|Y|Z|3d)?|matrix(3d)?|perspective|skew(X|Y)?)$/i;
function isTransform(value) {
    return !!(value && supportedTransforms.test(value));
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$getComputedStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/getComputedStyle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenateStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hyphenateStyle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$isTransform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/isTransform.js [app-client] (ecmascript)");
;
;
;
function style(node, property) {
    var css = '';
    var transforms = '';
    if (typeof property === 'string') {
        return node.style.getPropertyValue((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenateStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(property)) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$getComputedStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node).getPropertyValue((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenateStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(property));
    }
    Object.keys(property).forEach(function(key) {
        var value = property[key];
        if (!value && value !== 0) {
            node.style.removeProperty((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenateStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(key));
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$isTransform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(key)) {
            transforms += key + "(" + value + ") ";
        } else {
            css += (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hyphenateStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(key) + ": " + value + ";";
        }
    });
    if (transforms) {
        css += "transform: " + transforms + ";";
    }
    node.style.cssText += ";" + css;
}
const __TURBOPACK__default__export__ = style;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time truthy", 1) {
    (function() {
        'use strict';
        // The Symbol used to tag the ReactElement-like types. If there is no native Symbol
        // nor polyfill, then a plain number is used for performance.
        var hasSymbol = typeof Symbol === 'function' && Symbol.for;
        var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
        var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
        var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
        var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
        var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
        var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
        var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
        // (unstable) APIs that have been removed. Can we remove the symbols?
        var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
        var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
        var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
        var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
        var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
        var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
        var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
        var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
        var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
        var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
        var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;
        function isValidElementType(type) {
            return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
            type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
        }
        function typeOf(object) {
            if (typeof object === 'object' && object !== null) {
                var $$typeof = object.$$typeof;
                switch($$typeof){
                    case REACT_ELEMENT_TYPE:
                        var type = object.type;
                        switch(type){
                            case REACT_ASYNC_MODE_TYPE:
                            case REACT_CONCURRENT_MODE_TYPE:
                            case REACT_FRAGMENT_TYPE:
                            case REACT_PROFILER_TYPE:
                            case REACT_STRICT_MODE_TYPE:
                            case REACT_SUSPENSE_TYPE:
                                return type;
                            default:
                                var $$typeofType = type && type.$$typeof;
                                switch($$typeofType){
                                    case REACT_CONTEXT_TYPE:
                                    case REACT_FORWARD_REF_TYPE:
                                    case REACT_LAZY_TYPE:
                                    case REACT_MEMO_TYPE:
                                    case REACT_PROVIDER_TYPE:
                                        return $$typeofType;
                                    default:
                                        return $$typeof;
                                }
                        }
                    case REACT_PORTAL_TYPE:
                        return $$typeof;
                }
            }
            return undefined;
        } // AsyncMode is deprecated along with isAsyncMode
        var AsyncMode = REACT_ASYNC_MODE_TYPE;
        var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
        var ContextConsumer = REACT_CONTEXT_TYPE;
        var ContextProvider = REACT_PROVIDER_TYPE;
        var Element = REACT_ELEMENT_TYPE;
        var ForwardRef = REACT_FORWARD_REF_TYPE;
        var Fragment = REACT_FRAGMENT_TYPE;
        var Lazy = REACT_LAZY_TYPE;
        var Memo = REACT_MEMO_TYPE;
        var Portal = REACT_PORTAL_TYPE;
        var Profiler = REACT_PROFILER_TYPE;
        var StrictMode = REACT_STRICT_MODE_TYPE;
        var Suspense = REACT_SUSPENSE_TYPE;
        var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated
        function isAsyncMode(object) {
            {
                if (!hasWarnedAboutDeprecatedIsAsyncMode) {
                    hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint
                    console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
                }
            }
            return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
        }
        function isConcurrentMode(object) {
            return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
        }
        function isContextConsumer(object) {
            return typeOf(object) === REACT_CONTEXT_TYPE;
        }
        function isContextProvider(object) {
            return typeOf(object) === REACT_PROVIDER_TYPE;
        }
        function isElement(object) {
            return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        function isForwardRef(object) {
            return typeOf(object) === REACT_FORWARD_REF_TYPE;
        }
        function isFragment(object) {
            return typeOf(object) === REACT_FRAGMENT_TYPE;
        }
        function isLazy(object) {
            return typeOf(object) === REACT_LAZY_TYPE;
        }
        function isMemo(object) {
            return typeOf(object) === REACT_MEMO_TYPE;
        }
        function isPortal(object) {
            return typeOf(object) === REACT_PORTAL_TYPE;
        }
        function isProfiler(object) {
            return typeOf(object) === REACT_PROFILER_TYPE;
        }
        function isStrictMode(object) {
            return typeOf(object) === REACT_STRICT_MODE_TYPE;
        }
        function isSuspense(object) {
            return typeOf(object) === REACT_SUSPENSE_TYPE;
        }
        exports.AsyncMode = AsyncMode;
        exports.ConcurrentMode = ConcurrentMode;
        exports.ContextConsumer = ContextConsumer;
        exports.ContextProvider = ContextProvider;
        exports.Element = Element;
        exports.ForwardRef = ForwardRef;
        exports.Fragment = Fragment;
        exports.Lazy = Lazy;
        exports.Memo = Memo;
        exports.Portal = Portal;
        exports.Profiler = Profiler;
        exports.StrictMode = StrictMode;
        exports.Suspense = Suspense;
        exports.isAsyncMode = isAsyncMode;
        exports.isConcurrentMode = isConcurrentMode;
        exports.isContextConsumer = isContextConsumer;
        exports.isContextProvider = isContextProvider;
        exports.isElement = isElement;
        exports.isForwardRef = isForwardRef;
        exports.isFragment = isFragment;
        exports.isLazy = isLazy;
        exports.isMemo = isMemo;
        exports.isPortal = isPortal;
        exports.isProfiler = isProfiler;
        exports.isStrictMode = isStrictMode;
        exports.isSuspense = isSuspense;
        exports.isValidElementType = isValidElementType;
        exports.typeOf = typeOf;
    })();
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-is/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)");
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var assign = Object.assign.bind(Object);
module.exports = assign;
module.exports.default = module.exports; //# sourceMappingURL=object-assign.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';
module.exports = ReactPropTypesSecret;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/has.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = Function.call.bind(Object.prototype.hasOwnProperty);
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/checkPropTypes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
var printWarning = function() {};
if ("TURBOPACK compile-time truthy", 1) {
    var ReactPropTypesSecret = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)");
    var loggedTypeFailures = {};
    var has = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/has.js [app-client] (ecmascript)");
    printWarning = function(text) {
        var message = 'Warning: ' + text;
        if (typeof console !== 'undefined') {
            console.error(message);
        }
        try {
            // --- Welcome to debugging React ---
            // This error was thrown as a convenience so that you can use this stack
            // to find the callsite that caused this warning to fire.
            throw new Error(message);
        } catch (x) {}
    };
}
/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */ function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
    if ("TURBOPACK compile-time truthy", 1) {
        for(var typeSpecName in typeSpecs){
            if (has(typeSpecs, typeSpecName)) {
                var error;
                // Prop type validation may throw. In case they do, we don't want to
                // fail the render phase where it didn't fail before. So we log it.
                // After these have been cleaned up, we'll let them throw.
                try {
                    // This is intentionally an invariant that gets caught. It's the same
                    // behavior as without this statement except with a better message.
                    if (typeof typeSpecs[typeSpecName] !== 'function') {
                        var err = Error((componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' + 'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.');
                        err.name = 'Invariant Violation';
                        throw err;
                    }
                    error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
                } catch (ex) {
                    error = ex;
                }
                if (error && !(error instanceof Error)) {
                    printWarning((componentName || 'React class') + ': type specification of ' + location + ' `' + typeSpecName + '` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a ' + typeof error + '. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).');
                }
                if (error instanceof Error && !(error.message in loggedTypeFailures)) {
                    // Only monitor this failure once because there tends to be a lot of the
                    // same error.
                    loggedTypeFailures[error.message] = true;
                    var stack = getStack ? getStack() : '';
                    printWarning('Failed ' + location + ' type: ' + error.message + (stack != null ? stack : ''));
                }
            }
        }
    }
}
/**
 * Resets warning cache when testing.
 *
 * @private
 */ checkPropTypes.resetWarningCache = function() {
    if (("TURBOPACK compile-time value", "development") !== 'production') {
        loggedTypeFailures = {};
    }
};
module.exports = checkPropTypes;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/factoryWithTypeCheckers.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
var ReactIs = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-is/index.js [app-client] (ecmascript)");
var assign = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)");
var ReactPropTypesSecret = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)");
var has = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/lib/has.js [app-client] (ecmascript)");
var checkPropTypes = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/checkPropTypes.js [app-client] (ecmascript)");
var printWarning = function() {};
if ("TURBOPACK compile-time truthy", 1) {
    printWarning = function(text) {
        var message = 'Warning: ' + text;
        if (typeof console !== 'undefined') {
            console.error(message);
        }
        try {
            // --- Welcome to debugging React ---
            // This error was thrown as a convenience so that you can use this stack
            // to find the callsite that caused this warning to fire.
            throw new Error(message);
        } catch (x) {}
    };
}
function emptyFunctionThatReturnsNull() {
    return null;
}
module.exports = function(isValidElement, throwOnDirectAccess) {
    /* global Symbol */ var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
    var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.
    /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */ function getIteratorFn(maybeIterable) {
        var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
        if (typeof iteratorFn === 'function') {
            return iteratorFn;
        }
    }
    /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */ var ANONYMOUS = '<<anonymous>>';
    // Important!
    // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
    var ReactPropTypes = {
        array: createPrimitiveTypeChecker('array'),
        bigint: createPrimitiveTypeChecker('bigint'),
        bool: createPrimitiveTypeChecker('boolean'),
        func: createPrimitiveTypeChecker('function'),
        number: createPrimitiveTypeChecker('number'),
        object: createPrimitiveTypeChecker('object'),
        string: createPrimitiveTypeChecker('string'),
        symbol: createPrimitiveTypeChecker('symbol'),
        any: createAnyTypeChecker(),
        arrayOf: createArrayOfTypeChecker,
        element: createElementTypeChecker(),
        elementType: createElementTypeTypeChecker(),
        instanceOf: createInstanceTypeChecker,
        node: createNodeChecker(),
        objectOf: createObjectOfTypeChecker,
        oneOf: createEnumTypeChecker,
        oneOfType: createUnionTypeChecker,
        shape: createShapeTypeChecker,
        exact: createStrictShapeTypeChecker
    };
    /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */ /*eslint-disable no-self-compare*/ function is(x, y) {
        // SameValue algorithm
        if (x === y) {
            // Steps 1-5, 7-10
            // Steps 6.b-6.e: +0 != -0
            return x !== 0 || 1 / x === 1 / y;
        } else {
            // Step 6.a: NaN == NaN
            return x !== x && y !== y;
        }
    }
    /*eslint-enable no-self-compare*/ /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */ function PropTypeError(message, data) {
        this.message = message;
        this.data = data && typeof data === 'object' ? data : {};
        this.stack = '';
    }
    // Make `instanceof Error` still work for returned errors.
    PropTypeError.prototype = Error.prototype;
    function createChainableTypeChecker(validate) {
        if (("TURBOPACK compile-time value", "development") !== 'production') {
            var manualPropTypeCallCache = {};
            var manualPropTypeWarningCount = 0;
        }
        function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
            componentName = componentName || ANONYMOUS;
            propFullName = propFullName || propName;
            if (secret !== ReactPropTypesSecret) {
                if (throwOnDirectAccess) {
                    // New behavior only for users of `prop-types` package
                    var err = new Error('Calling PropTypes validators directly is not supported by the `prop-types` package. ' + 'Use `PropTypes.checkPropTypes()` to call them. ' + 'Read more at http://fb.me/use-check-prop-types');
                    err.name = 'Invariant Violation';
                    throw err;
                } else if (("TURBOPACK compile-time value", "development") !== 'production' && typeof console !== 'undefined') {
                    // Old behavior for people using React.PropTypes
                    var cacheKey = componentName + ':' + propName;
                    if (!manualPropTypeCallCache[cacheKey] && // Avoid spamming the console because they are often not actionable except for lib authors
                    manualPropTypeWarningCount < 3) {
                        printWarning('You are manually calling a React.PropTypes validation ' + 'function for the `' + propFullName + '` prop on `' + componentName + '`. This is deprecated ' + 'and will throw in the standalone `prop-types` package. ' + 'You may be seeing this warning due to a third-party PropTypes ' + 'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.');
                        manualPropTypeCallCache[cacheKey] = true;
                        manualPropTypeWarningCount++;
                    }
                }
            }
            if (props[propName] == null) {
                if (isRequired) {
                    if (props[propName] === null) {
                        return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
                    }
                    return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
                }
                return null;
            } else {
                return validate(props, propName, componentName, location, propFullName);
            }
        }
        var chainedCheckType = checkType.bind(null, false);
        chainedCheckType.isRequired = checkType.bind(null, true);
        return chainedCheckType;
    }
    function createPrimitiveTypeChecker(expectedType) {
        function validate(props, propName, componentName, location, propFullName, secret) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== expectedType) {
                // `propValue` being instance of, say, date/regexp, pass the 'object'
                // check, but we can offer a more precise error message here rather than
                // 'of type `object`'.
                var preciseType = getPreciseType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'), {
                    expectedType: expectedType
                });
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createAnyTypeChecker() {
        return createChainableTypeChecker(emptyFunctionThatReturnsNull);
    }
    function createArrayOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
            if (typeof typeChecker !== 'function') {
                return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
            }
            var propValue = props[propName];
            if (!Array.isArray(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
            }
            for(var i = 0; i < propValue.length; i++){
                var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
                if (error instanceof Error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createElementTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            if (!isValidElement(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createElementTypeTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            if (!ReactIs.isValidElementType(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createInstanceTypeChecker(expectedClass) {
        function validate(props, propName, componentName, location, propFullName) {
            if (!(props[propName] instanceof expectedClass)) {
                var expectedClassName = expectedClass.name || ANONYMOUS;
                var actualClassName = getClassName(props[propName]);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createEnumTypeChecker(expectedValues) {
        if (!Array.isArray(expectedValues)) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (arguments.length > 1) {
                    printWarning('Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' + 'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).');
                } else {
                    printWarning('Invalid argument supplied to oneOf, expected an array.');
                }
            }
            return emptyFunctionThatReturnsNull;
        }
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            for(var i = 0; i < expectedValues.length; i++){
                if (is(propValue, expectedValues[i])) {
                    return null;
                }
            }
            var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
                var type = getPreciseType(value);
                if (type === 'symbol') {
                    return String(value);
                }
                return value;
            });
            return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
        }
        return createChainableTypeChecker(validate);
    }
    function createObjectOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
            if (typeof typeChecker !== 'function') {
                return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
            }
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
            }
            for(var key in propValue){
                if (has(propValue, key)) {
                    var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                    if (error instanceof Error) {
                        return error;
                    }
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createUnionTypeChecker(arrayOfTypeCheckers) {
        if (!Array.isArray(arrayOfTypeCheckers)) {
            ("TURBOPACK compile-time truthy", 1) ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : "TURBOPACK unreachable";
            return emptyFunctionThatReturnsNull;
        }
        for(var i = 0; i < arrayOfTypeCheckers.length; i++){
            var checker = arrayOfTypeCheckers[i];
            if (typeof checker !== 'function') {
                printWarning('Invalid argument supplied to oneOfType. Expected an array of check functions, but ' + 'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.');
                return emptyFunctionThatReturnsNull;
            }
        }
        function validate(props, propName, componentName, location, propFullName) {
            var expectedTypes = [];
            for(var i = 0; i < arrayOfTypeCheckers.length; i++){
                var checker = arrayOfTypeCheckers[i];
                var checkerResult = checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
                if (checkerResult == null) {
                    return null;
                }
                if (checkerResult.data && has(checkerResult.data, 'expectedType')) {
                    expectedTypes.push(checkerResult.data.expectedType);
                }
            }
            var expectedTypesMessage = expectedTypes.length > 0 ? ', expected one of type [' + expectedTypes.join(', ') + ']' : '';
            return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`' + expectedTypesMessage + '.'));
        }
        return createChainableTypeChecker(validate);
    }
    function createNodeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            if (!isNode(props[propName])) {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function invalidValidatorError(componentName, location, propFullName, key, type) {
        return new PropTypeError((componentName || 'React class') + ': ' + location + ' type `' + propFullName + '.' + key + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + type + '`.');
    }
    function createShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
            }
            for(var key in shapeTypes){
                var checker = shapeTypes[key];
                if (typeof checker !== 'function') {
                    return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
                }
                var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                if (error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createStrictShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
            }
            // We need to check all keys in case some are required but missing from props.
            var allKeys = assign({}, props[propName], shapeTypes);
            for(var key in allKeys){
                var checker = shapeTypes[key];
                if (has(shapeTypes, key) && typeof checker !== 'function') {
                    return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
                }
                if (!checker) {
                    return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' + '\nBad object: ' + JSON.stringify(props[propName], null, '  ') + '\nValid keys: ' + JSON.stringify(Object.keys(shapeTypes), null, '  '));
                }
                var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                if (error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function isNode(propValue) {
        switch(typeof propValue){
            case 'number':
            case 'string':
            case 'undefined':
                return true;
            case 'boolean':
                return !propValue;
            case 'object':
                if (Array.isArray(propValue)) {
                    return propValue.every(isNode);
                }
                if (propValue === null || isValidElement(propValue)) {
                    return true;
                }
                var iteratorFn = getIteratorFn(propValue);
                if (iteratorFn) {
                    var iterator = iteratorFn.call(propValue);
                    var step;
                    if (iteratorFn !== propValue.entries) {
                        while(!(step = iterator.next()).done){
                            if (!isNode(step.value)) {
                                return false;
                            }
                        }
                    } else {
                        // Iterator will provide entry [k,v] tuples rather than values.
                        while(!(step = iterator.next()).done){
                            var entry = step.value;
                            if (entry) {
                                if (!isNode(entry[1])) {
                                    return false;
                                }
                            }
                        }
                    }
                } else {
                    return false;
                }
                return true;
            default:
                return false;
        }
    }
    function isSymbol(propType, propValue) {
        // Native Symbol.
        if (propType === 'symbol') {
            return true;
        }
        // falsy value can't be a Symbol
        if (!propValue) {
            return false;
        }
        // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
        if (propValue['@@toStringTag'] === 'Symbol') {
            return true;
        }
        // Fallback for non-spec compliant Symbols which are polyfilled.
        if (typeof Symbol === 'function' && propValue instanceof Symbol) {
            return true;
        }
        return false;
    }
    // Equivalent of `typeof` but with special handling for array and regexp.
    function getPropType(propValue) {
        var propType = typeof propValue;
        if (Array.isArray(propValue)) {
            return 'array';
        }
        if (propValue instanceof RegExp) {
            // Old webkits (at least until Android 4.0) return 'function' rather than
            // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
            // passes PropTypes.object.
            return 'object';
        }
        if (isSymbol(propType, propValue)) {
            return 'symbol';
        }
        return propType;
    }
    // This handles more types than `getPropType`. Only used for error messages.
    // See `createPrimitiveTypeChecker`.
    function getPreciseType(propValue) {
        if (typeof propValue === 'undefined' || propValue === null) {
            return '' + propValue;
        }
        var propType = getPropType(propValue);
        if (propType === 'object') {
            if (propValue instanceof Date) {
                return 'date';
            } else if (propValue instanceof RegExp) {
                return 'regexp';
            }
        }
        return propType;
    }
    // Returns a string that is postfixed to a warning about an invalid type.
    // For example, "undefined" or "of type array"
    function getPostfixForTypeWarning(value) {
        var type = getPreciseType(value);
        switch(type){
            case 'array':
            case 'object':
                return 'an ' + type;
            case 'boolean':
            case 'date':
            case 'regexp':
                return 'a ' + type;
            default:
                return type;
        }
    }
    // Returns class name of the object, if any.
    function getClassName(propValue) {
        if (!propValue.constructor || !propValue.constructor.name) {
            return ANONYMOUS;
        }
        return propValue.constructor.name;
    }
    ReactPropTypes.checkPropTypes = checkPropTypes;
    ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
    ReactPropTypes.PropTypes = ReactPropTypes;
    return ReactPropTypes;
};
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
if ("TURBOPACK compile-time truthy", 1) {
    var ReactIs = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-is/index.js [app-client] (ecmascript)");
    // By explicitly using `prop-types` you are opting into new development behavior.
    // http://fb.me/prop-types-in-prod
    var throwOnDirectAccess = true;
    module.exports = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/factoryWithTypeCheckers.js [app-client] (ecmascript)")(ReactIs.isElement, throwOnDirectAccess);
} else //TURBOPACK unreachable
;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = {
    disabled: false
};
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/utils/PropTypes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "classNamesShape",
    ()=>classNamesShape,
    "timeoutsShape",
    ()=>timeoutsShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/index.js [app-client] (ecmascript)");
;
var timeoutsShape = ("TURBOPACK compile-time truthy", 1) ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    }).isRequired
]) : "TURBOPACK unreachable";
var classNamesShape = ("TURBOPACK compile-time truthy", 1) ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        active: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        enterDone: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        enterActive: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        exitDone: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        exitActive: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    })
]) : "TURBOPACK unreachable";
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/TransitionGroupContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/utils/reflow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "forceReflow",
    ()=>forceReflow
]);
var forceReflow = function forceReflow(node) {
    return node.scrollTop;
};
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ENTERED",
    ()=>ENTERED,
    "ENTERING",
    ()=>ENTERING,
    "EXITED",
    ()=>EXITED,
    "EXITING",
    ()=>EXITING,
    "UNMOUNTED",
    ()=>UNMOUNTED,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@babel/runtime/helpers/esm/inheritsLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$utils$2f$PropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/utils/PropTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$TransitionGroupContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/TransitionGroupContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$utils$2f$reflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/utils/reflow.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
var UNMOUNTED = 'unmounted';
var EXITED = 'exited';
var ENTERING = 'entering';
var ENTERED = 'entered';
var EXITING = 'exiting';
/**
 * The Transition component lets you describe a transition from one component
 * state to another _over time_ with a simple declarative API. Most commonly
 * it's used to animate the mounting and unmounting of a component, but can also
 * be used to describe in-place transition states as well.
 *
 * ---
 *
 * **Note**: `Transition` is a platform-agnostic base component. If you're using
 * transitions in CSS, you'll probably want to use
 * [`CSSTransition`](https://reactcommunity.org/react-transition-group/css-transition)
 * instead. It inherits all the features of `Transition`, but contains
 * additional features necessary to play nice with CSS transitions (hence the
 * name of the component).
 *
 * ---
 *
 * By default the `Transition` component does not alter the behavior of the
 * component it renders, it only tracks "enter" and "exit" states for the
 * components. It's up to you to give meaning and effect to those states. For
 * example we can add styles to a component when it enters or exits:
 *
 * ```jsx
 * import { Transition } from 'react-transition-group';
 *
 * const duration = 300;
 *
 * const defaultStyle = {
 *   transition: `opacity ${duration}ms ease-in-out`,
 *   opacity: 0,
 * }
 *
 * const transitionStyles = {
 *   entering: { opacity: 1 },
 *   entered:  { opacity: 1 },
 *   exiting:  { opacity: 0 },
 *   exited:  { opacity: 0 },
 * };
 *
 * const Fade = ({ in: inProp }) => (
 *   <Transition in={inProp} timeout={duration}>
 *     {state => (
 *       <div style={{
 *         ...defaultStyle,
 *         ...transitionStyles[state]
 *       }}>
 *         I'm a fade Transition!
 *       </div>
 *     )}
 *   </Transition>
 * );
 * ```
 *
 * There are 4 main states a Transition can be in:
 *  - `'entering'`
 *  - `'entered'`
 *  - `'exiting'`
 *  - `'exited'`
 *
 * Transition state is toggled via the `in` prop. When `true` the component
 * begins the "Enter" stage. During this stage, the component will shift from
 * its current transition state, to `'entering'` for the duration of the
 * transition and then to the `'entered'` stage once it's complete. Let's take
 * the following example (we'll use the
 * [useState](https://reactjs.org/docs/hooks-reference.html#usestate) hook):
 *
 * ```jsx
 * function App() {
 *   const [inProp, setInProp] = useState(false);
 *   return (
 *     <div>
 *       <Transition in={inProp} timeout={500}>
 *         {state => (
 *           // ...
 *         )}
 *       </Transition>
 *       <button onClick={() => setInProp(true)}>
 *         Click to Enter
 *       </button>
 *     </div>
 *   );
 * }
 * ```
 *
 * When the button is clicked the component will shift to the `'entering'` state
 * and stay there for 500ms (the value of `timeout`) before it finally switches
 * to `'entered'`.
 *
 * When `in` is `false` the same thing happens except the state moves from
 * `'exiting'` to `'exited'`.
 */ var Transition = /*#__PURE__*/ function(_React$Component) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Transition, _React$Component);
    function Transition(props, context) {
        var _this;
        _this = _React$Component.call(this, props, context) || this;
        var parentGroup = context; // In the context of a TransitionGroup all enters are really appears
        var appear = parentGroup && !parentGroup.isMounting ? props.enter : props.appear;
        var initialStatus;
        _this.appearStatus = null;
        if (props.in) {
            if (appear) {
                initialStatus = EXITED;
                _this.appearStatus = ENTERING;
            } else {
                initialStatus = ENTERED;
            }
        } else {
            if (props.unmountOnExit || props.mountOnEnter) {
                initialStatus = UNMOUNTED;
            } else {
                initialStatus = EXITED;
            }
        }
        _this.state = {
            status: initialStatus
        };
        _this.nextCallback = null;
        return _this;
    }
    Transition.getDerivedStateFromProps = function getDerivedStateFromProps(_ref, prevState) {
        var nextIn = _ref.in;
        if (nextIn && prevState.status === UNMOUNTED) {
            return {
                status: EXITED
            };
        }
        return null;
    } // getSnapshotBeforeUpdate(prevProps) {
    ;
    var _proto = Transition.prototype;
    _proto.componentDidMount = function componentDidMount() {
        this.updateStatus(true, this.appearStatus);
    };
    _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
        var nextStatus = null;
        if (prevProps !== this.props) {
            var status = this.state.status;
            if (this.props.in) {
                if (status !== ENTERING && status !== ENTERED) {
                    nextStatus = ENTERING;
                }
            } else {
                if (status === ENTERING || status === ENTERED) {
                    nextStatus = EXITING;
                }
            }
        }
        this.updateStatus(false, nextStatus);
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
        this.cancelNextCallback();
    };
    _proto.getTimeouts = function getTimeouts() {
        var timeout = this.props.timeout;
        var exit, enter, appear;
        exit = enter = appear = timeout;
        if (timeout != null && typeof timeout !== 'number') {
            exit = timeout.exit;
            enter = timeout.enter; // TODO: remove fallback for next major
            appear = timeout.appear !== undefined ? timeout.appear : enter;
        }
        return {
            exit: exit,
            enter: enter,
            appear: appear
        };
    };
    _proto.updateStatus = function updateStatus(mounting, nextStatus) {
        if (mounting === void 0) {
            mounting = false;
        }
        if (nextStatus !== null) {
            // nextStatus will always be ENTERING or EXITING.
            this.cancelNextCallback();
            if (nextStatus === ENTERING) {
                if (this.props.unmountOnExit || this.props.mountOnEnter) {
                    var node = this.props.nodeRef ? this.props.nodeRef.current : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].findDOMNode(this); // https://github.com/reactjs/react-transition-group/pull/749
                    // With unmountOnExit or mountOnEnter, the enter animation should happen at the transition between `exited` and `entering`.
                    // To make the animation happen,  we have to separate each rendering and avoid being processed as batched.
                    if (node) (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$utils$2f$reflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forceReflow"])(node);
                }
                this.performEnter(mounting);
            } else {
                this.performExit();
            }
        } else if (this.props.unmountOnExit && this.state.status === EXITED) {
            this.setState({
                status: UNMOUNTED
            });
        }
    };
    _proto.performEnter = function performEnter(mounting) {
        var _this2 = this;
        var enter = this.props.enter;
        var appearing = this.context ? this.context.isMounting : mounting;
        var _ref2 = this.props.nodeRef ? [
            appearing
        ] : [
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].findDOMNode(this),
            appearing
        ], maybeNode = _ref2[0], maybeAppearing = _ref2[1];
        var timeouts = this.getTimeouts();
        var enterTimeout = appearing ? timeouts.appear : timeouts.enter; // no enter animation skip right to ENTERED
        // if we are mounting and running this it means appear _must_ be set
        if (!mounting && !enter || __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled) {
            this.safeSetState({
                status: ENTERED
            }, function() {
                _this2.props.onEntered(maybeNode);
            });
            return;
        }
        this.props.onEnter(maybeNode, maybeAppearing);
        this.safeSetState({
            status: ENTERING
        }, function() {
            _this2.props.onEntering(maybeNode, maybeAppearing);
            _this2.onTransitionEnd(enterTimeout, function() {
                _this2.safeSetState({
                    status: ENTERED
                }, function() {
                    _this2.props.onEntered(maybeNode, maybeAppearing);
                });
            });
        });
    };
    _proto.performExit = function performExit() {
        var _this3 = this;
        var exit = this.props.exit;
        var timeouts = this.getTimeouts();
        var maybeNode = this.props.nodeRef ? undefined : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].findDOMNode(this); // no exit animation skip right to EXITED
        if (!exit || __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled) {
            this.safeSetState({
                status: EXITED
            }, function() {
                _this3.props.onExited(maybeNode);
            });
            return;
        }
        this.props.onExit(maybeNode);
        this.safeSetState({
            status: EXITING
        }, function() {
            _this3.props.onExiting(maybeNode);
            _this3.onTransitionEnd(timeouts.exit, function() {
                _this3.safeSetState({
                    status: EXITED
                }, function() {
                    _this3.props.onExited(maybeNode);
                });
            });
        });
    };
    _proto.cancelNextCallback = function cancelNextCallback() {
        if (this.nextCallback !== null) {
            this.nextCallback.cancel();
            this.nextCallback = null;
        }
    };
    _proto.safeSetState = function safeSetState(nextState, callback) {
        // This shouldn't be necessary, but there are weird race conditions with
        // setState callbacks and unmounting in testing, so always make sure that
        // we can cancel any pending setState callbacks after we unmount.
        callback = this.setNextCallback(callback);
        this.setState(nextState, callback);
    };
    _proto.setNextCallback = function setNextCallback(callback) {
        var _this4 = this;
        var active = true;
        this.nextCallback = function(event) {
            if (active) {
                active = false;
                _this4.nextCallback = null;
                callback(event);
            }
        };
        this.nextCallback.cancel = function() {
            active = false;
        };
        return this.nextCallback;
    };
    _proto.onTransitionEnd = function onTransitionEnd(timeout, handler) {
        this.setNextCallback(handler);
        var node = this.props.nodeRef ? this.props.nodeRef.current : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].findDOMNode(this);
        var doesNotHaveTimeoutOrListener = timeout == null && !this.props.addEndListener;
        if (!node || doesNotHaveTimeoutOrListener) {
            setTimeout(this.nextCallback, 0);
            return;
        }
        if (this.props.addEndListener) {
            var _ref3 = this.props.nodeRef ? [
                this.nextCallback
            ] : [
                node,
                this.nextCallback
            ], maybeNode = _ref3[0], maybeNextCallback = _ref3[1];
            this.props.addEndListener(maybeNode, maybeNextCallback);
        }
        if (timeout != null) {
            setTimeout(this.nextCallback, timeout);
        }
    };
    _proto.render = function render() {
        var status = this.state.status;
        if (status === UNMOUNTED) {
            return null;
        }
        var _this$props = this.props, children = _this$props.children, _in = _this$props.in, _mountOnEnter = _this$props.mountOnEnter, _unmountOnExit = _this$props.unmountOnExit, _appear = _this$props.appear, _enter = _this$props.enter, _exit = _this$props.exit, _timeout = _this$props.timeout, _addEndListener = _this$props.addEndListener, _onEnter = _this$props.onEnter, _onEntering = _this$props.onEntering, _onEntered = _this$props.onEntered, _onExit = _this$props.onExit, _onExiting = _this$props.onExiting, _onExited = _this$props.onExited, _nodeRef = _this$props.nodeRef, childProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this$props, [
            "children",
            "in",
            "mountOnEnter",
            "unmountOnExit",
            "appear",
            "enter",
            "exit",
            "timeout",
            "addEndListener",
            "onEnter",
            "onEntering",
            "onEntered",
            "onExit",
            "onExiting",
            "onExited",
            "nodeRef"
        ]);
        return(/*#__PURE__*/ // allows for nested Transitions
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$TransitionGroupContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: null
        }, typeof children === 'function' ? children(status, childProps) : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.only(children), childProps)));
    };
    return Transition;
}(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Component);
Transition.contextType = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$TransitionGroupContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Transition.propTypes = ("TURBOPACK compile-time truthy", 1) ? {
    /**
   * A React reference to DOM element that need to transition:
   * https://stackoverflow.com/a/51127130/4671932
   *
   *   - When `nodeRef` prop is used, `node` is not passed to callback functions
   *      (e.g. `onEnter`) because user already has direct access to the node.
   *   - When changing `key` prop of `Transition` in a `TransitionGroup` a new
   *     `nodeRef` need to be provided to `Transition` with changed `key` prop
   *     (see
   *     [test/CSSTransition-test.js](https://github.com/reactjs/react-transition-group/blob/13435f897b3ab71f6e19d724f145596f5910581c/test/CSSTransition-test.js#L362-L437)).
   */ nodeRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        current: typeof Element === 'undefined' ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any : function(propValue, key, componentName, location, propFullName, secret) {
            var value = propValue[key];
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].instanceOf(value && 'ownerDocument' in value ? value.ownerDocument.defaultView.Element : Element)(propValue, key, componentName, location, propFullName, secret);
        }
    }),
    /**
   * A `function` child can be used instead of a React element. This function is
   * called with the current transition status (`'entering'`, `'entered'`,
   * `'exiting'`, `'exited'`), which can be used to apply context
   * specific props to a component.
   *
   * ```jsx
   * <Transition in={this.state.in} timeout={150}>
   *   {state => (
   *     <MyComponent className={`fade fade-${state}`} />
   *   )}
   * </Transition>
   * ```
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].element.isRequired
    ]).isRequired,
    /**
   * Show the component; triggers the enter or exit states
   */ in: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * By default the child component is mounted immediately along with
   * the parent `Transition` component. If you want to "lazy mount" the component on the
   * first `in={true}` you can set `mountOnEnter`. After the first enter transition the component will stay
   * mounted, even on "exited", unless you also specify `unmountOnExit`.
   */ mountOnEnter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * By default the child component stays mounted after it reaches the `'exited'` state.
   * Set `unmountOnExit` if you'd prefer to unmount the component after it finishes exiting.
   */ unmountOnExit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * By default the child component does not perform the enter transition when
   * it first mounts, regardless of the value of `in`. If you want this
   * behavior, set both `appear` and `in` to `true`.
   *
   * > **Note**: there are no special appear states like `appearing`/`appeared`, this prop
   * > only adds an additional enter transition. However, in the
   * > `<CSSTransition>` component that first enter transition does result in
   * > additional `.appear-*` classes, that way you can choose to style it
   * > differently.
   */ appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Enable or disable enter transitions.
   */ enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Enable or disable exit transitions.
   */ exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The duration of the transition, in milliseconds.
   * Required unless `addEndListener` is provided.
   *
   * You may specify a single timeout for all transitions:
   *
   * ```jsx
   * timeout={500}
   * ```
   *
   * or individually:
   *
   * ```jsx
   * timeout={{
   *  appear: 500,
   *  enter: 300,
   *  exit: 500,
   * }}
   * ```
   *
   * - `appear` defaults to the value of `enter`
   * - `enter` defaults to `0`
   * - `exit` defaults to `0`
   *
   * @type {number | { enter?: number, exit?: number, appear?: number }}
   */ timeout: function timeout(props) {
        var pt = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$utils$2f$PropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeoutsShape"];
        if (!props.addEndListener) pt = pt.isRequired;
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        return pt.apply(void 0, [
            props
        ].concat(args));
    },
    /**
   * Add a custom transition end trigger. Called with the transitioning
   * DOM node and a `done` callback. Allows for more fine grained transition end
   * logic. Timeouts are still used as a fallback if provided.
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * ```jsx
   * addEndListener={(node, done) => {
   *   // use the css transitionend event to mark the finish of a transition
   *   node.addEventListener('transitionend', done, false);
   * }}
   * ```
   */ addEndListener: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired before the "entering" status is applied. An extra parameter
   * `isAppearing` is supplied to indicate if the enter stage is occurring on the initial mount
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * @type Function(node: HtmlElement, isAppearing: bool) -> void
   */ onEnter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired after the "entering" status is applied. An extra parameter
   * `isAppearing` is supplied to indicate if the enter stage is occurring on the initial mount
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * @type Function(node: HtmlElement, isAppearing: bool)
   */ onEntering: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired after the "entered" status is applied. An extra parameter
   * `isAppearing` is supplied to indicate if the enter stage is occurring on the initial mount
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * @type Function(node: HtmlElement, isAppearing: bool) -> void
   */ onEntered: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired before the "exiting" status is applied.
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * @type Function(node: HtmlElement) -> void
   */ onExit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired after the "exiting" status is applied.
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed.
   *
   * @type Function(node: HtmlElement) -> void
   */ onExiting: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired after the "exited" status is applied.
   *
   * **Note**: when `nodeRef` prop is passed, `node` is not passed
   *
   * @type Function(node: HtmlElement) -> void
   */ onExited: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
} : "TURBOPACK unreachable"; // Name the function so it is clearer in the documentation
function noop() {}
Transition.defaultProps = {
    in: false,
    mountOnEnter: false,
    unmountOnExit: false,
    appear: false,
    enter: true,
    exit: true,
    onEnter: noop,
    onEntering: noop,
    onEntered: noop,
    onExit: noop,
    onExiting: noop,
    onExited: noop
};
Transition.UNMOUNTED = UNMOUNTED;
Transition.EXITED = EXITED;
Transition.ENTERING = ENTERING;
Transition.ENTERED = ENTERED;
Transition.EXITING = EXITING;
const __TURBOPACK__default__export__ = Transition;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getChildRef",
    ()=>getChildRef,
    "getReactVersion",
    ()=>getReactVersion,
    "isEscKey",
    ()=>isEscKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function isEscKey(e) {
    return e.code === 'Escape' || e.keyCode === 27;
}
function getReactVersion() {
    const parts = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["version"].split('.');
    return {
        major: +parts[0],
        minor: +parts[1],
        patch: +parts[2]
    };
}
function getChildRef(element) {
    if (!element || typeof element === 'function') {
        return null;
    }
    const { major } = getReactVersion();
    const childRef = major >= 19 ? element.props.ref : element.ref;
    return childRef;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/canUseDOM.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = !!(typeof window !== 'undefined' && window.document && window.document.createElement);
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/addEventListener.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable no-return-assign */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "onceSupported",
    ()=>onceSupported,
    "optionsSupported",
    ()=>optionsSupported
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/canUseDOM.js [app-client] (ecmascript)");
;
var optionsSupported = false;
var onceSupported = false;
try {
    var options = {
        get passive () {
            return optionsSupported = true;
        },
        get once () {
            // eslint-disable-next-line no-multi-assign
            return onceSupported = optionsSupported = true;
        }
    };
    if (__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) {
        window.addEventListener('test', options, options);
        window.removeEventListener('test', options, true);
    }
} catch (e) {
/* */ }
/**
 * An `addEventListener` ponyfill, supports the `once` option
 * 
 * @param node the element
 * @param eventName the event name
 * @param handle the handler
 * @param options event options
 */ function addEventListener(node, eventName, handler, options) {
    if (options && typeof options !== 'boolean' && !onceSupported) {
        var once = options.once, capture = options.capture;
        var wrappedHandler = handler;
        if (!onceSupported && once) {
            wrappedHandler = handler.__once || function onceHandler(event) {
                this.removeEventListener(eventName, onceHandler, capture);
                handler.call(this, event);
            };
            handler.__once = wrappedHandler;
        }
        node.addEventListener(eventName, wrappedHandler, optionsSupported ? options : capture);
    }
    node.addEventListener(eventName, handler, options);
}
const __TURBOPACK__default__export__ = addEventListener;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/removeEventListener.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * A `removeEventListener` ponyfill
 * 
 * @param node the element
 * @param eventName the event name
 * @param handle the handler
 * @param options event options
 */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function removeEventListener(node, eventName, handler, options) {
    var capture = options && typeof options !== 'boolean' ? options.capture : options;
    node.removeEventListener(eventName, handler, capture);
    if (handler.__once) {
        node.removeEventListener(eventName, handler.__once, capture);
    }
}
const __TURBOPACK__default__export__ = removeEventListener;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/listen.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$addEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/addEventListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$removeEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/removeEventListener.js [app-client] (ecmascript)");
;
;
function listen(node, eventName, handler, options) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$addEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node, eventName, handler, options);
    return function() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$removeEventListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node, eventName, handler, options);
    };
}
const __TURBOPACK__default__export__ = listen;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/triggerEvent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Triggers an event on a given element.
 * 
 * @param node the element
 * @param eventName the event name to trigger
 * @param bubbles whether the event should bubble up
 * @param cancelable whether the event should be cancelable
 */ __turbopack_context__.s([
    "default",
    ()=>triggerEvent
]);
function triggerEvent(node, eventName, bubbles, cancelable) {
    if (bubbles === void 0) {
        bubbles = false;
    }
    if (cancelable === void 0) {
        cancelable = true;
    }
    if (node) {
        var event = document.createEvent('HTMLEvents');
        event.initEvent(eventName, bubbles, cancelable);
        node.dispatchEvent(event);
    }
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/transitionEnd.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>transitionEnd
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/listen.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$triggerEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/triggerEvent.js [app-client] (ecmascript)");
;
;
;
function parseDuration(node) {
    var str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node, 'transitionDuration') || '';
    var mult = str.indexOf('ms') === -1 ? 1000 : 1;
    return parseFloat(str) * mult;
}
function emulateTransitionEnd(element, duration, padding) {
    if (padding === void 0) {
        padding = 5;
    }
    var called = false;
    var handle = setTimeout(function() {
        if (!called) (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$triggerEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, 'transitionend', true);
    }, duration + padding);
    var remove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, 'transitionend', function() {
        called = true;
    }, {
        once: true
    });
    return function() {
        clearTimeout(handle);
        remove();
    };
}
function transitionEnd(element, handler, duration, padding) {
    if (duration == null) duration = parseDuration(element) || 0;
    var removeEmulate = emulateTransitionEnd(element, duration, padding);
    var remove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, 'transitionend', handler);
    return function() {
        removeEmulate();
        remove();
    };
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/transitionEndListener.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>transitionEndListener
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$transitionEnd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/transitionEnd.js [app-client] (ecmascript)");
;
;
function parseDuration(node, property) {
    const str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node, property) || '';
    const mult = str.indexOf('ms') === -1 ? 1000 : 1;
    return parseFloat(str) * mult;
}
function transitionEndListener(element, handler) {
    const duration = parseDuration(element, 'transitionDuration');
    const delay = parseDuration(element, 'transitionDelay');
    const remove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$transitionEnd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, (e)=>{
        if (e.target === element) {
            remove();
            handler(e);
        }
    }, duration + delay);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/createChainedFunction.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Safe chained function
 *
 * Will only create a new function if needed,
 * otherwise will pass back existing functions or null.
 *
 * @param {function} functions to chain
 * @returns {function|null}
 */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function createChainedFunction(...funcs) {
    return funcs.filter((f)=>f != null).reduce((acc, f)=>{
        if (typeof f !== 'function') {
            throw new Error('Invalid Argument Type, must only provide functions, undefined, or null.');
        }
        if (acc === null) return f;
        return function chainedFunction(...args) {
            // @ts-expect-error ignore "this" error
            acc.apply(this, args);
            // @ts-expect-error ignore "this" error
            f.apply(this, args);
        };
    }, null);
}
const __TURBOPACK__default__export__ = createChainedFunction;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/triggerBrowserReflow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// reading a dimension prop will cause the browser to recalculate,
// which will let our animations work
__turbopack_context__.s([
    "default",
    ()=>triggerBrowserReflow
]);
function triggerBrowserReflow(node) {
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    node.offsetHeight;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "mergeRefs",
    ()=>mergeRefs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const toFnRef = (ref)=>!ref || typeof ref === 'function' ? ref : (value)=>{
        ref.current = value;
    };
function mergeRefs(refA, refB) {
    const a = toFnRef(refA);
    const b = toFnRef(refB);
    return (value)=>{
        if (a) a(value);
        if (b) b(value);
    };
}
/**
 * Create and returns a single callback ref composed from two other Refs.
 *
 * ```tsx
 * const Button = React.forwardRef((props, ref) => {
 *   const [element, attachRef] = useCallbackRef<HTMLButtonElement>();
 *   const mergedRef = useMergedRefs(ref, attachRef);
 *
 *   return <button ref={mergedRef} {...props}/>
 * })
 * ```
 *
 * @param refA A Callback or mutable Ref
 * @param refB A Callback or mutable Ref
 * @category refs
 */ function useMergedRefs(refA, refB) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useMergedRefs.useMemo": ()=>mergeRefs(refA, refB)
    }["useMergedRefs.useMemo"], [
        refA,
        refB
    ]);
}
const __TURBOPACK__default__export__ = useMergedRefs;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/safeFindDOMNode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>safeFindDOMNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
function safeFindDOMNode(componentOrElement) {
    if (componentOrElement && 'setState' in componentOrElement) {
        // TODO: Remove in next major.
        // eslint-disable-next-line react/no-find-dom-node
        return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].findDOMNode(componentOrElement);
    }
    return componentOrElement != null ? componentOrElement : null;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/TransitionWrapper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$safeFindDOMNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/safeFindDOMNode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
// Normalizes Transition callbacks when nodeRef is used.
const TransitionWrapper = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(({ onEnter, onEntering, onEntered, onExit, onExiting, onExited, addEndListener, children, childRef, ...props }, ref)=>{
    const nodeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nodeRef, childRef);
    const attachRef = (r)=>{
        mergedRef((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$safeFindDOMNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(r));
    };
    const normalize = (callback)=>(param)=>{
            if (callback && nodeRef.current) {
                callback(nodeRef.current, param);
            }
        };
    const handleEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEnter), [
        onEnter
    ]);
    const handleEntering = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEntering), [
        onEntering
    ]);
    const handleEntered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEntered), [
        onEntered
    ]);
    const handleExit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExit), [
        onExit
    ]);
    const handleExiting = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExiting), [
        onExiting
    ]);
    const handleExited = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExited), [
        onExited
    ]);
    const handleAddEndListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(addEndListener), [
        addEndListener
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        ...props,
        onEnter: handleEnter,
        onEntered: handleEntered,
        onEntering: handleEntering,
        onExit: handleExit,
        onExited: handleExited,
        onExiting: handleExiting,
        addEndListener: handleAddEndListener,
        nodeRef: nodeRef,
        children: typeof children === 'function' ? (status, innerProps)=>// TODO: Types for RTG missing innerProps, so need to cast.
            children(status, {
                ...innerProps,
                ref: attachRef
            }) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(children, {
            ref: attachRef
        })
    });
});
TransitionWrapper.displayName = 'TransitionWrapper';
const __TURBOPACK__default__export__ = TransitionWrapper;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Collapse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/transitionEndListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/createChainedFunction.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$triggerBrowserReflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/triggerBrowserReflow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/TransitionWrapper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const MARGINS = {
    height: [
        'marginTop',
        'marginBottom'
    ],
    width: [
        'marginLeft',
        'marginRight'
    ]
};
function getDefaultDimensionValue(dimension, elem) {
    const offset = `offset${dimension[0].toUpperCase()}${dimension.slice(1)}`;
    const value = elem[offset];
    const margins = MARGINS[dimension];
    return value + // @ts-expect-error TODO
    parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(elem, margins[0]), 10) + // @ts-expect-error TODO
    parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(elem, margins[1]), 10);
}
const collapseStyles = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXITED"]]: 'collapse',
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXITING"]]: 'collapsing',
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERING"]]: 'collapsing',
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERED"]]: 'collapse show'
};
const Collapse = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(({ onEnter, onEntering, onEntered, onExit, onExiting, className, children, dimension = 'height', in: inProp = false, timeout = 300, mountOnEnter = false, unmountOnExit = false, appear = false, getDimensionValue = getDefaultDimensionValue, ...props }, ref)=>{
    /* Compute dimension */ const computedDimension = typeof dimension === 'function' ? dimension() : dimension;
    /* -- Expanding -- */ const handleEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapse.useMemo[handleEnter]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Collapse.useMemo[handleEnter]": (elem)=>{
                    elem.style[computedDimension] = '0';
                }
            }["Collapse.useMemo[handleEnter]"], onEnter)
    }["Collapse.useMemo[handleEnter]"], [
        computedDimension,
        onEnter
    ]);
    const handleEntering = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapse.useMemo[handleEntering]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Collapse.useMemo[handleEntering]": (elem)=>{
                    const scroll = `scroll${computedDimension[0].toUpperCase()}${computedDimension.slice(1)}`;
                    elem.style[computedDimension] = `${elem[scroll]}px`;
                }
            }["Collapse.useMemo[handleEntering]"], onEntering)
    }["Collapse.useMemo[handleEntering]"], [
        computedDimension,
        onEntering
    ]);
    const handleEntered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapse.useMemo[handleEntered]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Collapse.useMemo[handleEntered]": (elem)=>{
                    elem.style[computedDimension] = null;
                }
            }["Collapse.useMemo[handleEntered]"], onEntered)
    }["Collapse.useMemo[handleEntered]"], [
        computedDimension,
        onEntered
    ]);
    /* -- Collapsing -- */ const handleExit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapse.useMemo[handleExit]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Collapse.useMemo[handleExit]": (elem)=>{
                    elem.style[computedDimension] = `${getDimensionValue(computedDimension, elem)}px`;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$triggerBrowserReflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(elem);
                }
            }["Collapse.useMemo[handleExit]"], onExit)
    }["Collapse.useMemo[handleExit]"], [
        onExit,
        getDimensionValue,
        computedDimension
    ]);
    const handleExiting = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapse.useMemo[handleExiting]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$createChainedFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Collapse.useMemo[handleExiting]": (elem)=>{
                    elem.style[computedDimension] = null;
                }
            }["Collapse.useMemo[handleExiting]"], onExiting)
    }["Collapse.useMemo[handleExiting]"], [
        computedDimension,
        onExiting
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        addEndListener: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        ...props,
        "aria-expanded": props.role ? inProp : null,
        onEnter: handleEnter,
        onEntering: handleEntering,
        onEntered: handleEntered,
        onExit: handleExit,
        onExiting: handleExiting,
        childRef: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children),
        in: inProp,
        timeout: timeout,
        mountOnEnter: mountOnEnter,
        unmountOnExit: unmountOnExit,
        appear: appear,
        children: (state, innerProps)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(children, {
                ...innerProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, children.props.className, collapseStyles[state], computedDimension === 'width' && 'collapse-horizontal')
            })
    });
});
Collapse.displayName = 'Collapse';
const __TURBOPACK__default__export__ = Collapse;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarCollapse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Collapse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
const NavbarCollapse = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ children, bsPrefix, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'navbar-collapse');
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Collapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        in: !!(context && context.expanded),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            ref: ref,
            className: bsPrefix,
            children: children
        })
    });
});
NavbarCollapse.displayName = 'NavbarCollapse';
const __TURBOPACK__default__export__ = NavbarCollapse;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
/**
 * Creates a `Ref` whose value is updated in an effect, ensuring the most recent
 * value is the one rendered with. Generally only required for Concurrent mode usage
 * where previous work in `render()` may be discarded before being used.
 *
 * This is safe to access in an event handler.
 *
 * @param value The `Ref` value
 */ function useCommittedRef(value) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCommittedRef.useEffect": ()=>{
            ref.current = value;
        }
    }["useCommittedRef.useEffect"], [
        value
    ]);
    return ref;
}
const __TURBOPACK__default__export__ = useCommittedRef;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useEventCallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useCommittedRef.js [app-client] (ecmascript)");
;
;
function useEventCallback(fn) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useCommittedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useEventCallback.useCallback": function(...args) {
            return ref.current && ref.current(...args);
        }
    }["useEventCallback.useCallback"], [
        ref
    ]);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarToggle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const NavbarToggle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, children, label = 'Toggle navigation', // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'button', onClick, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'navbar-toggler');
    const { onToggle, expanded } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) || {};
    const handleClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "NavbarToggle.useEventCallback[handleClick]": (e)=>{
            if (onClick) onClick(e);
            if (onToggle) onToggle();
        }
    }["NavbarToggle.useEventCallback[handleClick]"]);
    if (Component === 'button') {
        props.type = 'button';
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...props,
        ref: ref,
        onClick: handleClick,
        "aria-label": label,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix, !expanded && 'collapsed'),
        children: children || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            className: `${bsPrefix}-icon`
        })
    });
});
NavbarToggle.displayName = 'NavbarToggle';
const __TURBOPACK__default__export__ = NavbarToggle;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useIsomorphicEffect.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const isReactNative = ("TURBOPACK compile-time value", "object") !== 'undefined' && // @ts-ignore
/*TURBOPACK member replacement*/ __turbopack_context__.g.navigator && // @ts-ignore
/*TURBOPACK member replacement*/ __turbopack_context__.g.navigator.product === 'ReactNative';
const isDOM = typeof document !== 'undefined';
const __TURBOPACK__default__export__ = isDOM || isReactNative ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useMediaQuery.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useMediaQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useIsomorphicEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const matchersByWindow = new WeakMap();
const getMatcher = (query, targetWindow)=>{
    if (!query || !targetWindow) return undefined;
    const matchers = matchersByWindow.get(targetWindow) || new Map();
    matchersByWindow.set(targetWindow, matchers);
    let mql = matchers.get(query);
    if (!mql) {
        mql = targetWindow.matchMedia(query);
        mql.refCount = 0;
        matchers.set(mql.media, mql);
    }
    return mql;
};
function useMediaQuery(query, targetWindow = typeof window === 'undefined' ? undefined : window) {
    const mql = getMatcher(query, targetWindow);
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useMediaQuery.useState": ()=>mql ? mql.matches : false
    }["useMediaQuery.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useMediaQuery.useEffect": ()=>{
            let mql = getMatcher(query, targetWindow);
            if (!mql) {
                return setMatches(false);
            }
            let matchers = matchersByWindow.get(targetWindow);
            const handleChange = {
                "useMediaQuery.useEffect.handleChange": ()=>{
                    setMatches(mql.matches);
                }
            }["useMediaQuery.useEffect.handleChange"];
            mql.refCount++;
            mql.addListener(handleChange);
            handleChange();
            return ({
                "useMediaQuery.useEffect": ()=>{
                    mql.removeListener(handleChange);
                    mql.refCount--;
                    if (mql.refCount <= 0) {
                        matchers == null ? void 0 : matchers.delete(mql.media);
                    }
                    mql = undefined;
                }
            })["useMediaQuery.useEffect"];
        }
    }["useMediaQuery.useEffect"], [
        query
    ]);
    return matches;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useBreakpoint.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBreakpointHook",
    ()=>createBreakpointHook,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMediaQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useMediaQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function createBreakpointHook(breakpointValues) {
    const names = Object.keys(breakpointValues);
    function and(query, next) {
        if (query === next) {
            return next;
        }
        return query ? `${query} and ${next}` : next;
    }
    function getNext(breakpoint) {
        return names[Math.min(names.indexOf(breakpoint) + 1, names.length - 1)];
    }
    function getMaxQuery(breakpoint) {
        const next = getNext(breakpoint);
        let value = breakpointValues[next];
        if (typeof value === 'number') value = `${value - 0.2}px`;
        else value = `calc(${value} - 0.2px)`;
        return `(max-width: ${value})`;
    }
    function getMinQuery(breakpoint) {
        let value = breakpointValues[breakpoint];
        if (typeof value === 'number') {
            value = `${value}px`;
        }
        return `(min-width: ${value})`;
    }
    /**
   * Match a set of breakpoints
   *
   * ```tsx
   * const MidSizeOnly = () => {
   *   const isMid = useBreakpoint({ lg: 'down', sm: 'up' });
   *
   *   if (isMid) return <div>On a Reasonable sized Screen!</div>
   *   return null;
   * }
   * ```
   * @param breakpointMap An object map of breakpoints and directions, queries are constructed using "and" to join
   * breakpoints together
   * @param window Optionally specify the target window to match against (useful when rendering into iframes)
   */ /**
   * Match a single breakpoint exactly, up, or down.
   *
   * ```tsx
   * const PhoneOnly = () => {
   *   const isSmall = useBreakpoint('sm', 'down');
   *
   *   if (isSmall) return <div>On a Small Screen!</div>
   *   return null;
   * }
   * ```
   *
   * @param breakpoint The breakpoint key
   * @param direction A direction 'up' for a max, 'down' for min, true to match only the breakpoint
   * @param window Optionally specify the target window to match against (useful when rendering into iframes)
   */ function useBreakpoint(breakpointOrMap, direction, window) {
        let breakpointMap;
        if (typeof breakpointOrMap === 'object') {
            breakpointMap = breakpointOrMap;
            window = direction;
            direction = true;
        } else {
            direction = direction || true;
            breakpointMap = {
                [breakpointOrMap]: direction
            };
        }
        let query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
            "createBreakpointHook.useBreakpoint.useMemo[query]": ()=>Object.entries(breakpointMap).reduce({
                    "createBreakpointHook.useBreakpoint.useMemo[query]": (query, [key, direction])=>{
                        if (direction === 'up' || direction === true) {
                            query = and(query, getMinQuery(key));
                        }
                        if (direction === 'down' || direction === true) {
                            query = and(query, getMaxQuery(key));
                        }
                        return query;
                    }
                }["createBreakpointHook.useBreakpoint.useMemo[query]"], '')
        }["createBreakpointHook.useBreakpoint.useMemo[query]"], [
            JSON.stringify(breakpointMap)
        ]);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMediaQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(query, window);
    }
    return useBreakpoint;
}
const useBreakpoint = createBreakpointHook({
    xs: 0,
    sm: 576,
    md: 768,
    lg: 992,
    xl: 1200,
    xxl: 1400
});
const __TURBOPACK__default__export__ = useBreakpoint;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/activeElement.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>activeElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerDocument.js [app-client] (ecmascript)");
;
function activeElement(doc) {
    if (doc === void 0) {
        doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    }
    // Support: IE 9 only
    // IE9 throws an "Unspecified error" accessing document.activeElement from an <iframe>
    try {
        var active = doc.activeElement; // IE11 returns a seemingly empty object in some cases when accessing
        // document.activeElement from an <iframe>
        if (!active || !active.nodeName) return null;
        return active;
    } catch (e) {
        /* ie throws if no active element */ return doc.body;
    }
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/contains.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable no-bitwise, no-cond-assign */ /**
 * Checks if an element contains another given element.
 * 
 * @param context the context element
 * @param node the element to check
 */ __turbopack_context__.s([
    "default",
    ()=>contains
]);
function contains(context, node) {
    // HTML DOM and SVG DOM may have different support levels,
    // so we need to check on context instead of a document root element.
    if (context.contains) return context.contains(node);
    if (context.compareDocumentPosition) return context === node || !!(context.compareDocumentPosition(node) & 16);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useUpdatedRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useUpdatedRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useUpdatedRef(value) {
    const valueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    valueRef.current = value;
    return valueRef;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useWillUnmount.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useWillUnmount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useUpdatedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useUpdatedRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function useWillUnmount(fn) {
    const onUnmount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useUpdatedRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWillUnmount.useEffect": ()=>({
                "useWillUnmount.useEffect": ()=>onUnmount.current()
            })["useWillUnmount.useEffect"]
    }["useWillUnmount.useEffect"], []);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/getScrollbarWidth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Get the width of the vertical window scrollbar if it's visible
 */ __turbopack_context__.s([
    "default",
    ()=>getBodyScrollbarWidth
]);
function getBodyScrollbarWidth(ownerDocument = document) {
    const window = ownerDocument.defaultView;
    return Math.abs(window.innerWidth - ownerDocument.documentElement.clientWidth);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/ModalManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OPEN_DATA_ATTRIBUTE",
    ()=>OPEN_DATA_ATTRIBUTE,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/DataKey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$getScrollbarWidth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/getScrollbarWidth.js [app-client] (ecmascript)");
;
;
;
const OPEN_DATA_ATTRIBUTE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$DataKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataAttr"])('modal-open');
/**
 * Manages a stack of Modals as well as ensuring
 * body scrolling is is disabled and padding accounted for
 */ class ModalManager {
    constructor({ ownerDocument, handleContainerOverflow = true, isRTL = false } = {}){
        this.handleContainerOverflow = handleContainerOverflow;
        this.isRTL = isRTL;
        this.modals = [];
        this.ownerDocument = ownerDocument;
    }
    getScrollbarWidth() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$getScrollbarWidth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this.ownerDocument);
    }
    getElement() {
        return (this.ownerDocument || document).body;
    }
    setModalAttributes(_modal) {
    // For overriding
    }
    removeModalAttributes(_modal) {
    // For overriding
    }
    setContainerStyle(containerState) {
        const style = {
            overflow: 'hidden'
        };
        // we are only interested in the actual `style` here
        // because we will override it
        const paddingProp = this.isRTL ? 'paddingLeft' : 'paddingRight';
        const container = this.getElement();
        containerState.style = {
            overflow: container.style.overflow,
            [paddingProp]: container.style[paddingProp]
        };
        if (containerState.scrollBarWidth) {
            // use computed style, here to get the real padding
            // to add our scrollbar width
            style[paddingProp] = `${parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, paddingProp) || '0', 10) + containerState.scrollBarWidth}px`;
        }
        container.setAttribute(OPEN_DATA_ATTRIBUTE, '');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, style);
    }
    reset() {
        [
            ...this.modals
        ].forEach((m)=>this.remove(m));
    }
    removeContainerStyle(containerState) {
        const container = this.getElement();
        container.removeAttribute(OPEN_DATA_ATTRIBUTE);
        Object.assign(container.style, containerState.style);
    }
    add(modal) {
        let modalIdx = this.modals.indexOf(modal);
        if (modalIdx !== -1) {
            return modalIdx;
        }
        modalIdx = this.modals.length;
        this.modals.push(modal);
        this.setModalAttributes(modal);
        if (modalIdx !== 0) {
            return modalIdx;
        }
        this.state = {
            scrollBarWidth: this.getScrollbarWidth(),
            style: {}
        };
        if (this.handleContainerOverflow) {
            this.setContainerStyle(this.state);
        }
        return modalIdx;
    }
    remove(modal) {
        const modalIdx = this.modals.indexOf(modal);
        if (modalIdx === -1) {
            return;
        }
        this.modals.splice(modalIdx, 1);
        // if that was the last modal in a container,
        // clean up the container
        if (!this.modals.length && this.handleContainerOverflow) {
            this.removeContainerStyle(this.state);
        }
        this.removeModalAttributes(modal);
    }
    isTopModal(modal) {
        return !!this.modals.length && this.modals[this.modals.length - 1] === modal;
    }
}
const __TURBOPACK__default__export__ = ModalManager;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useWindow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WindowProvider",
    ()=>WindowProvider,
    "default",
    ()=>useWindow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/canUseDOM.js [app-client] (ecmascript)");
;
;
const Context = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? window : undefined);
const WindowProvider = Context.Provider;
function useWindow() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Context);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useWaitForDOMRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useWaitForDOMRef,
    "resolveContainerRef",
    ()=>resolveContainerRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/ownerDocument.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/canUseDOM.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useWindow.js [app-client] (ecmascript)");
;
;
;
;
const resolveContainerRef = (ref, document)=>{
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) return null;
    if (ref == null) return (document || (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()).body;
    if (typeof ref === 'function') ref = ref();
    if (ref && 'current' in ref) ref = ref.current;
    if (ref && ('nodeType' in ref || ref.getBoundingClientRect)) return ref;
    return null;
};
function useWaitForDOMRef(ref, onResolved) {
    const window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const [resolvedRef, setRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useWaitForDOMRef.useState": ()=>resolveContainerRef(ref, window == null ? void 0 : window.document)
    }["useWaitForDOMRef.useState"]);
    if (!resolvedRef) {
        const earlyRef = resolveContainerRef(ref);
        if (earlyRef) setRef(earlyRef);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWaitForDOMRef.useEffect": ()=>{
            if (onResolved && resolvedRef) {
                onResolved(resolvedRef);
            }
        }
    }["useWaitForDOMRef.useEffect"], [
        onResolved,
        resolvedRef
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWaitForDOMRef.useEffect": ()=>{
            const nextRef = resolveContainerRef(ref);
            if (nextRef !== resolvedRef) {
                setRef(nextRef);
            }
        }
    }["useWaitForDOMRef.useEffect"], [
        ref,
        resolvedRef
    ]);
    return resolvedRef;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NoopTransition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
;
;
;
;
function NoopTransition({ children, in: inProp, onExited, mountOnEnter, unmountOnExit }) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hasEnteredRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(inProp);
    const handleExited = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(onExited);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NoopTransition.useEffect": ()=>{
            if (inProp) hasEnteredRef.current = true;
            else {
                handleExited(ref.current);
            }
        }
    }["NoopTransition.useEffect"], [
        inProp,
        handleExited
    ]);
    const combinedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ref, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children));
    const child = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(children, {
        ref: combinedRef
    });
    if (inProp) return child;
    if (unmountOnExit) {
        return null;
    }
    if (!hasEnteredRef.current && mountOnEnter) {
        return null;
    }
    return child;
}
const __TURBOPACK__default__export__ = NoopTransition;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useRTGTransitionProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useRTGTransitionProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
const _excluded = [
    "onEnter",
    "onEntering",
    "onEntered",
    "onExit",
    "onExiting",
    "onExited",
    "addEndListener",
    "children"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
function useRTGTransitionProps(_ref) {
    let { onEnter, onEntering, onEntered, onExit, onExiting, onExited, addEndListener, children } = _ref, props = _objectWithoutPropertiesLoose(_ref, _excluded);
    const nodeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nodeRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children));
    const normalize = (callback)=>(param)=>{
            if (callback && nodeRef.current) {
                callback(nodeRef.current, param);
            }
        };
    /* eslint-disable react-hooks/exhaustive-deps */ const handleEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEnter), [
        onEnter
    ]);
    const handleEntering = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEntering), [
        onEntering
    ]);
    const handleEntered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onEntered), [
        onEntered
    ]);
    const handleExit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExit), [
        onExit
    ]);
    const handleExiting = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExiting), [
        onExiting
    ]);
    const handleExited = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(onExited), [
        onExited
    ]);
    const handleAddEndListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(normalize(addEndListener), [
        addEndListener
    ]);
    /* eslint-enable react-hooks/exhaustive-deps */ return Object.assign({}, props, {
        nodeRef
    }, onEnter && {
        onEnter: handleEnter
    }, onEntering && {
        onEntering: handleEntering
    }, onEntered && {
        onEntered: handleEntered
    }, onExit && {
        onExit: handleExit
    }, onExiting && {
        onExiting: handleExiting
    }, onExited && {
        onExited: handleExited
    }, addEndListener && {
        addEndListener: handleAddEndListener
    }, {
        children: typeof children === 'function' ? (status, innerProps)=>// TODO: Types for RTG missing innerProps, so need to cast.
            children(status, Object.assign({}, innerProps, {
                ref: mergedRef
            })) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(children, {
            ref: mergedRef
        })
    });
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/RTGTransition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useRTGTransitionProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useRTGTransitionProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "component"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
// Normalizes Transition callbacks when nodeRef is used.
const RTGTransition = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((_ref, ref)=>{
    let { component: Component } = _ref, props = _objectWithoutPropertiesLoose(_ref, _excluded);
    const transitionProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useRTGTransitionProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, Object.assign({
        ref: ref
    }, transitionProps));
});
const __TURBOPACK__default__export__ = RTGTransition;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/ImperativeTransition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ImperativeTransition,
    "renderTransition",
    ()=>renderTransition,
    "useTransition",
    ()=>useTransition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useIsomorphicEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NoopTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/NoopTransition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$RTGTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/RTGTransition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function useTransition({ in: inProp, onTransition }) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isInitialRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    const handleTransition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(onTransition);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useTransition.useIsomorphicEffect": ()=>{
            if (!ref.current) {
                return undefined;
            }
            let stale = false;
            handleTransition({
                in: inProp,
                element: ref.current,
                initial: isInitialRef.current,
                isStale: {
                    "useTransition.useIsomorphicEffect": ()=>stale
                }["useTransition.useIsomorphicEffect"]
            });
            return ({
                "useTransition.useIsomorphicEffect": ()=>{
                    stale = true;
                }
            })["useTransition.useIsomorphicEffect"];
        }
    }["useTransition.useIsomorphicEffect"], [
        inProp,
        handleTransition
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useIsomorphicEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useTransition.useIsomorphicEffect": ()=>{
            isInitialRef.current = false;
            // this is for strict mode
            return ({
                "useTransition.useIsomorphicEffect": ()=>{
                    isInitialRef.current = true;
                }
            })["useTransition.useIsomorphicEffect"];
        }
    }["useTransition.useIsomorphicEffect"], []);
    return ref;
}
function ImperativeTransition({ children, in: inProp, onExited, onEntered, transition }) {
    const [exited, setExited] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!inProp);
    // TODO: I think this needs to be in an effect
    if (inProp && exited) {
        setExited(false);
    }
    const ref = useTransition({
        in: !!inProp,
        onTransition: {
            "ImperativeTransition.useTransition[ref]": (options)=>{
                const onFinish = {
                    "ImperativeTransition.useTransition[ref].onFinish": ()=>{
                        if (options.isStale()) return;
                        if (options.in) {
                            onEntered == null ? void 0 : onEntered(options.element, options.initial);
                        } else {
                            setExited(true);
                            onExited == null ? void 0 : onExited(options.element);
                        }
                    }
                }["ImperativeTransition.useTransition[ref].onFinish"];
                Promise.resolve(transition(options)).then(onFinish, {
                    "ImperativeTransition.useTransition[ref]": (error)=>{
                        if (!options.in) setExited(true);
                        throw error;
                    }
                }["ImperativeTransition.useTransition[ref]"]);
            }
        }["ImperativeTransition.useTransition[ref]"]
    });
    const combinedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ref, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children));
    return exited && !inProp ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(children, {
        ref: combinedRef
    });
}
function renderTransition(component, runTransition, props) {
    if (component) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$RTGTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({}, props, {
            component: component
        }));
    }
    if (runTransition) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ImperativeTransition, Object.assign({}, props, {
            transition: runTransition
        }));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$NoopTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({}, props));
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Modal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/* eslint-disable @typescript-eslint/no-use-before-define, react/prop-types */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$activeElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/activeElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$contains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/contains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/canUseDOM.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/listen.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMounted$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useMounted.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useWillUnmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useWillUnmount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/usePrevious.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/ModalManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWaitForDOMRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useWaitForDOMRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/useWindow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ImperativeTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/ImperativeTransition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _excluded = [
    "show",
    "role",
    "className",
    "style",
    "children",
    "backdrop",
    "keyboard",
    "onBackdropClick",
    "onEscapeKeyDown",
    "transition",
    "runTransition",
    "backdropTransition",
    "runBackdropTransition",
    "autoFocus",
    "enforceFocus",
    "restoreFocus",
    "restoreFocusOptions",
    "renderDialog",
    "renderBackdrop",
    "manager",
    "container",
    "onShow",
    "onHide",
    "onExit",
    "onExited",
    "onExiting",
    "onEnter",
    "onEntering",
    "onEntered"
];
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (e.indexOf(n) >= 0) continue;
        t[n] = r[n];
    }
    return t;
}
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
let manager;
/*
  Modal props are split into a version with and without index signature so that you can fully use them in another projects
  This is due to Typescript not playing well with index signatures e.g. when using Omit
*/ function getManager(window) {
    if (!manager) manager = new __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]({
        ownerDocument: window == null ? void 0 : window.document
    });
    return manager;
}
function useModalManager(provided) {
    const window = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const modalManager = provided || getManager(window);
    const modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        dialog: null,
        backdrop: null
    });
    return Object.assign(modal.current, {
        add: ()=>modalManager.add(modal.current),
        remove: ()=>modalManager.remove(modal.current),
        isTopModal: ()=>modalManager.isTopModal(modal.current),
        setDialogRef: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "useModalManager.useCallback": (ref)=>{
                modal.current.dialog = ref;
            }
        }["useModalManager.useCallback"], []),
        setBackdropRef: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
            "useModalManager.useCallback": (ref)=>{
                modal.current.backdrop = ref;
            }
        }["useModalManager.useCallback"], [])
    });
}
const Modal = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])((_ref, ref)=>{
    let { show = false, role = 'dialog', className, style, children, backdrop = true, keyboard = true, onBackdropClick, onEscapeKeyDown, transition, runTransition, backdropTransition, runBackdropTransition, autoFocus = true, enforceFocus = true, restoreFocus = true, restoreFocusOptions, renderDialog, renderBackdrop = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", Object.assign({}, props)), manager: providedManager, container: containerRef, onShow, onHide = ()=>{}, onExit, onExited, onExiting, onEnter, onEntering, onEntered } = _ref, rest = _objectWithoutPropertiesLoose(_ref, _excluded);
    const ownerWindow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$useWaitForDOMRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(containerRef);
    const modal = useModalManager(providedManager);
    const isMounted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useMounted$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const prevShow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(show);
    const [exited, setExited] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!show);
    const lastFocusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(ref, {
        "Modal.useImperativeHandle": ()=>modal
    }["Modal.useImperativeHandle"], [
        modal
    ]);
    if (__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$canUseDOM$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] && !prevShow && show) {
        lastFocusRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$activeElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerWindow == null ? void 0 : ownerWindow.document);
    }
    // TODO: I think this needs to be in an effect
    if (show && exited) {
        setExited(false);
    }
    const handleShow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useEventCallback[handleShow]": ()=>{
            modal.add();
            removeKeydownListenerRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(document, 'keydown', handleDocumentKeyDown);
            removeFocusListenerRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$listen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(document, 'focus', {
                "Modal.useEventCallback[handleShow]": // the timeout is necessary b/c this will run before the new modal is mounted
                // and so steals focus from it
                ()=>setTimeout(handleEnforceFocus)
            }["Modal.useEventCallback[handleShow]"], true);
            if (onShow) {
                onShow();
            }
            // autofocus after onShow to not trigger a focus event for previous
            // modals before this one is shown.
            if (autoFocus) {
                var _modal$dialog$ownerDo, _modal$dialog;
                const currentActiveElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$activeElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((_modal$dialog$ownerDo = (_modal$dialog = modal.dialog) == null ? void 0 : _modal$dialog.ownerDocument) != null ? _modal$dialog$ownerDo : ownerWindow == null ? void 0 : ownerWindow.document);
                if (modal.dialog && currentActiveElement && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$contains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(modal.dialog, currentActiveElement)) {
                    lastFocusRef.current = currentActiveElement;
                    modal.dialog.focus();
                }
            }
        }
    }["Modal.useEventCallback[handleShow]"]);
    const handleHide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useEventCallback[handleHide]": ()=>{
            modal.remove();
            removeKeydownListenerRef.current == null ? void 0 : removeKeydownListenerRef.current();
            removeFocusListenerRef.current == null ? void 0 : removeFocusListenerRef.current();
            if (restoreFocus) {
                var _lastFocusRef$current;
                // Support: <=IE11 doesn't support `focus()` on svg elements (RB: #917)
                (_lastFocusRef$current = lastFocusRef.current) == null ? void 0 : _lastFocusRef$current.focus == null ? void 0 : _lastFocusRef$current.focus(restoreFocusOptions);
                lastFocusRef.current = null;
            }
        }
    }["Modal.useEventCallback[handleHide]"]);
    // TODO: try and combine these effects: https://github.com/react-bootstrap/react-overlays/pull/794#discussion_r409954120
    // Show logic when:
    //  - show is `true` _and_ `container` has resolved
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!show || !container) return;
            handleShow();
        }
    }["Modal.useEffect"], [
        show,
        container,
        /* should never change: */ handleShow
    ]);
    // Hide cleanup logic when:
    //  - `exited` switches to true
    //  - component unmounts;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!exited) return;
            handleHide();
        }
    }["Modal.useEffect"], [
        exited,
        handleHide
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useWillUnmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useWillUnmount": ()=>{
            handleHide();
        }
    }["Modal.useWillUnmount"]);
    // --------------------------------
    const handleEnforceFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useEventCallback[handleEnforceFocus]": ()=>{
            if (!enforceFocus || !isMounted() || !modal.isTopModal()) {
                return;
            }
            const currentActiveElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$activeElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerWindow == null ? void 0 : ownerWindow.document);
            if (modal.dialog && currentActiveElement && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$contains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(modal.dialog, currentActiveElement)) {
                modal.dialog.focus();
            }
        }
    }["Modal.useEventCallback[handleEnforceFocus]"]);
    const handleBackdropClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useEventCallback[handleBackdropClick]": (e)=>{
            if (e.target !== e.currentTarget) {
                return;
            }
            onBackdropClick == null ? void 0 : onBackdropClick(e);
            if (backdrop === true) {
                onHide();
            }
        }
    }["Modal.useEventCallback[handleBackdropClick]"]);
    const handleDocumentKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "Modal.useEventCallback[handleDocumentKeyDown]": (e)=>{
            if (keyboard && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEscKey"])(e) && modal.isTopModal()) {
                onEscapeKeyDown == null ? void 0 : onEscapeKeyDown(e);
                if (!e.defaultPrevented) {
                    onHide();
                }
            }
        }
    }["Modal.useEventCallback[handleDocumentKeyDown]"]);
    const removeFocusListenerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const removeKeydownListenerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const handleHidden = (...args)=>{
        setExited(true);
        onExited == null ? void 0 : onExited(...args);
    };
    if (!container) {
        return null;
    }
    const dialogProps = Object.assign({
        role,
        ref: modal.setDialogRef,
        // apparently only works on the dialog role element
        'aria-modal': role === 'dialog' ? true : undefined
    }, rest, {
        style,
        className,
        tabIndex: -1
    });
    let dialog = renderDialog ? renderDialog(dialogProps) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", Object.assign({}, dialogProps, {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](children, {
            role: 'document'
        })
    }));
    dialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ImperativeTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderTransition"])(transition, runTransition, {
        unmountOnExit: true,
        mountOnEnter: true,
        appear: true,
        in: !!show,
        onExit,
        onExiting,
        onExited: handleHidden,
        onEnter,
        onEntering,
        onEntered,
        children: dialog
    });
    let backdropElement = null;
    if (backdrop) {
        backdropElement = renderBackdrop({
            ref: modal.setBackdropRef,
            onClick: handleBackdropClick
        });
        backdropElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ImperativeTransition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderTransition"])(backdropTransition, runBackdropTransition, {
            in: !!show,
            appear: true,
            mountOnEnter: true,
            unmountOnExit: true,
            children: backdropElement
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createPortal(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                backdropElement,
                dialog
            ]
        }), container)
    });
});
Modal.displayName = 'Modal';
const __TURBOPACK__default__export__ = Object.assign(Modal, {
    Manager: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Fade.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/transitionEndListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$triggerBrowserReflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/triggerBrowserReflow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/TransitionWrapper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const fadeStyles = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERING"]]: 'show',
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERED"]]: 'show'
};
const Fade = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, children, transitionClasses = {}, onEnter, ...rest }, ref)=>{
    const props = {
        in: false,
        timeout: 300,
        mountOnEnter: false,
        unmountOnExit: false,
        appear: false,
        ...rest
    };
    const handleEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Fade.useCallback[handleEnter]": (node, isAppearing)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$triggerBrowserReflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node);
            onEnter == null || onEnter(node, isAppearing);
        }
    }["Fade.useCallback[handleEnter]"], [
        onEnter
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        addEndListener: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        ...props,
        onEnter: handleEnter,
        childRef: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children),
        children: (status, innerProps)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](children, {
                ...innerProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('fade', className, children.props.className, fadeStyles[status], transitionClasses[status])
            })
    });
});
Fade.displayName = 'Fade';
const __TURBOPACK__default__export__ = Fade;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasBody.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const OffcanvasBody = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'div', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'offcanvas-body');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
OffcanvasBody.displayName = 'OffcanvasBody';
const __TURBOPACK__default__export__ = OffcanvasBody;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasToggling.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/transitionEndListener.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/TransitionWrapper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
const transitionStyles = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERING"]]: 'show',
    [__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERED"]]: 'show'
};
const OffcanvasToggling = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, children, in: inProp = false, mountOnEnter = false, unmountOnExit = false, appear = false, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'offcanvas');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$TransitionWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        addEndListener: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$transitionEndListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        in: inProp,
        mountOnEnter: mountOnEnter,
        unmountOnExit: unmountOnExit,
        appear: appear,
        ...props,
        childRef: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getChildRef"])(children),
        children: (status, innerProps)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](children, {
                ...innerProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, children.props.className, (status === __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTERING"] || status === __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXITING"]) && `${bsPrefix}-toggling`, transitionStyles[status])
            })
    });
});
OffcanvasToggling.displayName = 'OffcanvasToggling';
const __TURBOPACK__default__export__ = OffcanvasToggling;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ModalContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
const ModalContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    onHide () {}
});
const __TURBOPACK__default__export__ = ModalContext;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CloseButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
const propTypes = {
    /** An accessible label indicating the relevant information about the Close Button. */ 'aria-label': __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /** A callback fired after the Close Button is clicked. */ onClick: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Render different color variant for the button.
   *
   * Omitting this will render the default dark color.
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'white'
    ])
};
const CloseButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, variant, 'aria-label': ariaLabel = 'Close', ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        ref: ref,
        type: "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('btn-close', variant && `btn-close-${variant}`, className),
        "aria-label": ariaLabel,
        ...props
    }));
CloseButton.displayName = 'CloseButton';
CloseButton.propTypes = propTypes;
const __TURBOPACK__default__export__ = CloseButton;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/AbstractModalHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CloseButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CloseButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ModalContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ModalContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const AbstractModalHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ closeLabel = 'Close', closeVariant, closeButton = false, onHide, children, ...props }, ref)=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ModalContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const handleClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "AbstractModalHeader.useEventCallback[handleClick]": ()=>{
            context == null || context.onHide();
            onHide == null || onHide();
        }
    }["AbstractModalHeader.useEventCallback[handleClick]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        ref: ref,
        ...props,
        children: [
            children,
            closeButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CloseButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                "aria-label": closeLabel,
                variant: closeVariant,
                onClick: handleClick
            })
        ]
    });
});
AbstractModalHeader.displayName = 'AbstractModalHeader';
const __TURBOPACK__default__export__ = AbstractModalHeader;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$AbstractModalHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/AbstractModalHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const OffcanvasHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, closeLabel = 'Close', closeButton = false, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'offcanvas-header');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$AbstractModalHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        closeLabel: closeLabel,
        closeButton: closeButton
    });
});
OffcanvasHeader.displayName = 'OffcanvasHeader';
const __TURBOPACK__default__export__ = OffcanvasHeader;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/divWithClassName.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
const __TURBOPACK__default__export__ = (className)=>/*#__PURE__*/ // eslint-disable-next-line react/display-name
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((p, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            ...p,
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(p.className, className)
        }));
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasTitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/divWithClassName.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const DivStyledAsH5 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h5');
const OffcanvasTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = DivStyledAsH5, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'offcanvas-title');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
OffcanvasTitle.displayName = 'OffcanvasTitle';
const __TURBOPACK__default__export__ = OffcanvasTitle;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hasClass.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Checks if a given element has a CSS class.
 * 
 * @param element the element
 * @param className the CSS class name
 */ __turbopack_context__.s([
    "default",
    ()=>hasClass
]);
function hasClass(element, className) {
    if (element.classList) return !!className && element.classList.contains(className);
    return (" " + (element.className.baseVal || element.className) + " ").indexOf(" " + className + " ") !== -1;
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/addClass.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>addClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hasClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/hasClass.js [app-client] (ecmascript)");
;
function addClass(element, className) {
    if (element.classList) element.classList.add(className);
    else if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$hasClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, className)) if (typeof element.className === 'string') element.className = element.className + " " + className;
    else element.setAttribute('class', (element.className && element.className.baseVal || '') + " " + className);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/removeClass.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>removeClass
]);
function replaceClassName(origClass, classToRemove) {
    return origClass.replace(new RegExp("(^|\\s)" + classToRemove + "(?:\\s|$)", 'g'), '$1').replace(/\s+/g, ' ').replace(/^\s*|\s*$/g, '');
}
function removeClass(element, className) {
    if (element.classList) {
        element.classList.remove(className);
    } else if (typeof element.className === 'string') {
        element.className = replaceClassName(element.className, className);
    } else {
        element.setAttribute('class', replaceClassName(element.className && element.className.baseVal || '', className));
    }
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/BootstrapModalManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getSharedManager",
    ()=>getSharedManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$addClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/addClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/css.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/querySelectorAll.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$removeClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/dom-helpers/esm/removeClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/ModalManager.js [app-client] (ecmascript)");
;
;
;
;
;
const Selector = {
    FIXED_CONTENT: '.fixed-top, .fixed-bottom, .is-fixed, .sticky-top',
    STICKY_CONTENT: '.sticky-top',
    NAVBAR_TOGGLER: '.navbar-toggler'
};
class BootstrapModalManager extends __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$ModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] {
    adjustAndStore(prop, element, adjust) {
        const actual = element.style[prop];
        // @ts-expect-error TODO: DOMStringMap and CSSStyleDeclaration aren't strictly compatible
        element.dataset[prop] = actual;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, {
            [prop]: `${parseFloat((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, prop)) + adjust}px`
        });
    }
    restore(prop, element) {
        const value = element.dataset[prop];
        if (value !== undefined) {
            delete element.dataset[prop];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(element, {
                [prop]: value
            });
        }
    }
    setContainerStyle(containerState) {
        super.setContainerStyle(containerState);
        const container = this.getElement();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$addClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, 'modal-open');
        if (!containerState.scrollBarWidth) return;
        const paddingProp = this.isRTL ? 'paddingLeft' : 'paddingRight';
        const marginProp = this.isRTL ? 'marginLeft' : 'marginRight';
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.FIXED_CONTENT).forEach((el)=>this.adjustAndStore(paddingProp, el, containerState.scrollBarWidth));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.STICKY_CONTENT).forEach((el)=>this.adjustAndStore(marginProp, el, -containerState.scrollBarWidth));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.NAVBAR_TOGGLER).forEach((el)=>this.adjustAndStore(marginProp, el, containerState.scrollBarWidth));
    }
    removeContainerStyle(containerState) {
        super.removeContainerStyle(containerState);
        const container = this.getElement();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$removeClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, 'modal-open');
        const paddingProp = this.isRTL ? 'paddingLeft' : 'paddingRight';
        const marginProp = this.isRTL ? 'marginLeft' : 'marginRight';
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.FIXED_CONTENT).forEach((el)=>this.restore(paddingProp, el));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.STICKY_CONTENT).forEach((el)=>this.restore(marginProp, el));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$dom$2d$helpers$2f$esm$2f$querySelectorAll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container, Selector.NAVBAR_TOGGLER).forEach((el)=>this.restore(marginProp, el));
    }
}
let sharedManager;
function getSharedManager(options) {
    if (!sharedManager) sharedManager = new BootstrapModalManager(options);
    return sharedManager;
}
const __TURBOPACK__default__export__ = BootstrapModalManager;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Offcanvas.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useBreakpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useBreakpoint.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Modal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Fade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Fade.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasBody.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasToggling$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasToggling.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ModalContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ModalContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/OffcanvasTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$BootstrapModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/BootstrapModalManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function DialogTransition(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasToggling$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ...props
    });
}
function BackdropTransition(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Fade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ...props
    });
}
const Offcanvas = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, children, 'aria-labelledby': ariaLabelledby, placement = 'start', responsive, /* BaseModal props */ show = false, backdrop = true, keyboard = true, scroll = false, onEscapeKeyDown, onShow, onHide, container, autoFocus = true, enforceFocus = true, restoreFocus = true, restoreFocusOptions, onEntered, onExit, onExiting, onEnter, onEntering, onExited, backdropClassName, manager: propsManager, renderStaticNode = false, ...props }, ref)=>{
    const modalManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'offcanvas');
    const [showOffcanvas, setShowOffcanvas] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleHide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(onHide);
    const hideResponsiveOffcanvas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useBreakpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(responsive || 'xs', 'up');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Offcanvas.useEffect": ()=>{
            // Handles the case where screen is resized while the responsive
            // offcanvas is shown. If `responsive` not provided, just use `show`.
            setShowOffcanvas(responsive ? show && !hideResponsiveOffcanvas : show);
        }
    }["Offcanvas.useEffect"], [
        show,
        responsive,
        hideResponsiveOffcanvas
    ]);
    const modalContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Offcanvas.useMemo[modalContext]": ()=>({
                onHide: handleHide
            })
    }["Offcanvas.useMemo[modalContext]"], [
        handleHide
    ]);
    function getModalManager() {
        if (propsManager) return propsManager;
        if (scroll) {
            // Have to use a different modal manager since the shared
            // one handles overflow.
            if (!modalManager.current) modalManager.current = new __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$BootstrapModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]({
                handleContainerOverflow: false
            });
            return modalManager.current;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$BootstrapModalManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSharedManager"])();
    }
    const handleEnter = (node, ...args)=>{
        if (node) node.style.visibility = 'visible';
        onEnter == null || onEnter(node, ...args);
    };
    const handleExited = (node, ...args)=>{
        if (node) node.style.visibility = '';
        onExited == null || onExited(...args);
    };
    const renderBackdrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Offcanvas.useCallback[renderBackdrop]": (backdropProps)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                ...backdropProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`${bsPrefix}-backdrop`, backdropClassName)
            })
    }["Offcanvas.useCallback[renderBackdrop]"], [
        backdropClassName,
        bsPrefix
    ]);
    const renderDialog = (dialogProps)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            ...dialogProps,
            ...props,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, responsive ? `${bsPrefix}-${responsive}` : bsPrefix, `${bsPrefix}-${placement}`),
            "aria-labelledby": ariaLabelledby,
            children: children
        });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            !showOffcanvas && (responsive || renderStaticNode) && renderDialog({}),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ModalContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
                value: modalContext,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    show: showOffcanvas,
                    ref: ref,
                    backdrop: backdrop,
                    container: container,
                    keyboard: keyboard,
                    autoFocus: autoFocus,
                    enforceFocus: enforceFocus && !scroll,
                    restoreFocus: restoreFocus,
                    restoreFocusOptions: restoreFocusOptions,
                    onEscapeKeyDown: onEscapeKeyDown,
                    onShow: onShow,
                    onHide: handleHide,
                    onEnter: handleEnter,
                    onEntering: onEntering,
                    onEntered: onEntered,
                    onExit: onExit,
                    onExiting: onExiting,
                    onExited: handleExited,
                    manager: getModalManager(),
                    transition: DialogTransition,
                    backdropTransition: BackdropTransition,
                    renderBackdrop: renderBackdrop,
                    renderDialog: renderDialog
                })
            })
        ]
    });
});
Offcanvas.displayName = 'Offcanvas';
const __TURBOPACK__default__export__ = Object.assign(Offcanvas, {
    Body: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Header: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Title: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$OffcanvasTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarOffcanvas.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/hooks/esm/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Offcanvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Offcanvas.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
const NavbarOffcanvas = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ onHide, ...props }, ref)=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const handleHide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$hooks$2f$esm$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "NavbarOffcanvas.useEventCallback[handleHide]": ()=>{
            context == null || context.onToggle == null || context.onToggle();
            onHide == null || onHide();
        }
    }["NavbarOffcanvas.useEventCallback[handleHide]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Offcanvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        show: !!(context != null && context.expanded),
        ...props,
        renderStaticNode: true,
        onHide: handleHide
    });
});
NavbarOffcanvas.displayName = 'NavbarOffcanvas';
const __TURBOPACK__default__export__ = NavbarOffcanvas;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarText.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const NavbarText = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'span', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'navbar-text');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
NavbarText.displayName = 'NavbarText';
const __TURBOPACK__default__export__ = NavbarText;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Navbar.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/SelectableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useUncontrolled$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/uncontrollable/lib/esm/hook.js [app-client] (ecmascript) <export default as useUncontrolled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarBrand$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarBrand.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarCollapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarCollapse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarToggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarToggle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarOffcanvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarOffcanvas.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/NavbarText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
const Navbar = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, ref)=>{
    const { bsPrefix: initialBsPrefix, expand = true, variant = 'light', bg, fixed, sticky, className, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
    as: Component = 'nav', expanded, onToggle, onSelect, collapseOnSelect = false, ...controlledProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$uncontrollable$2f$lib$2f$esm$2f$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useUncontrolled$3e$__["useUncontrolled"])(props, {
        expanded: 'onToggle'
    });
    const bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(initialBsPrefix, 'navbar');
    const handleCollapse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Navbar.useCallback[handleCollapse]": (...args)=>{
            onSelect == null || onSelect(...args);
            if (collapseOnSelect && expanded) {
                onToggle == null || onToggle(false);
            }
        }
    }["Navbar.useCallback[handleCollapse]"], [
        onSelect,
        collapseOnSelect,
        expanded,
        onToggle
    ]);
    // will result in some false positives but that seems better
    // than false negatives. strict `undefined` check allows explicit
    // "nulling" of the role if the user really doesn't want one
    if (controlledProps.role === undefined && Component !== 'nav') {
        controlledProps.role = 'navigation';
    }
    let expandClass = `${bsPrefix}-expand`;
    if (typeof expand === 'string') expandClass = `${expandClass}-${expand}`;
    const navbarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Navbar.useMemo[navbarContext]": ()=>({
                onToggle: ({
                    "Navbar.useMemo[navbarContext]": ()=>onToggle == null ? void 0 : onToggle(!expanded)
                })["Navbar.useMemo[navbarContext]"],
                bsPrefix,
                expanded: !!expanded,
                expand
            })
    }["Navbar.useMemo[navbarContext]"], [
        bsPrefix,
        expanded,
        expand,
        onToggle
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: navbarContext,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$SelectableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: handleCollapse,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
                ref: ref,
                ...controlledProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix, expand && expandClass, variant && `${bsPrefix}-${variant}`, bg && `bg-${bg}`, sticky && `sticky-${sticky}`, fixed && `fixed-${fixed}`)
            })
        })
    });
});
Navbar.displayName = 'Navbar';
const __TURBOPACK__default__export__ = Object.assign(Navbar, {
    Brand: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarBrand$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Collapse: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarCollapse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Offcanvas: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarOffcanvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Text: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Toggle: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$NavbarToggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Navbar.js [app-client] (ecmascript) <export default as Navbar>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Navbar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Navbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Navbar.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/querystring.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    assign: null,
    searchParamsToUrlQuery: null,
    urlQueryToSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    assign: function() {
        return assign;
    },
    searchParamsToUrlQuery: function() {
        return searchParamsToUrlQuery;
    },
    urlQueryToSearchParams: function() {
        return urlQueryToSearchParams;
    }
});
function searchParamsToUrlQuery(searchParams) {
    const query = {};
    for (const [key, value] of searchParams.entries()){
        const existing = query[key];
        if (typeof existing === 'undefined') {
            query[key] = value;
        } else if (Array.isArray(existing)) {
            existing.push(value);
        } else {
            query[key] = [
                existing,
                value
            ];
        }
    }
    return query;
}
function stringifyUrlQueryParam(param) {
    if (typeof param === 'string') {
        return param;
    }
    if (typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
        return String(param);
    } else {
        return '';
    }
}
function urlQueryToSearchParams(query) {
    const searchParams = new URLSearchParams();
    for (const [key, value] of Object.entries(query)){
        if (Array.isArray(value)) {
            for (const item of value){
                searchParams.append(key, stringifyUrlQueryParam(item));
            }
        } else {
            searchParams.set(key, stringifyUrlQueryParam(value));
        }
    }
    return searchParams;
}
function assign(target, ...searchParamsList) {
    for (const searchParams of searchParamsList){
        for (const key of searchParams.keys()){
            target.delete(key);
        }
        for (const [key, value] of searchParams.entries()){
            target.append(key, value);
        }
    }
    return target;
} //# sourceMappingURL=querystring.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/format-url.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    formatUrl: null,
    formatWithValidation: null,
    urlObjectKeys: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    formatUrl: function() {
        return formatUrl;
    },
    formatWithValidation: function() {
        return formatWithValidation;
    },
    urlObjectKeys: function() {
        return urlObjectKeys;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _querystring = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/querystring.js [app-client] (ecmascript)"));
const slashedProtocols = /https?|ftp|gopher|file/;
function formatUrl(urlObj) {
    let { auth, hostname } = urlObj;
    let protocol = urlObj.protocol || '';
    let pathname = urlObj.pathname || '';
    let hash = urlObj.hash || '';
    let query = urlObj.query || '';
    let host = false;
    auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';
    if (urlObj.host) {
        host = auth + urlObj.host;
    } else if (hostname) {
        host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);
        if (urlObj.port) {
            host += ':' + urlObj.port;
        }
    }
    if (query && typeof query === 'object') {
        query = String(_querystring.urlQueryToSearchParams(query));
    }
    let search = urlObj.search || query && `?${query}` || '';
    if (protocol && !protocol.endsWith(':')) protocol += ':';
    if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
        host = '//' + (host || '');
        if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
    } else if (!host) {
        host = '';
    }
    if (hash && hash[0] !== '#') hash = '#' + hash;
    if (search && search[0] !== '?') search = '?' + search;
    pathname = pathname.replace(/[?#]/g, encodeURIComponent);
    search = search.replace('#', '%23');
    return `${protocol}${host}${pathname}${search}${hash}`;
}
const urlObjectKeys = [
    'auth',
    'hash',
    'host',
    'hostname',
    'href',
    'path',
    'pathname',
    'port',
    'protocol',
    'query',
    'search',
    'slashes'
];
function formatWithValidation(url) {
    if ("TURBOPACK compile-time truthy", 1) {
        if (url !== null && typeof url === 'object') {
            Object.keys(url).forEach((key)=>{
                if (!urlObjectKeys.includes(key)) {
                    console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
                }
            });
        }
    }
    return formatUrl(url);
} //# sourceMappingURL=format-url.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useMergedRef", {
    enumerable: true,
    get: function() {
        return useMergedRef;
    }
});
const _react = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function useMergedRef(refA, refB) {
    const cleanupA = (0, _react.useRef)(null);
    const cleanupB = (0, _react.useRef)(null);
    // NOTE: In theory, we could skip the wrapping if only one of the refs is non-null.
    // (this happens often if the user doesn't pass a ref to Link/Form/Image)
    // But this can cause us to leak a cleanup-ref into user code (previously via `<Link legacyBehavior>`),
    // and the user might pass that ref into ref-merging library that doesn't support cleanup refs
    // (because it hasn't been updated for React 19)
    // which can then cause things to blow up, because a cleanup-returning ref gets called with `null`.
    // So in practice, it's safer to be defensive and always wrap the ref, even on React 19.
    return (0, _react.useCallback)((current)=>{
        if (current === null) {
            const cleanupFnA = cleanupA.current;
            if (cleanupFnA) {
                cleanupA.current = null;
                cleanupFnA();
            }
            const cleanupFnB = cleanupB.current;
            if (cleanupFnB) {
                cleanupB.current = null;
                cleanupFnB();
            }
        } else {
            if (refA) {
                cleanupA.current = applyRef(refA, current);
            }
            if (refB) {
                cleanupB.current = applyRef(refB, current);
            }
        }
    }, [
        refA,
        refB
    ]);
}
function applyRef(refA, current) {
    if (typeof refA === 'function') {
        const cleanup = refA(current);
        if (typeof cleanup === 'function') {
            return cleanup;
        } else {
            return ()=>refA(null);
        }
    } else {
        refA.current = current;
        return ()=>{
            refA.current = null;
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-merged-ref.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DecodeError: null,
    MiddlewareNotFoundError: null,
    MissingStaticPage: null,
    NormalizeError: null,
    PageNotFoundError: null,
    SP: null,
    ST: null,
    WEB_VITALS: null,
    execOnce: null,
    getDisplayName: null,
    getLocationOrigin: null,
    getURL: null,
    isAbsoluteUrl: null,
    isResSent: null,
    loadGetInitialProps: null,
    normalizeRepeatedSlashes: null,
    stringifyError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DecodeError: function() {
        return DecodeError;
    },
    MiddlewareNotFoundError: function() {
        return MiddlewareNotFoundError;
    },
    MissingStaticPage: function() {
        return MissingStaticPage;
    },
    NormalizeError: function() {
        return NormalizeError;
    },
    PageNotFoundError: function() {
        return PageNotFoundError;
    },
    SP: function() {
        return SP;
    },
    ST: function() {
        return ST;
    },
    WEB_VITALS: function() {
        return WEB_VITALS;
    },
    execOnce: function() {
        return execOnce;
    },
    getDisplayName: function() {
        return getDisplayName;
    },
    getLocationOrigin: function() {
        return getLocationOrigin;
    },
    getURL: function() {
        return getURL;
    },
    isAbsoluteUrl: function() {
        return isAbsoluteUrl;
    },
    isResSent: function() {
        return isResSent;
    },
    loadGetInitialProps: function() {
        return loadGetInitialProps;
    },
    normalizeRepeatedSlashes: function() {
        return normalizeRepeatedSlashes;
    },
    stringifyError: function() {
        return stringifyError;
    }
});
const WEB_VITALS = [
    'CLS',
    'FCP',
    'FID',
    'INP',
    'LCP',
    'TTFB'
];
function execOnce(fn) {
    let used = false;
    let result;
    return (...args)=>{
        if (!used) {
            used = true;
            result = fn(...args);
        }
        return result;
    };
}
// Scheme: https://tools.ietf.org/html/rfc3986#section-3.1
// Absolute URL: https://tools.ietf.org/html/rfc3986#section-4.3
const ABSOLUTE_URL_REGEX = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/;
const isAbsoluteUrl = (url)=>ABSOLUTE_URL_REGEX.test(url);
function getLocationOrigin() {
    const { protocol, hostname, port } = window.location;
    return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}
function getURL() {
    const { href } = window.location;
    const origin = getLocationOrigin();
    return href.substring(origin.length);
}
function getDisplayName(Component) {
    return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}
function isResSent(res) {
    return res.finished || res.headersSent;
}
function normalizeRepeatedSlashes(url) {
    const urlParts = url.split('?');
    const urlNoQuery = urlParts[0];
    return urlNoQuery // first we replace any non-encoded backslashes with forward
    // then normalize repeated forward slashes
    .replace(/\\/g, '/').replace(/\/\/+/g, '/') + (urlParts[1] ? `?${urlParts.slice(1).join('?')}` : '');
}
async function loadGetInitialProps(App, ctx) {
    if ("TURBOPACK compile-time truthy", 1) {
        if (App.prototype?.getInitialProps) {
            const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://nextjs.org/docs/messages/get-initial-props-as-an-instance-method for more information.`;
            throw Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
                value: "E394",
                enumerable: false,
                configurable: true
            });
        }
    }
    // when called from _app `ctx` is nested in `ctx`
    const res = ctx.res || ctx.ctx && ctx.ctx.res;
    if (!App.getInitialProps) {
        if (ctx.ctx && ctx.Component) {
            // @ts-ignore pageProps default
            return {
                pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
            };
        }
        return {};
    }
    const props = await App.getInitialProps(ctx);
    if (res && isResSent(res)) {
        return props;
    }
    if (!props) {
        const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
        throw Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    if ("TURBOPACK compile-time truthy", 1) {
        if (Object.keys(props).length === 0 && !ctx.ctx) {
            console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://nextjs.org/docs/messages/empty-object-getInitialProps`);
        }
    }
    return props;
}
const SP = typeof performance !== 'undefined';
const ST = SP && [
    'mark',
    'measure',
    'getEntriesByName'
].every((method)=>typeof performance[method] === 'function');
class DecodeError extends Error {
}
class NormalizeError extends Error {
}
class PageNotFoundError extends Error {
    constructor(page){
        super();
        this.code = 'ENOENT';
        this.name = 'PageNotFoundError';
        this.message = `Cannot find module for page: ${page}`;
    }
}
class MissingStaticPage extends Error {
    constructor(page, message){
        super();
        this.message = `Failed to load static file for page: ${page} ${message}`;
    }
}
class MiddlewareNotFoundError extends Error {
    constructor(){
        super();
        this.code = 'ENOENT';
        this.message = `Cannot find the middleware module`;
    }
}
function stringifyError(error) {
    return JSON.stringify({
        message: error.message,
        stack: error.stack
    });
} //# sourceMappingURL=utils.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/is-local-url.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isLocalURL", {
    enumerable: true,
    get: function() {
        return isLocalURL;
    }
});
const _utils = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
const _hasbasepath = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/has-base-path.js [app-client] (ecmascript)");
function isLocalURL(url) {
    // prevent a hydration mismatch on href for url with anchor refs
    if (!(0, _utils.isAbsoluteUrl)(url)) return true;
    try {
        // absolute urls can be local if they are on the same origin
        const locationOrigin = (0, _utils.getLocationOrigin)();
        const resolved = new URL(url, locationOrigin);
        return resolved.origin === locationOrigin && (0, _hasbasepath.hasBasePath)(resolved.pathname);
    } catch (_) {
        return false;
    }
} //# sourceMappingURL=is-local-url.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "errorOnce", {
    enumerable: true,
    get: function() {
        return errorOnce;
    }
});
let errorOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const errors = new Set();
    errorOnce = (msg)=>{
        if (!errors.has(msg)) {
            console.error(msg);
        }
        errors.add(msg);
    };
} //# sourceMappingURL=error-once.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    useLinkStatus: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * A React component that extends the HTML `<a>` element to provide
 * [prefetching](https://nextjs.org/docs/app/building-your-application/routing/linking-and-navigating#2-prefetching)
 * and client-side navigation. This is the primary way to navigate between routes in Next.js.
 *
 * @remarks
 * - Prefetching is only enabled in production.
 *
 * @see https://nextjs.org/docs/app/api-reference/components/link
 */ default: function() {
        return LinkComponent;
    },
    useLinkStatus: function() {
        return useLinkStatus;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _formaturl = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/format-url.js [app-client] (ecmascript)");
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _usemergedref = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)");
const _utils = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
const _addbasepath = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/add-base-path.js [app-client] (ecmascript)");
const _warnonce = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)");
const _links = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/components/links.js [app-client] (ecmascript)");
const _islocalurl = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/router/utils/is-local-url.js [app-client] (ecmascript)");
const _types = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/components/segment-cache/types.js [app-client] (ecmascript)");
const _erroronce = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)");
function isModifiedEvent(event) {
    const eventTarget = event.currentTarget;
    const target = eventTarget.getAttribute('target');
    return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
    event.nativeEvent && event.nativeEvent.which === 2;
}
function linkClicked(e, href, as, linkInstanceRef, replace, scroll, onNavigate) {
    if (typeof window !== 'undefined') {
        const { nodeName } = e.currentTarget;
        // anchors inside an svg have a lowercase nodeName
        const isAnchorNodeName = nodeName.toUpperCase() === 'A';
        if (isAnchorNodeName && isModifiedEvent(e) || e.currentTarget.hasAttribute('download')) {
            // ignore click for browser’s default behavior
            return;
        }
        if (!(0, _islocalurl.isLocalURL)(href)) {
            if (replace) {
                // browser default behavior does not replace the history state
                // so we need to do it manually
                e.preventDefault();
                location.replace(href);
            }
            // ignore click for browser’s default behavior
            return;
        }
        e.preventDefault();
        if (onNavigate) {
            let isDefaultPrevented = false;
            onNavigate({
                preventDefault: ()=>{
                    isDefaultPrevented = true;
                }
            });
            if (isDefaultPrevented) {
                return;
            }
        }
        const { dispatchNavigateAction } = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/components/app-router-instance.js [app-client] (ecmascript)");
        _react.default.startTransition(()=>{
            dispatchNavigateAction(as || href, replace ? 'replace' : 'push', scroll ?? true, linkInstanceRef.current);
        });
    }
}
function formatStringOrUrl(urlObjOrString) {
    if (typeof urlObjOrString === 'string') {
        return urlObjOrString;
    }
    return (0, _formaturl.formatUrl)(urlObjOrString);
}
function LinkComponent(props) {
    const [linkStatus, setOptimisticLinkStatus] = (0, _react.useOptimistic)(_links.IDLE_LINK_STATUS);
    let children;
    const linkInstanceRef = (0, _react.useRef)(null);
    const { href: hrefProp, as: asProp, children: childrenProp, prefetch: prefetchProp = null, passHref, replace, shallow, scroll, onClick, onMouseEnter: onMouseEnterProp, onTouchStart: onTouchStartProp, legacyBehavior = false, onNavigate, ref: forwardedRef, unstable_dynamicOnHover, ...restProps } = props;
    children = childrenProp;
    if (legacyBehavior && (typeof children === 'string' || typeof children === 'number')) {
        children = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            children: children
        });
    }
    const router = _react.default.useContext(_approutercontextsharedruntime.AppRouterContext);
    const prefetchEnabled = prefetchProp !== false;
    const fetchStrategy = prefetchProp !== false ? getFetchStrategyFromPrefetchProp(prefetchProp) : _types.FetchStrategy.PPR;
    if ("TURBOPACK compile-time truthy", 1) {
        function createPropError(args) {
            return Object.defineProperty(new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + (typeof window !== 'undefined' ? "\nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                value: "E319",
                enumerable: false,
                configurable: true
            });
        }
        // TypeScript trick for type-guarding:
        const requiredPropsGuard = {
            href: true
        };
        const requiredProps = Object.keys(requiredPropsGuard);
        requiredProps.forEach((key)=>{
            if (key === 'href') {
                if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: props[key] === null ? 'null' : typeof props[key]
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                const _ = key;
            }
        });
        // TypeScript trick for type-guarding:
        const optionalPropsGuard = {
            as: true,
            replace: true,
            scroll: true,
            shallow: true,
            passHref: true,
            prefetch: true,
            unstable_dynamicOnHover: true,
            onClick: true,
            onMouseEnter: true,
            onTouchStart: true,
            legacyBehavior: true,
            onNavigate: true
        };
        const optionalProps = Object.keys(optionalPropsGuard);
        optionalProps.forEach((key)=>{
            const valType = typeof props[key];
            if (key === 'as') {
                if (props[key] && valType !== 'string' && valType !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: valType
                    });
                }
            } else if (key === 'onClick' || key === 'onMouseEnter' || key === 'onTouchStart' || key === 'onNavigate') {
                if (props[key] && valType !== 'function') {
                    throw createPropError({
                        key,
                        expected: '`function`',
                        actual: valType
                    });
                }
            } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'legacyBehavior' || key === 'unstable_dynamicOnHover') {
                if (props[key] != null && valType !== 'boolean') {
                    throw createPropError({
                        key,
                        expected: '`boolean`',
                        actual: valType
                    });
                }
            } else if (key === 'prefetch') {
                if (props[key] != null && valType !== 'boolean' && props[key] !== 'auto') {
                    throw createPropError({
                        key,
                        expected: '`boolean | "auto"`',
                        actual: valType
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                const _ = key;
            }
        });
    }
    if ("TURBOPACK compile-time truthy", 1) {
        if (props.locale) {
            (0, _warnonce.warnOnce)('The `locale` prop is not supported in `next/link` while using the `app` router. Read more about app router internalization: https://nextjs.org/docs/app/building-your-application/routing/internationalization');
        }
        if (!asProp) {
            let href;
            if (typeof hrefProp === 'string') {
                href = hrefProp;
            } else if (typeof hrefProp === 'object' && typeof hrefProp.pathname === 'string') {
                href = hrefProp.pathname;
            }
            if (href) {
                const hasDynamicSegment = href.split('/').some((segment)=>segment.startsWith('[') && segment.endsWith(']'));
                if (hasDynamicSegment) {
                    throw Object.defineProperty(new Error(`Dynamic href \`${href}\` found in <Link> while using the \`/app\` router, this is not supported. Read more: https://nextjs.org/docs/messages/app-dir-dynamic-href`), "__NEXT_ERROR_CODE", {
                        value: "E267",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
        }
    }
    const { href, as } = _react.default.useMemo({
        "LinkComponent.useMemo": ()=>{
            const resolvedHref = formatStringOrUrl(hrefProp);
            return {
                href: resolvedHref,
                as: asProp ? formatStringOrUrl(asProp) : resolvedHref
            };
        }
    }["LinkComponent.useMemo"], [
        hrefProp,
        asProp
    ]);
    // This will return the first child, if multiple are provided it will throw an error
    let child;
    if (legacyBehavior) {
        if (children?.$$typeof === Symbol.for('react.lazy')) {
            throw Object.defineProperty(new Error(`\`<Link legacyBehavior>\` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's \`<a>\` tag.`), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: false,
                configurable: true
            });
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if (onClick) {
                console.warn(`"onClick" was passed to <Link> with \`href\` of \`${hrefProp}\` but "legacyBehavior" was set. The legacy behavior requires onClick be set on the child of next/link`);
            }
            if (onMouseEnterProp) {
                console.warn(`"onMouseEnter" was passed to <Link> with \`href\` of \`${hrefProp}\` but "legacyBehavior" was set. The legacy behavior requires onMouseEnter be set on the child of next/link`);
            }
            try {
                child = _react.default.Children.only(children);
            } catch (err) {
                if (!children) {
                    throw Object.defineProperty(new Error(`No children were passed to <Link> with \`href\` of \`${hrefProp}\` but one child is required https://nextjs.org/docs/messages/link-no-children`), "__NEXT_ERROR_CODE", {
                        value: "E320",
                        enumerable: false,
                        configurable: true
                    });
                }
                throw Object.defineProperty(new Error(`Multiple children were passed to <Link> with \`href\` of \`${hrefProp}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + (typeof window !== 'undefined' ? " \nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                    value: "E266",
                    enumerable: false,
                    configurable: true
                });
            }
        } else //TURBOPACK unreachable
        ;
    } else {
        if ("TURBOPACK compile-time truthy", 1) {
            if (children?.type === 'a') {
                throw Object.defineProperty(new Error('Invalid <Link> with <a> child. Please remove <a> or use <Link legacyBehavior>.\nLearn more: https://nextjs.org/docs/messages/invalid-new-link-with-extra-anchor'), "__NEXT_ERROR_CODE", {
                    value: "E209",
                    enumerable: false,
                    configurable: true
                });
            }
        }
    }
    const childRef = legacyBehavior ? child && typeof child === 'object' && child.ref : forwardedRef;
    // Use a callback ref to attach an IntersectionObserver to the anchor tag on
    // mount. In the future we will also use this to keep track of all the
    // currently mounted <Link> instances, e.g. so we can re-prefetch them after
    // a revalidation or refresh.
    const observeLinkVisibilityOnMount = _react.default.useCallback({
        "LinkComponent.useCallback[observeLinkVisibilityOnMount]": (element)=>{
            if (router !== null) {
                linkInstanceRef.current = (0, _links.mountLinkInstance)(element, href, router, fetchStrategy, prefetchEnabled, setOptimisticLinkStatus);
            }
            return ({
                "LinkComponent.useCallback[observeLinkVisibilityOnMount]": ()=>{
                    if (linkInstanceRef.current) {
                        (0, _links.unmountLinkForCurrentNavigation)(linkInstanceRef.current);
                        linkInstanceRef.current = null;
                    }
                    (0, _links.unmountPrefetchableInstance)(element);
                }
            })["LinkComponent.useCallback[observeLinkVisibilityOnMount]"];
        }
    }["LinkComponent.useCallback[observeLinkVisibilityOnMount]"], [
        prefetchEnabled,
        href,
        router,
        fetchStrategy,
        setOptimisticLinkStatus
    ]);
    const mergedRef = (0, _usemergedref.useMergedRef)(observeLinkVisibilityOnMount, childRef);
    const childProps = {
        ref: mergedRef,
        onClick (e) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (!e) {
                    throw Object.defineProperty(new Error(`Component rendered inside next/link has to pass click event to "onClick" prop.`), "__NEXT_ERROR_CODE", {
                        value: "E312",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
            if (!legacyBehavior && typeof onClick === 'function') {
                onClick(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onClick === 'function') {
                child.props.onClick(e);
            }
            if (!router) {
                return;
            }
            if (e.defaultPrevented) {
                return;
            }
            linkClicked(e, href, as, linkInstanceRef, replace, scroll, onNavigate);
        },
        onMouseEnter (e) {
            if (!legacyBehavior && typeof onMouseEnterProp === 'function') {
                onMouseEnterProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onMouseEnter === 'function') {
                child.props.onMouseEnter(e);
            }
            if (!router) {
                return;
            }
            if ("TURBOPACK compile-time truthy", 1) {
                return;
            }
            //TURBOPACK unreachable
            ;
            const upgradeToDynamicPrefetch = undefined;
        },
        onTouchStart: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : function onTouchStart(e) {
            if (!legacyBehavior && typeof onTouchStartProp === 'function') {
                onTouchStartProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onTouchStart === 'function') {
                child.props.onTouchStart(e);
            }
            if (!router) {
                return;
            }
            if (!prefetchEnabled) {
                return;
            }
            const upgradeToDynamicPrefetch = unstable_dynamicOnHover === true;
            (0, _links.onNavigationIntent)(e.currentTarget, upgradeToDynamicPrefetch);
        }
    };
    // If the url is absolute, we can bypass the logic to prepend the basePath.
    if ((0, _utils.isAbsoluteUrl)(as)) {
        childProps.href = as;
    } else if (!legacyBehavior || passHref || child.type === 'a' && !('href' in child.props)) {
        childProps.href = (0, _addbasepath.addBasePath)(as);
    }
    let link;
    if (legacyBehavior) {
        if ("TURBOPACK compile-time truthy", 1) {
            (0, _erroronce.errorOnce)('`legacyBehavior` is deprecated and will be removed in a future ' + 'release. A codemod is available to upgrade your components:\n\n' + 'npx @next/codemod@latest new-link .\n\n' + 'Learn more: https://nextjs.org/docs/app/building-your-application/upgrading/codemods#remove-a-tags-from-link-components');
        }
        link = /*#__PURE__*/ _react.default.cloneElement(child, childProps);
    } else {
        link = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            ...restProps,
            ...childProps,
            children: children
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(LinkStatusContext.Provider, {
        value: linkStatus,
        children: link
    });
}
const LinkStatusContext = /*#__PURE__*/ (0, _react.createContext)(_links.IDLE_LINK_STATUS);
const useLinkStatus = ()=>{
    return (0, _react.useContext)(LinkStatusContext);
};
function getFetchStrategyFromPrefetchProp(prefetchProp) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return prefetchProp === null || prefetchProp === 'auto' ? _types.FetchStrategy.PPR : // (although invalid values should've been filtered out by prop validation in dev)
        _types.FetchStrategy.Full;
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=link.js.map
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*!
  * Bootstrap v5.3.8 (https://getbootstrap.com/)
  * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
  */ !function(t, e) {
    ("TURBOPACK compile-time truthy", 1) ? module.exports = e() : "TURBOPACK unreachable";
}(/*TURBOPACK member replacement*/ __turbopack_context__.e, function() {
    "use strict";
    const t = new Map, e = {
        set (e, i, n) {
            t.has(e) || t.set(e, new Map);
            const s = t.get(e);
            s.has(i) || 0 === s.size ? s.set(i, n) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(s.keys())[0]}.`);
        },
        get: (e, i)=>t.has(e) && t.get(e).get(i) || null,
        remove (e, i) {
            if (!t.has(e)) return;
            const n = t.get(e);
            n.delete(i), 0 === n.size && t.delete(e);
        }
    }, i = "transitionend", n = (t)=>(t && window.CSS && window.CSS.escape && (t = t.replace(/#([^\s"#']+)/g, (t, e)=>`#${CSS.escape(e)}`)), t), s = (t)=>null == t ? `${t}` : Object.prototype.toString.call(t).match(/\s([a-z]+)/i)[1].toLowerCase(), o = (t)=>{
        t.dispatchEvent(new Event(i));
    }, r = (t)=>!(!t || "object" != typeof t) && (void 0 !== t.jquery && (t = t[0]), void 0 !== t.nodeType), a = (t)=>r(t) ? t.jquery ? t[0] : t : "string" == typeof t && t.length > 0 ? document.querySelector(n(t)) : null, l = (t)=>{
        if (!r(t) || 0 === t.getClientRects().length) return !1;
        const e = "visible" === getComputedStyle(t).getPropertyValue("visibility"), i = t.closest("details:not([open])");
        if (!i) return e;
        if (i !== t) {
            const e = t.closest("summary");
            if (e && e.parentNode !== i) return !1;
            if (null === e) return !1;
        }
        return e;
    }, c = (t)=>!t || t.nodeType !== Node.ELEMENT_NODE || !!t.classList.contains("disabled") || (void 0 !== t.disabled ? t.disabled : t.hasAttribute("disabled") && "false" !== t.getAttribute("disabled")), h = (t)=>{
        if (!document.documentElement.attachShadow) return null;
        if ("function" == typeof t.getRootNode) {
            const e = t.getRootNode();
            return e instanceof ShadowRoot ? e : null;
        }
        return t instanceof ShadowRoot ? t : t.parentNode ? h(t.parentNode) : null;
    }, d = ()=>{}, u = (t)=>{
        t.offsetHeight;
    }, f = ()=>window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null, p = [], m = ()=>"rtl" === document.documentElement.dir, g = (t)=>{
        var e;
        e = ()=>{
            const e = f();
            if (e) {
                const i = t.NAME, n = e.fn[i];
                e.fn[i] = t.jQueryInterface, e.fn[i].Constructor = t, e.fn[i].noConflict = ()=>(e.fn[i] = n, t.jQueryInterface);
            }
        }, "loading" === document.readyState ? (p.length || document.addEventListener("DOMContentLoaded", ()=>{
            for (const t of p)t();
        }), p.push(e)) : e();
    }, _ = (t, e = [], i = t)=>"function" == typeof t ? t.call(...e) : i, b = (t, e, n = !0)=>{
        if (!n) return void _(t);
        const s = ((t)=>{
            if (!t) return 0;
            let { transitionDuration: e, transitionDelay: i } = window.getComputedStyle(t);
            const n = Number.parseFloat(e), s = Number.parseFloat(i);
            return n || s ? (e = e.split(",")[0], i = i.split(",")[0], 1e3 * (Number.parseFloat(e) + Number.parseFloat(i))) : 0;
        })(e) + 5;
        let r = !1;
        const a = ({ target: n })=>{
            n === e && (r = !0, e.removeEventListener(i, a), _(t));
        };
        e.addEventListener(i, a), setTimeout(()=>{
            r || o(e);
        }, s);
    }, v = (t, e, i, n)=>{
        const s = t.length;
        let o = t.indexOf(e);
        return -1 === o ? !i && n ? t[s - 1] : t[0] : (o += i ? 1 : -1, n && (o = (o + s) % s), t[Math.max(0, Math.min(o, s - 1))]);
    }, y = /[^.]*(?=\..*)\.|.*/, w = /\..*/, A = /::\d+$/, E = {};
    let T = 1;
    const C = {
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, O = new Set([
        "click",
        "dblclick",
        "mouseup",
        "mousedown",
        "contextmenu",
        "mousewheel",
        "DOMMouseScroll",
        "mouseover",
        "mouseout",
        "mousemove",
        "selectstart",
        "selectend",
        "keydown",
        "keypress",
        "keyup",
        "orientationchange",
        "touchstart",
        "touchmove",
        "touchend",
        "touchcancel",
        "pointerdown",
        "pointermove",
        "pointerup",
        "pointerleave",
        "pointercancel",
        "gesturestart",
        "gesturechange",
        "gestureend",
        "focus",
        "blur",
        "change",
        "reset",
        "select",
        "submit",
        "focusin",
        "focusout",
        "load",
        "unload",
        "beforeunload",
        "resize",
        "move",
        "DOMContentLoaded",
        "readystatechange",
        "error",
        "abort",
        "scroll"
    ]);
    function x(t, e) {
        return e && `${e}::${T++}` || t.uidEvent || T++;
    }
    function k(t) {
        const e = x(t);
        return t.uidEvent = e, E[e] = E[e] || {}, E[e];
    }
    function L(t, e, i = null) {
        return Object.values(t).find((t)=>t.callable === e && t.delegationSelector === i);
    }
    function S(t, e, i) {
        const n = "string" == typeof e, s = n ? i : e || i;
        let o = N(t);
        return O.has(o) || (o = t), [
            n,
            s,
            o
        ];
    }
    function D(t, e, i, n, s) {
        if ("string" != typeof e || !t) return;
        let [o, r, a] = S(e, i, n);
        if (e in C) {
            const t = (t)=>function(e) {
                    if (!e.relatedTarget || e.relatedTarget !== e.delegateTarget && !e.delegateTarget.contains(e.relatedTarget)) return t.call(this, e);
                };
            r = t(r);
        }
        const l = k(t), c = l[a] || (l[a] = {}), h = L(c, r, o ? i : null);
        if (h) return void (h.oneOff = h.oneOff && s);
        const d = x(r, e.replace(y, "")), u = o ? function(t, e, i) {
            return function n(s) {
                const o = t.querySelectorAll(e);
                for(let { target: r } = s; r && r !== this; r = r.parentNode)for (const a of o)if (a === r) return j(s, {
                    delegateTarget: r
                }), n.oneOff && P.off(t, s.type, e, i), i.apply(r, [
                    s
                ]);
            };
        }(t, i, r) : function(t, e) {
            return function i(n) {
                return j(n, {
                    delegateTarget: t
                }), i.oneOff && P.off(t, n.type, e), e.apply(t, [
                    n
                ]);
            };
        }(t, r);
        u.delegationSelector = o ? i : null, u.callable = r, u.oneOff = s, u.uidEvent = d, c[d] = u, t.addEventListener(a, u, o);
    }
    function $(t, e, i, n, s) {
        const o = L(e[i], n, s);
        o && (t.removeEventListener(i, o, Boolean(s)), delete e[i][o.uidEvent]);
    }
    function I(t, e, i, n) {
        const s = e[i] || {};
        for (const [o, r] of Object.entries(s))o.includes(n) && $(t, e, i, r.callable, r.delegationSelector);
    }
    function N(t) {
        return t = t.replace(w, ""), C[t] || t;
    }
    const P = {
        on (t, e, i, n) {
            D(t, e, i, n, !1);
        },
        one (t, e, i, n) {
            D(t, e, i, n, !0);
        },
        off (t, e, i, n) {
            if ("string" != typeof e || !t) return;
            const [s, o, r] = S(e, i, n), a = r !== e, l = k(t), c = l[r] || {}, h = e.startsWith(".");
            if (void 0 === o) {
                if (h) for (const i of Object.keys(l))I(t, l, i, e.slice(1));
                for (const [i, n] of Object.entries(c)){
                    const s = i.replace(A, "");
                    a && !e.includes(s) || $(t, l, r, n.callable, n.delegationSelector);
                }
            } else {
                if (!Object.keys(c).length) return;
                $(t, l, r, o, s ? i : null);
            }
        },
        trigger (t, e, i) {
            if ("string" != typeof e || !t) return null;
            const n = f();
            let s = null, o = !0, r = !0, a = !1;
            e !== N(e) && n && (s = n.Event(e, i), n(t).trigger(s), o = !s.isPropagationStopped(), r = !s.isImmediatePropagationStopped(), a = s.isDefaultPrevented());
            const l = j(new Event(e, {
                bubbles: o,
                cancelable: !0
            }), i);
            return a && l.preventDefault(), r && t.dispatchEvent(l), l.defaultPrevented && s && s.preventDefault(), l;
        }
    };
    function j(t, e = {}) {
        for (const [i, n] of Object.entries(e))try {
            t[i] = n;
        } catch (e) {
            Object.defineProperty(t, i, {
                configurable: !0,
                get: ()=>n
            });
        }
        return t;
    }
    function M(t) {
        if ("true" === t) return !0;
        if ("false" === t) return !1;
        if (t === Number(t).toString()) return Number(t);
        if ("" === t || "null" === t) return null;
        if ("string" != typeof t) return t;
        try {
            return JSON.parse(decodeURIComponent(t));
        } catch (e) {
            return t;
        }
    }
    function F(t) {
        return t.replace(/[A-Z]/g, (t)=>`-${t.toLowerCase()}`);
    }
    const H = {
        setDataAttribute (t, e, i) {
            t.setAttribute(`data-bs-${F(e)}`, i);
        },
        removeDataAttribute (t, e) {
            t.removeAttribute(`data-bs-${F(e)}`);
        },
        getDataAttributes (t) {
            if (!t) return {};
            const e = {}, i = Object.keys(t.dataset).filter((t)=>t.startsWith("bs") && !t.startsWith("bsConfig"));
            for (const n of i){
                let i = n.replace(/^bs/, "");
                i = i.charAt(0).toLowerCase() + i.slice(1), e[i] = M(t.dataset[n]);
            }
            return e;
        },
        getDataAttribute: (t, e)=>M(t.getAttribute(`data-bs-${F(e)}`))
    };
    class W {
        static get Default() {
            return {};
        }
        static get DefaultType() {
            return {};
        }
        static get NAME() {
            throw new Error('You have to implement the static method "NAME", for each component!');
        }
        _getConfig(t) {
            return t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
        }
        _configAfterMerge(t) {
            return t;
        }
        _mergeConfigObj(t, e) {
            const i = r(e) ? H.getDataAttribute(e, "config") : {};
            return {
                ...this.constructor.Default,
                ..."object" == typeof i ? i : {},
                ...r(e) ? H.getDataAttributes(e) : {},
                ..."object" == typeof t ? t : {}
            };
        }
        _typeCheckConfig(t, e = this.constructor.DefaultType) {
            for (const [i, n] of Object.entries(e)){
                const e = t[i], o = r(e) ? "element" : s(e);
                if (!new RegExp(n).test(o)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${n}".`);
            }
        }
    }
    class B extends W {
        constructor(t, i){
            super(), (t = a(t)) && (this._element = t, this._config = this._getConfig(i), e.set(this._element, this.constructor.DATA_KEY, this));
        }
        dispose() {
            e.remove(this._element, this.constructor.DATA_KEY), P.off(this._element, this.constructor.EVENT_KEY);
            for (const t of Object.getOwnPropertyNames(this))this[t] = null;
        }
        _queueCallback(t, e, i = !0) {
            b(t, e, i);
        }
        _getConfig(t) {
            return t = this._mergeConfigObj(t, this._element), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
        }
        static getInstance(t) {
            return e.get(a(t), this.DATA_KEY);
        }
        static getOrCreateInstance(t, e = {}) {
            return this.getInstance(t) || new this(t, "object" == typeof e ? e : null);
        }
        static get VERSION() {
            return "5.3.8";
        }
        static get DATA_KEY() {
            return `bs.${this.NAME}`;
        }
        static get EVENT_KEY() {
            return `.${this.DATA_KEY}`;
        }
        static eventName(t) {
            return `${t}${this.EVENT_KEY}`;
        }
    }
    const z = (t)=>{
        let e = t.getAttribute("data-bs-target");
        if (!e || "#" === e) {
            let i = t.getAttribute("href");
            if (!i || !i.includes("#") && !i.startsWith(".")) return null;
            i.includes("#") && !i.startsWith("#") && (i = `#${i.split("#")[1]}`), e = i && "#" !== i ? i.trim() : null;
        }
        return e ? e.split(",").map((t)=>n(t)).join(",") : null;
    }, R = {
        find: (t, e = document.documentElement)=>[].concat(...Element.prototype.querySelectorAll.call(e, t)),
        findOne: (t, e = document.documentElement)=>Element.prototype.querySelector.call(e, t),
        children: (t, e)=>[].concat(...t.children).filter((t)=>t.matches(e)),
        parents (t, e) {
            const i = [];
            let n = t.parentNode.closest(e);
            for(; n;)i.push(n), n = n.parentNode.closest(e);
            return i;
        },
        prev (t, e) {
            let i = t.previousElementSibling;
            for(; i;){
                if (i.matches(e)) return [
                    i
                ];
                i = i.previousElementSibling;
            }
            return [];
        },
        next (t, e) {
            let i = t.nextElementSibling;
            for(; i;){
                if (i.matches(e)) return [
                    i
                ];
                i = i.nextElementSibling;
            }
            return [];
        },
        focusableChildren (t) {
            const e = [
                "a",
                "button",
                "input",
                "textarea",
                "select",
                "details",
                "[tabindex]",
                '[contenteditable="true"]'
            ].map((t)=>`${t}:not([tabindex^="-"])`).join(",");
            return this.find(e, t).filter((t)=>!c(t) && l(t));
        },
        getSelectorFromElement (t) {
            const e = z(t);
            return e && R.findOne(e) ? e : null;
        },
        getElementFromSelector (t) {
            const e = z(t);
            return e ? R.findOne(e) : null;
        },
        getMultipleElementsFromSelector (t) {
            const e = z(t);
            return e ? R.find(e) : [];
        }
    }, q = (t, e = "hide")=>{
        const i = `click.dismiss${t.EVENT_KEY}`, n = t.NAME;
        P.on(document, i, `[data-bs-dismiss="${n}"]`, function(i) {
            if ([
                "A",
                "AREA"
            ].includes(this.tagName) && i.preventDefault(), c(this)) return;
            const s = R.getElementFromSelector(this) || this.closest(`.${n}`);
            t.getOrCreateInstance(s)[e]();
        });
    }, V = ".bs.alert", K = `close${V}`, Q = `closed${V}`;
    class X extends B {
        static get NAME() {
            return "alert";
        }
        close() {
            if (P.trigger(this._element, K).defaultPrevented) return;
            this._element.classList.remove("show");
            const t = this._element.classList.contains("fade");
            this._queueCallback(()=>this._destroyElement(), this._element, t);
        }
        _destroyElement() {
            this._element.remove(), P.trigger(this._element, Q), this.dispose();
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = X.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t](this);
                }
            });
        }
    }
    q(X, "close"), g(X);
    const Y = '[data-bs-toggle="button"]';
    class U extends B {
        static get NAME() {
            return "button";
        }
        toggle() {
            this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"));
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = U.getOrCreateInstance(this);
                "toggle" === t && e[t]();
            });
        }
    }
    P.on(document, "click.bs.button.data-api", Y, (t)=>{
        t.preventDefault();
        const e = t.target.closest(Y);
        U.getOrCreateInstance(e).toggle();
    }), g(U);
    const G = ".bs.swipe", J = `touchstart${G}`, Z = `touchmove${G}`, tt = `touchend${G}`, et = `pointerdown${G}`, it = `pointerup${G}`, nt = {
        endCallback: null,
        leftCallback: null,
        rightCallback: null
    }, st = {
        endCallback: "(function|null)",
        leftCallback: "(function|null)",
        rightCallback: "(function|null)"
    };
    class ot extends W {
        constructor(t, e){
            super(), this._element = t, t && ot.isSupported() && (this._config = this._getConfig(e), this._deltaX = 0, this._supportPointerEvents = Boolean(window.PointerEvent), this._initEvents());
        }
        static get Default() {
            return nt;
        }
        static get DefaultType() {
            return st;
        }
        static get NAME() {
            return "swipe";
        }
        dispose() {
            P.off(this._element, G);
        }
        _start(t) {
            this._supportPointerEvents ? this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX) : this._deltaX = t.touches[0].clientX;
        }
        _end(t) {
            this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX - this._deltaX), this._handleSwipe(), _(this._config.endCallback);
        }
        _move(t) {
            this._deltaX = t.touches && t.touches.length > 1 ? 0 : t.touches[0].clientX - this._deltaX;
        }
        _handleSwipe() {
            const t = Math.abs(this._deltaX);
            if (t <= 40) return;
            const e = t / this._deltaX;
            this._deltaX = 0, e && _(e > 0 ? this._config.rightCallback : this._config.leftCallback);
        }
        _initEvents() {
            this._supportPointerEvents ? (P.on(this._element, et, (t)=>this._start(t)), P.on(this._element, it, (t)=>this._end(t)), this._element.classList.add("pointer-event")) : (P.on(this._element, J, (t)=>this._start(t)), P.on(this._element, Z, (t)=>this._move(t)), P.on(this._element, tt, (t)=>this._end(t)));
        }
        _eventIsPointerPenTouch(t) {
            return this._supportPointerEvents && ("pen" === t.pointerType || "touch" === t.pointerType);
        }
        static isSupported() {
            return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0;
        }
    }
    const rt = ".bs.carousel", at = ".data-api", lt = "ArrowLeft", ct = "ArrowRight", ht = "next", dt = "prev", ut = "left", ft = "right", pt = `slide${rt}`, mt = `slid${rt}`, gt = `keydown${rt}`, _t = `mouseenter${rt}`, bt = `mouseleave${rt}`, vt = `dragstart${rt}`, yt = `load${rt}${at}`, wt = `click${rt}${at}`, At = "carousel", Et = "active", Tt = ".active", Ct = ".carousel-item", Ot = Tt + Ct, xt = {
        [lt]: ft,
        [ct]: ut
    }, kt = {
        interval: 5e3,
        keyboard: !0,
        pause: "hover",
        ride: !1,
        touch: !0,
        wrap: !0
    }, Lt = {
        interval: "(number|boolean)",
        keyboard: "boolean",
        pause: "(string|boolean)",
        ride: "(boolean|string)",
        touch: "boolean",
        wrap: "boolean"
    };
    class St extends B {
        constructor(t, e){
            super(t, e), this._interval = null, this._activeElement = null, this._isSliding = !1, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = R.findOne(".carousel-indicators", this._element), this._addEventListeners(), this._config.ride === At && this.cycle();
        }
        static get Default() {
            return kt;
        }
        static get DefaultType() {
            return Lt;
        }
        static get NAME() {
            return "carousel";
        }
        next() {
            this._slide(ht);
        }
        nextWhenVisible() {
            !document.hidden && l(this._element) && this.next();
        }
        prev() {
            this._slide(dt);
        }
        pause() {
            this._isSliding && o(this._element), this._clearInterval();
        }
        cycle() {
            this._clearInterval(), this._updateInterval(), this._interval = setInterval(()=>this.nextWhenVisible(), this._config.interval);
        }
        _maybeEnableCycle() {
            this._config.ride && (this._isSliding ? P.one(this._element, mt, ()=>this.cycle()) : this.cycle());
        }
        to(t) {
            const e = this._getItems();
            if (t > e.length - 1 || t < 0) return;
            if (this._isSliding) return void P.one(this._element, mt, ()=>this.to(t));
            const i = this._getItemIndex(this._getActive());
            if (i === t) return;
            const n = t > i ? ht : dt;
            this._slide(n, e[t]);
        }
        dispose() {
            this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
        }
        _configAfterMerge(t) {
            return t.defaultInterval = t.interval, t;
        }
        _addEventListeners() {
            this._config.keyboard && P.on(this._element, gt, (t)=>this._keydown(t)), "hover" === this._config.pause && (P.on(this._element, _t, ()=>this.pause()), P.on(this._element, bt, ()=>this._maybeEnableCycle())), this._config.touch && ot.isSupported() && this._addTouchEventListeners();
        }
        _addTouchEventListeners() {
            for (const t of R.find(".carousel-item img", this._element))P.on(t, vt, (t)=>t.preventDefault());
            const t = {
                leftCallback: ()=>this._slide(this._directionToOrder(ut)),
                rightCallback: ()=>this._slide(this._directionToOrder(ft)),
                endCallback: ()=>{
                    "hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(()=>this._maybeEnableCycle(), 500 + this._config.interval));
                }
            };
            this._swipeHelper = new ot(this._element, t);
        }
        _keydown(t) {
            if (/input|textarea/i.test(t.target.tagName)) return;
            const e = xt[t.key];
            e && (t.preventDefault(), this._slide(this._directionToOrder(e)));
        }
        _getItemIndex(t) {
            return this._getItems().indexOf(t);
        }
        _setActiveIndicatorElement(t) {
            if (!this._indicatorsElement) return;
            const e = R.findOne(Tt, this._indicatorsElement);
            e.classList.remove(Et), e.removeAttribute("aria-current");
            const i = R.findOne(`[data-bs-slide-to="${t}"]`, this._indicatorsElement);
            i && (i.classList.add(Et), i.setAttribute("aria-current", "true"));
        }
        _updateInterval() {
            const t = this._activeElement || this._getActive();
            if (!t) return;
            const e = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
            this._config.interval = e || this._config.defaultInterval;
        }
        _slide(t, e = null) {
            if (this._isSliding) return;
            const i = this._getActive(), n = t === ht, s = e || v(this._getItems(), i, n, this._config.wrap);
            if (s === i) return;
            const o = this._getItemIndex(s), r = (e)=>P.trigger(this._element, e, {
                    relatedTarget: s,
                    direction: this._orderToDirection(t),
                    from: this._getItemIndex(i),
                    to: o
                });
            if (r(pt).defaultPrevented) return;
            if (!i || !s) return;
            const a = Boolean(this._interval);
            this.pause(), this._isSliding = !0, this._setActiveIndicatorElement(o), this._activeElement = s;
            const l = n ? "carousel-item-start" : "carousel-item-end", c = n ? "carousel-item-next" : "carousel-item-prev";
            s.classList.add(c), u(s), i.classList.add(l), s.classList.add(l), this._queueCallback(()=>{
                s.classList.remove(l, c), s.classList.add(Et), i.classList.remove(Et, c, l), this._isSliding = !1, r(mt);
            }, i, this._isAnimated()), a && this.cycle();
        }
        _isAnimated() {
            return this._element.classList.contains("slide");
        }
        _getActive() {
            return R.findOne(Ot, this._element);
        }
        _getItems() {
            return R.find(Ct, this._element);
        }
        _clearInterval() {
            this._interval && (clearInterval(this._interval), this._interval = null);
        }
        _directionToOrder(t) {
            return m() ? t === ut ? dt : ht : t === ut ? ht : dt;
        }
        _orderToDirection(t) {
            return m() ? t === dt ? ut : ft : t === dt ? ft : ut;
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = St.getOrCreateInstance(this, t);
                if ("number" != typeof t) {
                    if ("string" == typeof t) {
                        if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                        e[t]();
                    }
                } else e.to(t);
            });
        }
    }
    P.on(document, wt, "[data-bs-slide], [data-bs-slide-to]", function(t) {
        const e = R.getElementFromSelector(this);
        if (!e || !e.classList.contains(At)) return;
        t.preventDefault();
        const i = St.getOrCreateInstance(e), n = this.getAttribute("data-bs-slide-to");
        return n ? (i.to(n), void i._maybeEnableCycle()) : "next" === H.getDataAttribute(this, "slide") ? (i.next(), void i._maybeEnableCycle()) : (i.prev(), void i._maybeEnableCycle());
    }), P.on(window, yt, ()=>{
        const t = R.find('[data-bs-ride="carousel"]');
        for (const e of t)St.getOrCreateInstance(e);
    }), g(St);
    const Dt = ".bs.collapse", $t = `show${Dt}`, It = `shown${Dt}`, Nt = `hide${Dt}`, Pt = `hidden${Dt}`, jt = `click${Dt}.data-api`, Mt = "show", Ft = "collapse", Ht = "collapsing", Wt = `:scope .${Ft} .${Ft}`, Bt = '[data-bs-toggle="collapse"]', zt = {
        parent: null,
        toggle: !0
    }, Rt = {
        parent: "(null|element)",
        toggle: "boolean"
    };
    class qt extends B {
        constructor(t, e){
            super(t, e), this._isTransitioning = !1, this._triggerArray = [];
            const i = R.find(Bt);
            for (const t of i){
                const e = R.getSelectorFromElement(t), i = R.find(e).filter((t)=>t === this._element);
                null !== e && i.length && this._triggerArray.push(t);
            }
            this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle();
        }
        static get Default() {
            return zt;
        }
        static get DefaultType() {
            return Rt;
        }
        static get NAME() {
            return "collapse";
        }
        toggle() {
            this._isShown() ? this.hide() : this.show();
        }
        show() {
            if (this._isTransitioning || this._isShown()) return;
            let t = [];
            if (this._config.parent && (t = this._getFirstLevelChildren(".collapse.show, .collapse.collapsing").filter((t)=>t !== this._element).map((t)=>qt.getOrCreateInstance(t, {
                    toggle: !1
                }))), t.length && t[0]._isTransitioning) return;
            if (P.trigger(this._element, $t).defaultPrevented) return;
            for (const e of t)e.hide();
            const e = this._getDimension();
            this._element.classList.remove(Ft), this._element.classList.add(Ht), this._element.style[e] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
            const i = `scroll${e[0].toUpperCase() + e.slice(1)}`;
            this._queueCallback(()=>{
                this._isTransitioning = !1, this._element.classList.remove(Ht), this._element.classList.add(Ft, Mt), this._element.style[e] = "", P.trigger(this._element, It);
            }, this._element, !0), this._element.style[e] = `${this._element[i]}px`;
        }
        hide() {
            if (this._isTransitioning || !this._isShown()) return;
            if (P.trigger(this._element, Nt).defaultPrevented) return;
            const t = this._getDimension();
            this._element.style[t] = `${this._element.getBoundingClientRect()[t]}px`, u(this._element), this._element.classList.add(Ht), this._element.classList.remove(Ft, Mt);
            for (const t of this._triggerArray){
                const e = R.getElementFromSelector(t);
                e && !this._isShown(e) && this._addAriaAndCollapsedClass([
                    t
                ], !1);
            }
            this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(()=>{
                this._isTransitioning = !1, this._element.classList.remove(Ht), this._element.classList.add(Ft), P.trigger(this._element, Pt);
            }, this._element, !0);
        }
        _isShown(t = this._element) {
            return t.classList.contains(Mt);
        }
        _configAfterMerge(t) {
            return t.toggle = Boolean(t.toggle), t.parent = a(t.parent), t;
        }
        _getDimension() {
            return this._element.classList.contains("collapse-horizontal") ? "width" : "height";
        }
        _initializeChildren() {
            if (!this._config.parent) return;
            const t = this._getFirstLevelChildren(Bt);
            for (const e of t){
                const t = R.getElementFromSelector(e);
                t && this._addAriaAndCollapsedClass([
                    e
                ], this._isShown(t));
            }
        }
        _getFirstLevelChildren(t) {
            const e = R.find(Wt, this._config.parent);
            return R.find(t, this._config.parent).filter((t)=>!e.includes(t));
        }
        _addAriaAndCollapsedClass(t, e) {
            if (t.length) for (const i of t)i.classList.toggle("collapsed", !e), i.setAttribute("aria-expanded", e);
        }
        static jQueryInterface(t) {
            const e = {};
            return "string" == typeof t && /show|hide/.test(t) && (e.toggle = !1), this.each(function() {
                const i = qt.getOrCreateInstance(this, e);
                if ("string" == typeof t) {
                    if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
                    i[t]();
                }
            });
        }
    }
    P.on(document, jt, Bt, function(t) {
        ("A" === t.target.tagName || t.delegateTarget && "A" === t.delegateTarget.tagName) && t.preventDefault();
        for (const t of R.getMultipleElementsFromSelector(this))qt.getOrCreateInstance(t, {
            toggle: !1
        }).toggle();
    }), g(qt);
    var Vt = "top", Kt = "bottom", Qt = "right", Xt = "left", Yt = "auto", Ut = [
        Vt,
        Kt,
        Qt,
        Xt
    ], Gt = "start", Jt = "end", Zt = "clippingParents", te = "viewport", ee = "popper", ie = "reference", ne = Ut.reduce(function(t, e) {
        return t.concat([
            e + "-" + Gt,
            e + "-" + Jt
        ]);
    }, []), se = [].concat(Ut, [
        Yt
    ]).reduce(function(t, e) {
        return t.concat([
            e,
            e + "-" + Gt,
            e + "-" + Jt
        ]);
    }, []), oe = "beforeRead", re = "read", ae = "afterRead", le = "beforeMain", ce = "main", he = "afterMain", de = "beforeWrite", ue = "write", fe = "afterWrite", pe = [
        oe,
        re,
        ae,
        le,
        ce,
        he,
        de,
        ue,
        fe
    ];
    function me(t) {
        return t ? (t.nodeName || "").toLowerCase() : null;
    }
    function ge(t) {
        if (null == t) return window;
        if ("[object Window]" !== t.toString()) {
            var e = t.ownerDocument;
            return e && e.defaultView || window;
        }
        return t;
    }
    function _e(t) {
        return t instanceof ge(t).Element || t instanceof Element;
    }
    function be(t) {
        return t instanceof ge(t).HTMLElement || t instanceof HTMLElement;
    }
    function ve(t) {
        return "undefined" != typeof ShadowRoot && (t instanceof ge(t).ShadowRoot || t instanceof ShadowRoot);
    }
    const ye = {
        name: "applyStyles",
        enabled: !0,
        phase: "write",
        fn: function(t) {
            var e = t.state;
            Object.keys(e.elements).forEach(function(t) {
                var i = e.styles[t] || {}, n = e.attributes[t] || {}, s = e.elements[t];
                be(s) && me(s) && (Object.assign(s.style, i), Object.keys(n).forEach(function(t) {
                    var e = n[t];
                    !1 === e ? s.removeAttribute(t) : s.setAttribute(t, !0 === e ? "" : e);
                }));
            });
        },
        effect: function(t) {
            var e = t.state, i = {
                popper: {
                    position: e.options.strategy,
                    left: "0",
                    top: "0",
                    margin: "0"
                },
                arrow: {
                    position: "absolute"
                },
                reference: {}
            };
            return Object.assign(e.elements.popper.style, i.popper), e.styles = i, e.elements.arrow && Object.assign(e.elements.arrow.style, i.arrow), function() {
                Object.keys(e.elements).forEach(function(t) {
                    var n = e.elements[t], s = e.attributes[t] || {}, o = Object.keys(e.styles.hasOwnProperty(t) ? e.styles[t] : i[t]).reduce(function(t, e) {
                        return t[e] = "", t;
                    }, {});
                    be(n) && me(n) && (Object.assign(n.style, o), Object.keys(s).forEach(function(t) {
                        n.removeAttribute(t);
                    }));
                });
            };
        },
        requires: [
            "computeStyles"
        ]
    };
    function we(t) {
        return t.split("-")[0];
    }
    var Ae = Math.max, Ee = Math.min, Te = Math.round;
    function Ce() {
        var t = navigator.userAgentData;
        return null != t && t.brands && Array.isArray(t.brands) ? t.brands.map(function(t) {
            return t.brand + "/" + t.version;
        }).join(" ") : navigator.userAgent;
    }
    function Oe() {
        return !/^((?!chrome|android).)*safari/i.test(Ce());
    }
    function xe(t, e, i) {
        void 0 === e && (e = !1), void 0 === i && (i = !1);
        var n = t.getBoundingClientRect(), s = 1, o = 1;
        e && be(t) && (s = t.offsetWidth > 0 && Te(n.width) / t.offsetWidth || 1, o = t.offsetHeight > 0 && Te(n.height) / t.offsetHeight || 1);
        var r = (_e(t) ? ge(t) : window).visualViewport, a = !Oe() && i, l = (n.left + (a && r ? r.offsetLeft : 0)) / s, c = (n.top + (a && r ? r.offsetTop : 0)) / o, h = n.width / s, d = n.height / o;
        return {
            width: h,
            height: d,
            top: c,
            right: l + h,
            bottom: c + d,
            left: l,
            x: l,
            y: c
        };
    }
    function ke(t) {
        var e = xe(t), i = t.offsetWidth, n = t.offsetHeight;
        return Math.abs(e.width - i) <= 1 && (i = e.width), Math.abs(e.height - n) <= 1 && (n = e.height), {
            x: t.offsetLeft,
            y: t.offsetTop,
            width: i,
            height: n
        };
    }
    function Le(t, e) {
        var i = e.getRootNode && e.getRootNode();
        if (t.contains(e)) return !0;
        if (i && ve(i)) {
            var n = e;
            do {
                if (n && t.isSameNode(n)) return !0;
                n = n.parentNode || n.host;
            }while (n)
        }
        return !1;
    }
    function Se(t) {
        return ge(t).getComputedStyle(t);
    }
    function De(t) {
        return [
            "table",
            "td",
            "th"
        ].indexOf(me(t)) >= 0;
    }
    function $e(t) {
        return ((_e(t) ? t.ownerDocument : t.document) || window.document).documentElement;
    }
    function Ie(t) {
        return "html" === me(t) ? t : t.assignedSlot || t.parentNode || (ve(t) ? t.host : null) || $e(t);
    }
    function Ne(t) {
        return be(t) && "fixed" !== Se(t).position ? t.offsetParent : null;
    }
    function Pe(t) {
        for(var e = ge(t), i = Ne(t); i && De(i) && "static" === Se(i).position;)i = Ne(i);
        return i && ("html" === me(i) || "body" === me(i) && "static" === Se(i).position) ? e : i || function(t) {
            var e = /firefox/i.test(Ce());
            if (/Trident/i.test(Ce()) && be(t) && "fixed" === Se(t).position) return null;
            var i = Ie(t);
            for(ve(i) && (i = i.host); be(i) && [
                "html",
                "body"
            ].indexOf(me(i)) < 0;){
                var n = Se(i);
                if ("none" !== n.transform || "none" !== n.perspective || "paint" === n.contain || -1 !== [
                    "transform",
                    "perspective"
                ].indexOf(n.willChange) || e && "filter" === n.willChange || e && n.filter && "none" !== n.filter) return i;
                i = i.parentNode;
            }
            return null;
        }(t) || e;
    }
    function je(t) {
        return [
            "top",
            "bottom"
        ].indexOf(t) >= 0 ? "x" : "y";
    }
    function Me(t, e, i) {
        return Ae(t, Ee(e, i));
    }
    function Fe(t) {
        return Object.assign({}, {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }, t);
    }
    function He(t, e) {
        return e.reduce(function(e, i) {
            return e[i] = t, e;
        }, {});
    }
    const We = {
        name: "arrow",
        enabled: !0,
        phase: "main",
        fn: function(t) {
            var e, i = t.state, n = t.name, s = t.options, o = i.elements.arrow, r = i.modifiersData.popperOffsets, a = we(i.placement), l = je(a), c = [
                Xt,
                Qt
            ].indexOf(a) >= 0 ? "height" : "width";
            if (o && r) {
                var h = function(t, e) {
                    return Fe("number" != typeof (t = "function" == typeof t ? t(Object.assign({}, e.rects, {
                        placement: e.placement
                    })) : t) ? t : He(t, Ut));
                }(s.padding, i), d = ke(o), u = "y" === l ? Vt : Xt, f = "y" === l ? Kt : Qt, p = i.rects.reference[c] + i.rects.reference[l] - r[l] - i.rects.popper[c], m = r[l] - i.rects.reference[l], g = Pe(o), _ = g ? "y" === l ? g.clientHeight || 0 : g.clientWidth || 0 : 0, b = p / 2 - m / 2, v = h[u], y = _ - d[c] - h[f], w = _ / 2 - d[c] / 2 + b, A = Me(v, w, y), E = l;
                i.modifiersData[n] = ((e = {})[E] = A, e.centerOffset = A - w, e);
            }
        },
        effect: function(t) {
            var e = t.state, i = t.options.element, n = void 0 === i ? "[data-popper-arrow]" : i;
            null != n && ("string" != typeof n || (n = e.elements.popper.querySelector(n))) && Le(e.elements.popper, n) && (e.elements.arrow = n);
        },
        requires: [
            "popperOffsets"
        ],
        requiresIfExists: [
            "preventOverflow"
        ]
    };
    function Be(t) {
        return t.split("-")[1];
    }
    var ze = {
        top: "auto",
        right: "auto",
        bottom: "auto",
        left: "auto"
    };
    function Re(t) {
        var e, i = t.popper, n = t.popperRect, s = t.placement, o = t.variation, r = t.offsets, a = t.position, l = t.gpuAcceleration, c = t.adaptive, h = t.roundOffsets, d = t.isFixed, u = r.x, f = void 0 === u ? 0 : u, p = r.y, m = void 0 === p ? 0 : p, g = "function" == typeof h ? h({
            x: f,
            y: m
        }) : {
            x: f,
            y: m
        };
        f = g.x, m = g.y;
        var _ = r.hasOwnProperty("x"), b = r.hasOwnProperty("y"), v = Xt, y = Vt, w = window;
        if (c) {
            var A = Pe(i), E = "clientHeight", T = "clientWidth";
            A === ge(i) && "static" !== Se(A = $e(i)).position && "absolute" === a && (E = "scrollHeight", T = "scrollWidth"), (s === Vt || (s === Xt || s === Qt) && o === Jt) && (y = Kt, m -= (d && A === w && w.visualViewport ? w.visualViewport.height : A[E]) - n.height, m *= l ? 1 : -1), s !== Xt && (s !== Vt && s !== Kt || o !== Jt) || (v = Qt, f -= (d && A === w && w.visualViewport ? w.visualViewport.width : A[T]) - n.width, f *= l ? 1 : -1);
        }
        var C, O = Object.assign({
            position: a
        }, c && ze), x = !0 === h ? function(t, e) {
            var i = t.x, n = t.y, s = e.devicePixelRatio || 1;
            return {
                x: Te(i * s) / s || 0,
                y: Te(n * s) / s || 0
            };
        }({
            x: f,
            y: m
        }, ge(i)) : {
            x: f,
            y: m
        };
        return f = x.x, m = x.y, l ? Object.assign({}, O, ((C = {})[y] = b ? "0" : "", C[v] = _ ? "0" : "", C.transform = (w.devicePixelRatio || 1) <= 1 ? "translate(" + f + "px, " + m + "px)" : "translate3d(" + f + "px, " + m + "px, 0)", C)) : Object.assign({}, O, ((e = {})[y] = b ? m + "px" : "", e[v] = _ ? f + "px" : "", e.transform = "", e));
    }
    const qe = {
        name: "computeStyles",
        enabled: !0,
        phase: "beforeWrite",
        fn: function(t) {
            var e = t.state, i = t.options, n = i.gpuAcceleration, s = void 0 === n || n, o = i.adaptive, r = void 0 === o || o, a = i.roundOffsets, l = void 0 === a || a, c = {
                placement: we(e.placement),
                variation: Be(e.placement),
                popper: e.elements.popper,
                popperRect: e.rects.popper,
                gpuAcceleration: s,
                isFixed: "fixed" === e.options.strategy
            };
            null != e.modifiersData.popperOffsets && (e.styles.popper = Object.assign({}, e.styles.popper, Re(Object.assign({}, c, {
                offsets: e.modifiersData.popperOffsets,
                position: e.options.strategy,
                adaptive: r,
                roundOffsets: l
            })))), null != e.modifiersData.arrow && (e.styles.arrow = Object.assign({}, e.styles.arrow, Re(Object.assign({}, c, {
                offsets: e.modifiersData.arrow,
                position: "absolute",
                adaptive: !1,
                roundOffsets: l
            })))), e.attributes.popper = Object.assign({}, e.attributes.popper, {
                "data-popper-placement": e.placement
            });
        },
        data: {}
    };
    var Ve = {
        passive: !0
    };
    const Ke = {
        name: "eventListeners",
        enabled: !0,
        phase: "write",
        fn: function() {},
        effect: function(t) {
            var e = t.state, i = t.instance, n = t.options, s = n.scroll, o = void 0 === s || s, r = n.resize, a = void 0 === r || r, l = ge(e.elements.popper), c = [].concat(e.scrollParents.reference, e.scrollParents.popper);
            return o && c.forEach(function(t) {
                t.addEventListener("scroll", i.update, Ve);
            }), a && l.addEventListener("resize", i.update, Ve), function() {
                o && c.forEach(function(t) {
                    t.removeEventListener("scroll", i.update, Ve);
                }), a && l.removeEventListener("resize", i.update, Ve);
            };
        },
        data: {}
    };
    var Qe = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };
    function Xe(t) {
        return t.replace(/left|right|bottom|top/g, function(t) {
            return Qe[t];
        });
    }
    var Ye = {
        start: "end",
        end: "start"
    };
    function Ue(t) {
        return t.replace(/start|end/g, function(t) {
            return Ye[t];
        });
    }
    function Ge(t) {
        var e = ge(t);
        return {
            scrollLeft: e.pageXOffset,
            scrollTop: e.pageYOffset
        };
    }
    function Je(t) {
        return xe($e(t)).left + Ge(t).scrollLeft;
    }
    function Ze(t) {
        var e = Se(t), i = e.overflow, n = e.overflowX, s = e.overflowY;
        return /auto|scroll|overlay|hidden/.test(i + s + n);
    }
    function ti(t) {
        return [
            "html",
            "body",
            "#document"
        ].indexOf(me(t)) >= 0 ? t.ownerDocument.body : be(t) && Ze(t) ? t : ti(Ie(t));
    }
    function ei(t, e) {
        var i;
        void 0 === e && (e = []);
        var n = ti(t), s = n === (null == (i = t.ownerDocument) ? void 0 : i.body), o = ge(n), r = s ? [
            o
        ].concat(o.visualViewport || [], Ze(n) ? n : []) : n, a = e.concat(r);
        return s ? a : a.concat(ei(Ie(r)));
    }
    function ii(t) {
        return Object.assign({}, t, {
            left: t.x,
            top: t.y,
            right: t.x + t.width,
            bottom: t.y + t.height
        });
    }
    function ni(t, e, i) {
        return e === te ? ii(function(t, e) {
            var i = ge(t), n = $e(t), s = i.visualViewport, o = n.clientWidth, r = n.clientHeight, a = 0, l = 0;
            if (s) {
                o = s.width, r = s.height;
                var c = Oe();
                (c || !c && "fixed" === e) && (a = s.offsetLeft, l = s.offsetTop);
            }
            return {
                width: o,
                height: r,
                x: a + Je(t),
                y: l
            };
        }(t, i)) : _e(e) ? function(t, e) {
            var i = xe(t, !1, "fixed" === e);
            return i.top = i.top + t.clientTop, i.left = i.left + t.clientLeft, i.bottom = i.top + t.clientHeight, i.right = i.left + t.clientWidth, i.width = t.clientWidth, i.height = t.clientHeight, i.x = i.left, i.y = i.top, i;
        }(e, i) : ii(function(t) {
            var e, i = $e(t), n = Ge(t), s = null == (e = t.ownerDocument) ? void 0 : e.body, o = Ae(i.scrollWidth, i.clientWidth, s ? s.scrollWidth : 0, s ? s.clientWidth : 0), r = Ae(i.scrollHeight, i.clientHeight, s ? s.scrollHeight : 0, s ? s.clientHeight : 0), a = -n.scrollLeft + Je(t), l = -n.scrollTop;
            return "rtl" === Se(s || i).direction && (a += Ae(i.clientWidth, s ? s.clientWidth : 0) - o), {
                width: o,
                height: r,
                x: a,
                y: l
            };
        }($e(t)));
    }
    function si(t) {
        var e, i = t.reference, n = t.element, s = t.placement, o = s ? we(s) : null, r = s ? Be(s) : null, a = i.x + i.width / 2 - n.width / 2, l = i.y + i.height / 2 - n.height / 2;
        switch(o){
            case Vt:
                e = {
                    x: a,
                    y: i.y - n.height
                };
                break;
            case Kt:
                e = {
                    x: a,
                    y: i.y + i.height
                };
                break;
            case Qt:
                e = {
                    x: i.x + i.width,
                    y: l
                };
                break;
            case Xt:
                e = {
                    x: i.x - n.width,
                    y: l
                };
                break;
            default:
                e = {
                    x: i.x,
                    y: i.y
                };
        }
        var c = o ? je(o) : null;
        if (null != c) {
            var h = "y" === c ? "height" : "width";
            switch(r){
                case Gt:
                    e[c] = e[c] - (i[h] / 2 - n[h] / 2);
                    break;
                case Jt:
                    e[c] = e[c] + (i[h] / 2 - n[h] / 2);
            }
        }
        return e;
    }
    function oi(t, e) {
        void 0 === e && (e = {});
        var i = e, n = i.placement, s = void 0 === n ? t.placement : n, o = i.strategy, r = void 0 === o ? t.strategy : o, a = i.boundary, l = void 0 === a ? Zt : a, c = i.rootBoundary, h = void 0 === c ? te : c, d = i.elementContext, u = void 0 === d ? ee : d, f = i.altBoundary, p = void 0 !== f && f, m = i.padding, g = void 0 === m ? 0 : m, _ = Fe("number" != typeof g ? g : He(g, Ut)), b = u === ee ? ie : ee, v = t.rects.popper, y = t.elements[p ? b : u], w = function(t, e, i, n) {
            var s = "clippingParents" === e ? function(t) {
                var e = ei(Ie(t)), i = [
                    "absolute",
                    "fixed"
                ].indexOf(Se(t).position) >= 0 && be(t) ? Pe(t) : t;
                return _e(i) ? e.filter(function(t) {
                    return _e(t) && Le(t, i) && "body" !== me(t);
                }) : [];
            }(t) : [].concat(e), o = [].concat(s, [
                i
            ]), r = o[0], a = o.reduce(function(e, i) {
                var s = ni(t, i, n);
                return e.top = Ae(s.top, e.top), e.right = Ee(s.right, e.right), e.bottom = Ee(s.bottom, e.bottom), e.left = Ae(s.left, e.left), e;
            }, ni(t, r, n));
            return a.width = a.right - a.left, a.height = a.bottom - a.top, a.x = a.left, a.y = a.top, a;
        }(_e(y) ? y : y.contextElement || $e(t.elements.popper), l, h, r), A = xe(t.elements.reference), E = si({
            reference: A,
            element: v,
            placement: s
        }), T = ii(Object.assign({}, v, E)), C = u === ee ? T : A, O = {
            top: w.top - C.top + _.top,
            bottom: C.bottom - w.bottom + _.bottom,
            left: w.left - C.left + _.left,
            right: C.right - w.right + _.right
        }, x = t.modifiersData.offset;
        if (u === ee && x) {
            var k = x[s];
            Object.keys(O).forEach(function(t) {
                var e = [
                    Qt,
                    Kt
                ].indexOf(t) >= 0 ? 1 : -1, i = [
                    Vt,
                    Kt
                ].indexOf(t) >= 0 ? "y" : "x";
                O[t] += k[i] * e;
            });
        }
        return O;
    }
    function ri(t, e) {
        void 0 === e && (e = {});
        var i = e, n = i.placement, s = i.boundary, o = i.rootBoundary, r = i.padding, a = i.flipVariations, l = i.allowedAutoPlacements, c = void 0 === l ? se : l, h = Be(n), d = h ? a ? ne : ne.filter(function(t) {
            return Be(t) === h;
        }) : Ut, u = d.filter(function(t) {
            return c.indexOf(t) >= 0;
        });
        0 === u.length && (u = d);
        var f = u.reduce(function(e, i) {
            return e[i] = oi(t, {
                placement: i,
                boundary: s,
                rootBoundary: o,
                padding: r
            })[we(i)], e;
        }, {});
        return Object.keys(f).sort(function(t, e) {
            return f[t] - f[e];
        });
    }
    const ai = {
        name: "flip",
        enabled: !0,
        phase: "main",
        fn: function(t) {
            var e = t.state, i = t.options, n = t.name;
            if (!e.modifiersData[n]._skip) {
                for(var s = i.mainAxis, o = void 0 === s || s, r = i.altAxis, a = void 0 === r || r, l = i.fallbackPlacements, c = i.padding, h = i.boundary, d = i.rootBoundary, u = i.altBoundary, f = i.flipVariations, p = void 0 === f || f, m = i.allowedAutoPlacements, g = e.options.placement, _ = we(g), b = l || (_ !== g && p ? function(t) {
                    if (we(t) === Yt) return [];
                    var e = Xe(t);
                    return [
                        Ue(t),
                        e,
                        Ue(e)
                    ];
                }(g) : [
                    Xe(g)
                ]), v = [
                    g
                ].concat(b).reduce(function(t, i) {
                    return t.concat(we(i) === Yt ? ri(e, {
                        placement: i,
                        boundary: h,
                        rootBoundary: d,
                        padding: c,
                        flipVariations: p,
                        allowedAutoPlacements: m
                    }) : i);
                }, []), y = e.rects.reference, w = e.rects.popper, A = new Map, E = !0, T = v[0], C = 0; C < v.length; C++){
                    var O = v[C], x = we(O), k = Be(O) === Gt, L = [
                        Vt,
                        Kt
                    ].indexOf(x) >= 0, S = L ? "width" : "height", D = oi(e, {
                        placement: O,
                        boundary: h,
                        rootBoundary: d,
                        altBoundary: u,
                        padding: c
                    }), $ = L ? k ? Qt : Xt : k ? Kt : Vt;
                    y[S] > w[S] && ($ = Xe($));
                    var I = Xe($), N = [];
                    if (o && N.push(D[x] <= 0), a && N.push(D[$] <= 0, D[I] <= 0), N.every(function(t) {
                        return t;
                    })) {
                        T = O, E = !1;
                        break;
                    }
                    A.set(O, N);
                }
                if (E) for(var P = function(t) {
                    var e = v.find(function(e) {
                        var i = A.get(e);
                        if (i) return i.slice(0, t).every(function(t) {
                            return t;
                        });
                    });
                    if (e) return T = e, "break";
                }, j = p ? 3 : 1; j > 0 && "break" !== P(j); j--);
                e.placement !== T && (e.modifiersData[n]._skip = !0, e.placement = T, e.reset = !0);
            }
        },
        requiresIfExists: [
            "offset"
        ],
        data: {
            _skip: !1
        }
    };
    function li(t, e, i) {
        return void 0 === i && (i = {
            x: 0,
            y: 0
        }), {
            top: t.top - e.height - i.y,
            right: t.right - e.width + i.x,
            bottom: t.bottom - e.height + i.y,
            left: t.left - e.width - i.x
        };
    }
    function ci(t) {
        return [
            Vt,
            Qt,
            Kt,
            Xt
        ].some(function(e) {
            return t[e] >= 0;
        });
    }
    const hi = {
        name: "hide",
        enabled: !0,
        phase: "main",
        requiresIfExists: [
            "preventOverflow"
        ],
        fn: function(t) {
            var e = t.state, i = t.name, n = e.rects.reference, s = e.rects.popper, o = e.modifiersData.preventOverflow, r = oi(e, {
                elementContext: "reference"
            }), a = oi(e, {
                altBoundary: !0
            }), l = li(r, n), c = li(a, s, o), h = ci(l), d = ci(c);
            e.modifiersData[i] = {
                referenceClippingOffsets: l,
                popperEscapeOffsets: c,
                isReferenceHidden: h,
                hasPopperEscaped: d
            }, e.attributes.popper = Object.assign({}, e.attributes.popper, {
                "data-popper-reference-hidden": h,
                "data-popper-escaped": d
            });
        }
    }, di = {
        name: "offset",
        enabled: !0,
        phase: "main",
        requires: [
            "popperOffsets"
        ],
        fn: function(t) {
            var e = t.state, i = t.options, n = t.name, s = i.offset, o = void 0 === s ? [
                0,
                0
            ] : s, r = se.reduce(function(t, i) {
                return t[i] = function(t, e, i) {
                    var n = we(t), s = [
                        Xt,
                        Vt
                    ].indexOf(n) >= 0 ? -1 : 1, o = "function" == typeof i ? i(Object.assign({}, e, {
                        placement: t
                    })) : i, r = o[0], a = o[1];
                    return r = r || 0, a = (a || 0) * s, [
                        Xt,
                        Qt
                    ].indexOf(n) >= 0 ? {
                        x: a,
                        y: r
                    } : {
                        x: r,
                        y: a
                    };
                }(i, e.rects, o), t;
            }, {}), a = r[e.placement], l = a.x, c = a.y;
            null != e.modifiersData.popperOffsets && (e.modifiersData.popperOffsets.x += l, e.modifiersData.popperOffsets.y += c), e.modifiersData[n] = r;
        }
    }, ui = {
        name: "popperOffsets",
        enabled: !0,
        phase: "read",
        fn: function(t) {
            var e = t.state, i = t.name;
            e.modifiersData[i] = si({
                reference: e.rects.reference,
                element: e.rects.popper,
                placement: e.placement
            });
        },
        data: {}
    }, fi = {
        name: "preventOverflow",
        enabled: !0,
        phase: "main",
        fn: function(t) {
            var e = t.state, i = t.options, n = t.name, s = i.mainAxis, o = void 0 === s || s, r = i.altAxis, a = void 0 !== r && r, l = i.boundary, c = i.rootBoundary, h = i.altBoundary, d = i.padding, u = i.tether, f = void 0 === u || u, p = i.tetherOffset, m = void 0 === p ? 0 : p, g = oi(e, {
                boundary: l,
                rootBoundary: c,
                padding: d,
                altBoundary: h
            }), _ = we(e.placement), b = Be(e.placement), v = !b, y = je(_), w = "x" === y ? "y" : "x", A = e.modifiersData.popperOffsets, E = e.rects.reference, T = e.rects.popper, C = "function" == typeof m ? m(Object.assign({}, e.rects, {
                placement: e.placement
            })) : m, O = "number" == typeof C ? {
                mainAxis: C,
                altAxis: C
            } : Object.assign({
                mainAxis: 0,
                altAxis: 0
            }, C), x = e.modifiersData.offset ? e.modifiersData.offset[e.placement] : null, k = {
                x: 0,
                y: 0
            };
            if (A) {
                if (o) {
                    var L, S = "y" === y ? Vt : Xt, D = "y" === y ? Kt : Qt, $ = "y" === y ? "height" : "width", I = A[y], N = I + g[S], P = I - g[D], j = f ? -T[$] / 2 : 0, M = b === Gt ? E[$] : T[$], F = b === Gt ? -T[$] : -E[$], H = e.elements.arrow, W = f && H ? ke(H) : {
                        width: 0,
                        height: 0
                    }, B = e.modifiersData["arrow#persistent"] ? e.modifiersData["arrow#persistent"].padding : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0
                    }, z = B[S], R = B[D], q = Me(0, E[$], W[$]), V = v ? E[$] / 2 - j - q - z - O.mainAxis : M - q - z - O.mainAxis, K = v ? -E[$] / 2 + j + q + R + O.mainAxis : F + q + R + O.mainAxis, Q = e.elements.arrow && Pe(e.elements.arrow), X = Q ? "y" === y ? Q.clientTop || 0 : Q.clientLeft || 0 : 0, Y = null != (L = null == x ? void 0 : x[y]) ? L : 0, U = I + K - Y, G = Me(f ? Ee(N, I + V - Y - X) : N, I, f ? Ae(P, U) : P);
                    A[y] = G, k[y] = G - I;
                }
                if (a) {
                    var J, Z = "x" === y ? Vt : Xt, tt = "x" === y ? Kt : Qt, et = A[w], it = "y" === w ? "height" : "width", nt = et + g[Z], st = et - g[tt], ot = -1 !== [
                        Vt,
                        Xt
                    ].indexOf(_), rt = null != (J = null == x ? void 0 : x[w]) ? J : 0, at = ot ? nt : et - E[it] - T[it] - rt + O.altAxis, lt = ot ? et + E[it] + T[it] - rt - O.altAxis : st, ct = f && ot ? function(t, e, i) {
                        var n = Me(t, e, i);
                        return n > i ? i : n;
                    }(at, et, lt) : Me(f ? at : nt, et, f ? lt : st);
                    A[w] = ct, k[w] = ct - et;
                }
                e.modifiersData[n] = k;
            }
        },
        requiresIfExists: [
            "offset"
        ]
    };
    function pi(t, e, i) {
        void 0 === i && (i = !1);
        var n, s, o = be(e), r = be(e) && function(t) {
            var e = t.getBoundingClientRect(), i = Te(e.width) / t.offsetWidth || 1, n = Te(e.height) / t.offsetHeight || 1;
            return 1 !== i || 1 !== n;
        }(e), a = $e(e), l = xe(t, r, i), c = {
            scrollLeft: 0,
            scrollTop: 0
        }, h = {
            x: 0,
            y: 0
        };
        return (o || !o && !i) && (("body" !== me(e) || Ze(a)) && (c = (n = e) !== ge(n) && be(n) ? {
            scrollLeft: (s = n).scrollLeft,
            scrollTop: s.scrollTop
        } : Ge(n)), be(e) ? ((h = xe(e, !0)).x += e.clientLeft, h.y += e.clientTop) : a && (h.x = Je(a))), {
            x: l.left + c.scrollLeft - h.x,
            y: l.top + c.scrollTop - h.y,
            width: l.width,
            height: l.height
        };
    }
    function mi(t) {
        var e = new Map, i = new Set, n = [];
        function s(t) {
            i.add(t.name), [].concat(t.requires || [], t.requiresIfExists || []).forEach(function(t) {
                if (!i.has(t)) {
                    var n = e.get(t);
                    n && s(n);
                }
            }), n.push(t);
        }
        return t.forEach(function(t) {
            e.set(t.name, t);
        }), t.forEach(function(t) {
            i.has(t.name) || s(t);
        }), n;
    }
    var gi = {
        placement: "bottom",
        modifiers: [],
        strategy: "absolute"
    };
    function _i() {
        for(var t = arguments.length, e = new Array(t), i = 0; i < t; i++)e[i] = arguments[i];
        return !e.some(function(t) {
            return !(t && "function" == typeof t.getBoundingClientRect);
        });
    }
    function bi(t) {
        void 0 === t && (t = {});
        var e = t, i = e.defaultModifiers, n = void 0 === i ? [] : i, s = e.defaultOptions, o = void 0 === s ? gi : s;
        return function(t, e, i) {
            void 0 === i && (i = o);
            var s, r, a = {
                placement: "bottom",
                orderedModifiers: [],
                options: Object.assign({}, gi, o),
                modifiersData: {},
                elements: {
                    reference: t,
                    popper: e
                },
                attributes: {},
                styles: {}
            }, l = [], c = !1, h = {
                state: a,
                setOptions: function(i) {
                    var s = "function" == typeof i ? i(a.options) : i;
                    d(), a.options = Object.assign({}, o, a.options, s), a.scrollParents = {
                        reference: _e(t) ? ei(t) : t.contextElement ? ei(t.contextElement) : [],
                        popper: ei(e)
                    };
                    var r, c, u = function(t) {
                        var e = mi(t);
                        return pe.reduce(function(t, i) {
                            return t.concat(e.filter(function(t) {
                                return t.phase === i;
                            }));
                        }, []);
                    }((r = [].concat(n, a.options.modifiers), c = r.reduce(function(t, e) {
                        var i = t[e.name];
                        return t[e.name] = i ? Object.assign({}, i, e, {
                            options: Object.assign({}, i.options, e.options),
                            data: Object.assign({}, i.data, e.data)
                        }) : e, t;
                    }, {}), Object.keys(c).map(function(t) {
                        return c[t];
                    })));
                    return a.orderedModifiers = u.filter(function(t) {
                        return t.enabled;
                    }), a.orderedModifiers.forEach(function(t) {
                        var e = t.name, i = t.options, n = void 0 === i ? {} : i, s = t.effect;
                        if ("function" == typeof s) {
                            var o = s({
                                state: a,
                                name: e,
                                instance: h,
                                options: n
                            });
                            l.push(o || function() {});
                        }
                    }), h.update();
                },
                forceUpdate: function() {
                    if (!c) {
                        var t = a.elements, e = t.reference, i = t.popper;
                        if (_i(e, i)) {
                            a.rects = {
                                reference: pi(e, Pe(i), "fixed" === a.options.strategy),
                                popper: ke(i)
                            }, a.reset = !1, a.placement = a.options.placement, a.orderedModifiers.forEach(function(t) {
                                return a.modifiersData[t.name] = Object.assign({}, t.data);
                            });
                            for(var n = 0; n < a.orderedModifiers.length; n++)if (!0 !== a.reset) {
                                var s = a.orderedModifiers[n], o = s.fn, r = s.options, l = void 0 === r ? {} : r, d = s.name;
                                "function" == typeof o && (a = o({
                                    state: a,
                                    options: l,
                                    name: d,
                                    instance: h
                                }) || a);
                            } else a.reset = !1, n = -1;
                        }
                    }
                },
                update: (s = function() {
                    return new Promise(function(t) {
                        h.forceUpdate(), t(a);
                    });
                }, function() {
                    return r || (r = new Promise(function(t) {
                        Promise.resolve().then(function() {
                            r = void 0, t(s());
                        });
                    })), r;
                }),
                destroy: function() {
                    d(), c = !0;
                }
            };
            if (!_i(t, e)) return h;
            function d() {
                l.forEach(function(t) {
                    return t();
                }), l = [];
            }
            return h.setOptions(i).then(function(t) {
                !c && i.onFirstUpdate && i.onFirstUpdate(t);
            }), h;
        };
    }
    var vi = bi(), yi = bi({
        defaultModifiers: [
            Ke,
            ui,
            qe,
            ye
        ]
    }), wi = bi({
        defaultModifiers: [
            Ke,
            ui,
            qe,
            ye,
            di,
            ai,
            fi,
            We,
            hi
        ]
    });
    const Ai = Object.freeze(Object.defineProperty({
        __proto__: null,
        afterMain: he,
        afterRead: ae,
        afterWrite: fe,
        applyStyles: ye,
        arrow: We,
        auto: Yt,
        basePlacements: Ut,
        beforeMain: le,
        beforeRead: oe,
        beforeWrite: de,
        bottom: Kt,
        clippingParents: Zt,
        computeStyles: qe,
        createPopper: wi,
        createPopperBase: vi,
        createPopperLite: yi,
        detectOverflow: oi,
        end: Jt,
        eventListeners: Ke,
        flip: ai,
        hide: hi,
        left: Xt,
        main: ce,
        modifierPhases: pe,
        offset: di,
        placements: se,
        popper: ee,
        popperGenerator: bi,
        popperOffsets: ui,
        preventOverflow: fi,
        read: re,
        reference: ie,
        right: Qt,
        start: Gt,
        top: Vt,
        variationPlacements: ne,
        viewport: te,
        write: ue
    }, Symbol.toStringTag, {
        value: "Module"
    })), Ei = "dropdown", Ti = ".bs.dropdown", Ci = ".data-api", Oi = "ArrowUp", xi = "ArrowDown", ki = `hide${Ti}`, Li = `hidden${Ti}`, Si = `show${Ti}`, Di = `shown${Ti}`, $i = `click${Ti}${Ci}`, Ii = `keydown${Ti}${Ci}`, Ni = `keyup${Ti}${Ci}`, Pi = "show", ji = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)', Mi = `${ji}.${Pi}`, Fi = ".dropdown-menu", Hi = m() ? "top-end" : "top-start", Wi = m() ? "top-start" : "top-end", Bi = m() ? "bottom-end" : "bottom-start", zi = m() ? "bottom-start" : "bottom-end", Ri = m() ? "left-start" : "right-start", qi = m() ? "right-start" : "left-start", Vi = {
        autoClose: !0,
        boundary: "clippingParents",
        display: "dynamic",
        offset: [
            0,
            2
        ],
        popperConfig: null,
        reference: "toggle"
    }, Ki = {
        autoClose: "(boolean|string)",
        boundary: "(string|element)",
        display: "string",
        offset: "(array|string|function)",
        popperConfig: "(null|object|function)",
        reference: "(string|element|object)"
    };
    class Qi extends B {
        constructor(t, e){
            super(t, e), this._popper = null, this._parent = this._element.parentNode, this._menu = R.next(this._element, Fi)[0] || R.prev(this._element, Fi)[0] || R.findOne(Fi, this._parent), this._inNavbar = this._detectNavbar();
        }
        static get Default() {
            return Vi;
        }
        static get DefaultType() {
            return Ki;
        }
        static get NAME() {
            return Ei;
        }
        toggle() {
            return this._isShown() ? this.hide() : this.show();
        }
        show() {
            if (c(this._element) || this._isShown()) return;
            const t = {
                relatedTarget: this._element
            };
            if (!P.trigger(this._element, Si, t).defaultPrevented) {
                if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(".navbar-nav")) for (const t of [].concat(...document.body.children))P.on(t, "mouseover", d);
                this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(Pi), this._element.classList.add(Pi), P.trigger(this._element, Di, t);
            }
        }
        hide() {
            if (c(this._element) || !this._isShown()) return;
            const t = {
                relatedTarget: this._element
            };
            this._completeHide(t);
        }
        dispose() {
            this._popper && this._popper.destroy(), super.dispose();
        }
        update() {
            this._inNavbar = this._detectNavbar(), this._popper && this._popper.update();
        }
        _completeHide(t) {
            if (!P.trigger(this._element, ki, t).defaultPrevented) {
                if ("ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children))P.off(t, "mouseover", d);
                this._popper && this._popper.destroy(), this._menu.classList.remove(Pi), this._element.classList.remove(Pi), this._element.setAttribute("aria-expanded", "false"), H.removeDataAttribute(this._menu, "popper"), P.trigger(this._element, Li, t);
            }
        }
        _getConfig(t) {
            if ("object" == typeof (t = super._getConfig(t)).reference && !r(t.reference) && "function" != typeof t.reference.getBoundingClientRect) throw new TypeError(`${Ei.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
            return t;
        }
        _createPopper() {
            if (void 0 === Ai) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)");
            let t = this._element;
            "parent" === this._config.reference ? t = this._parent : r(this._config.reference) ? t = a(this._config.reference) : "object" == typeof this._config.reference && (t = this._config.reference);
            const e = this._getPopperConfig();
            this._popper = wi(t, this._menu, e);
        }
        _isShown() {
            return this._menu.classList.contains(Pi);
        }
        _getPlacement() {
            const t = this._parent;
            if (t.classList.contains("dropend")) return Ri;
            if (t.classList.contains("dropstart")) return qi;
            if (t.classList.contains("dropup-center")) return "top";
            if (t.classList.contains("dropdown-center")) return "bottom";
            const e = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
            return t.classList.contains("dropup") ? e ? Wi : Hi : e ? zi : Bi;
        }
        _detectNavbar() {
            return null !== this._element.closest(".navbar");
        }
        _getOffset() {
            const { offset: t } = this._config;
            return "string" == typeof t ? t.split(",").map((t)=>Number.parseInt(t, 10)) : "function" == typeof t ? (e)=>t(e, this._element) : t;
        }
        _getPopperConfig() {
            const t = {
                placement: this._getPlacement(),
                modifiers: [
                    {
                        name: "preventOverflow",
                        options: {
                            boundary: this._config.boundary
                        }
                    },
                    {
                        name: "offset",
                        options: {
                            offset: this._getOffset()
                        }
                    }
                ]
            };
            return (this._inNavbar || "static" === this._config.display) && (H.setDataAttribute(this._menu, "popper", "static"), t.modifiers = [
                {
                    name: "applyStyles",
                    enabled: !1
                }
            ]), {
                ...t,
                ..._(this._config.popperConfig, [
                    void 0,
                    t
                ])
            };
        }
        _selectMenuItem({ key: t, target: e }) {
            const i = R.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter((t)=>l(t));
            i.length && v(i, e, t === xi, !i.includes(e)).focus();
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Qi.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]();
                }
            });
        }
        static clearMenus(t) {
            if (2 === t.button || "keyup" === t.type && "Tab" !== t.key) return;
            const e = R.find(Mi);
            for (const i of e){
                const e = Qi.getInstance(i);
                if (!e || !1 === e._config.autoClose) continue;
                const n = t.composedPath(), s = n.includes(e._menu);
                if (n.includes(e._element) || "inside" === e._config.autoClose && !s || "outside" === e._config.autoClose && s) continue;
                if (e._menu.contains(t.target) && ("keyup" === t.type && "Tab" === t.key || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
                const o = {
                    relatedTarget: e._element
                };
                "click" === t.type && (o.clickEvent = t), e._completeHide(o);
            }
        }
        static dataApiKeydownHandler(t) {
            const e = /input|textarea/i.test(t.target.tagName), i = "Escape" === t.key, n = [
                Oi,
                xi
            ].includes(t.key);
            if (!n && !i) return;
            if (e && !i) return;
            t.preventDefault();
            const s = this.matches(ji) ? this : R.prev(this, ji)[0] || R.next(this, ji)[0] || R.findOne(ji, t.delegateTarget.parentNode), o = Qi.getOrCreateInstance(s);
            if (n) return t.stopPropagation(), o.show(), void o._selectMenuItem(t);
            o._isShown() && (t.stopPropagation(), o.hide(), s.focus());
        }
    }
    P.on(document, Ii, ji, Qi.dataApiKeydownHandler), P.on(document, Ii, Fi, Qi.dataApiKeydownHandler), P.on(document, $i, Qi.clearMenus), P.on(document, Ni, Qi.clearMenus), P.on(document, $i, ji, function(t) {
        t.preventDefault(), Qi.getOrCreateInstance(this).toggle();
    }), g(Qi);
    const Xi = "backdrop", Yi = "show", Ui = `mousedown.bs.${Xi}`, Gi = {
        className: "modal-backdrop",
        clickCallback: null,
        isAnimated: !1,
        isVisible: !0,
        rootElement: "body"
    }, Ji = {
        className: "string",
        clickCallback: "(function|null)",
        isAnimated: "boolean",
        isVisible: "boolean",
        rootElement: "(element|string)"
    };
    class Zi extends W {
        constructor(t){
            super(), this._config = this._getConfig(t), this._isAppended = !1, this._element = null;
        }
        static get Default() {
            return Gi;
        }
        static get DefaultType() {
            return Ji;
        }
        static get NAME() {
            return Xi;
        }
        show(t) {
            if (!this._config.isVisible) return void _(t);
            this._append();
            const e = this._getElement();
            this._config.isAnimated && u(e), e.classList.add(Yi), this._emulateAnimation(()=>{
                _(t);
            });
        }
        hide(t) {
            this._config.isVisible ? (this._getElement().classList.remove(Yi), this._emulateAnimation(()=>{
                this.dispose(), _(t);
            })) : _(t);
        }
        dispose() {
            this._isAppended && (P.off(this._element, Ui), this._element.remove(), this._isAppended = !1);
        }
        _getElement() {
            if (!this._element) {
                const t = document.createElement("div");
                t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t;
            }
            return this._element;
        }
        _configAfterMerge(t) {
            return t.rootElement = a(t.rootElement), t;
        }
        _append() {
            if (this._isAppended) return;
            const t = this._getElement();
            this._config.rootElement.append(t), P.on(t, Ui, ()=>{
                _(this._config.clickCallback);
            }), this._isAppended = !0;
        }
        _emulateAnimation(t) {
            b(t, this._getElement(), this._config.isAnimated);
        }
    }
    const tn = ".bs.focustrap", en = `focusin${tn}`, nn = `keydown.tab${tn}`, sn = "backward", on = {
        autofocus: !0,
        trapElement: null
    }, rn = {
        autofocus: "boolean",
        trapElement: "element"
    };
    class an extends W {
        constructor(t){
            super(), this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null;
        }
        static get Default() {
            return on;
        }
        static get DefaultType() {
            return rn;
        }
        static get NAME() {
            return "focustrap";
        }
        activate() {
            this._isActive || (this._config.autofocus && this._config.trapElement.focus(), P.off(document, tn), P.on(document, en, (t)=>this._handleFocusin(t)), P.on(document, nn, (t)=>this._handleKeydown(t)), this._isActive = !0);
        }
        deactivate() {
            this._isActive && (this._isActive = !1, P.off(document, tn));
        }
        _handleFocusin(t) {
            const { trapElement: e } = this._config;
            if (t.target === document || t.target === e || e.contains(t.target)) return;
            const i = R.focusableChildren(e);
            0 === i.length ? e.focus() : this._lastTabNavDirection === sn ? i[i.length - 1].focus() : i[0].focus();
        }
        _handleKeydown(t) {
            "Tab" === t.key && (this._lastTabNavDirection = t.shiftKey ? sn : "forward");
        }
    }
    const ln = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", cn = ".sticky-top", hn = "padding-right", dn = "margin-right";
    class un {
        constructor(){
            this._element = document.body;
        }
        getWidth() {
            const t = document.documentElement.clientWidth;
            return Math.abs(window.innerWidth - t);
        }
        hide() {
            const t = this.getWidth();
            this._disableOverFlow(), this._setElementAttributes(this._element, hn, (e)=>e + t), this._setElementAttributes(ln, hn, (e)=>e + t), this._setElementAttributes(cn, dn, (e)=>e - t);
        }
        reset() {
            this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, hn), this._resetElementAttributes(ln, hn), this._resetElementAttributes(cn, dn);
        }
        isOverflowing() {
            return this.getWidth() > 0;
        }
        _disableOverFlow() {
            this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden";
        }
        _setElementAttributes(t, e, i) {
            const n = this.getWidth();
            this._applyManipulationCallback(t, (t)=>{
                if (t !== this._element && window.innerWidth > t.clientWidth + n) return;
                this._saveInitialAttribute(t, e);
                const s = window.getComputedStyle(t).getPropertyValue(e);
                t.style.setProperty(e, `${i(Number.parseFloat(s))}px`);
            });
        }
        _saveInitialAttribute(t, e) {
            const i = t.style.getPropertyValue(e);
            i && H.setDataAttribute(t, e, i);
        }
        _resetElementAttributes(t, e) {
            this._applyManipulationCallback(t, (t)=>{
                const i = H.getDataAttribute(t, e);
                null !== i ? (H.removeDataAttribute(t, e), t.style.setProperty(e, i)) : t.style.removeProperty(e);
            });
        }
        _applyManipulationCallback(t, e) {
            if (r(t)) e(t);
            else for (const i of R.find(t, this._element))e(i);
        }
    }
    const fn = ".bs.modal", pn = `hide${fn}`, mn = `hidePrevented${fn}`, gn = `hidden${fn}`, _n = `show${fn}`, bn = `shown${fn}`, vn = `resize${fn}`, yn = `click.dismiss${fn}`, wn = `mousedown.dismiss${fn}`, An = `keydown.dismiss${fn}`, En = `click${fn}.data-api`, Tn = "modal-open", Cn = "show", On = "modal-static", xn = {
        backdrop: !0,
        focus: !0,
        keyboard: !0
    }, kn = {
        backdrop: "(boolean|string)",
        focus: "boolean",
        keyboard: "boolean"
    };
    class Ln extends B {
        constructor(t, e){
            super(t, e), this._dialog = R.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._isTransitioning = !1, this._scrollBar = new un, this._addEventListeners();
        }
        static get Default() {
            return xn;
        }
        static get DefaultType() {
            return kn;
        }
        static get NAME() {
            return "modal";
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t);
        }
        show(t) {
            this._isShown || this._isTransitioning || P.trigger(this._element, _n, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._isTransitioning = !0, this._scrollBar.hide(), document.body.classList.add(Tn), this._adjustDialog(), this._backdrop.show(()=>this._showElement(t)));
        }
        hide() {
            this._isShown && !this._isTransitioning && (P.trigger(this._element, pn).defaultPrevented || (this._isShown = !1, this._isTransitioning = !0, this._focustrap.deactivate(), this._element.classList.remove(Cn), this._queueCallback(()=>this._hideModal(), this._element, this._isAnimated())));
        }
        dispose() {
            P.off(window, fn), P.off(this._dialog, fn), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
        }
        handleUpdate() {
            this._adjustDialog();
        }
        _initializeBackDrop() {
            return new Zi({
                isVisible: Boolean(this._config.backdrop),
                isAnimated: this._isAnimated()
            });
        }
        _initializeFocusTrap() {
            return new an({
                trapElement: this._element
            });
        }
        _showElement(t) {
            document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
            const e = R.findOne(".modal-body", this._dialog);
            e && (e.scrollTop = 0), u(this._element), this._element.classList.add(Cn), this._queueCallback(()=>{
                this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, P.trigger(this._element, bn, {
                    relatedTarget: t
                });
            }, this._dialog, this._isAnimated());
        }
        _addEventListeners() {
            P.on(this._element, An, (t)=>{
                "Escape" === t.key && (this._config.keyboard ? this.hide() : this._triggerBackdropTransition());
            }), P.on(window, vn, ()=>{
                this._isShown && !this._isTransitioning && this._adjustDialog();
            }), P.on(this._element, wn, (t)=>{
                P.one(this._element, yn, (e)=>{
                    this._element === t.target && this._element === e.target && ("static" !== this._config.backdrop ? this._config.backdrop && this.hide() : this._triggerBackdropTransition());
                });
            });
        }
        _hideModal() {
            this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(()=>{
                document.body.classList.remove(Tn), this._resetAdjustments(), this._scrollBar.reset(), P.trigger(this._element, gn);
            });
        }
        _isAnimated() {
            return this._element.classList.contains("fade");
        }
        _triggerBackdropTransition() {
            if (P.trigger(this._element, mn).defaultPrevented) return;
            const t = this._element.scrollHeight > document.documentElement.clientHeight, e = this._element.style.overflowY;
            "hidden" === e || this._element.classList.contains(On) || (t || (this._element.style.overflowY = "hidden"), this._element.classList.add(On), this._queueCallback(()=>{
                this._element.classList.remove(On), this._queueCallback(()=>{
                    this._element.style.overflowY = e;
                }, this._dialog);
            }, this._dialog), this._element.focus());
        }
        _adjustDialog() {
            const t = this._element.scrollHeight > document.documentElement.clientHeight, e = this._scrollBar.getWidth(), i = e > 0;
            if (i && !t) {
                const t = m() ? "paddingLeft" : "paddingRight";
                this._element.style[t] = `${e}px`;
            }
            if (!i && t) {
                const t = m() ? "paddingRight" : "paddingLeft";
                this._element.style[t] = `${e}px`;
            }
        }
        _resetAdjustments() {
            this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
        }
        static jQueryInterface(t, e) {
            return this.each(function() {
                const i = Ln.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
                    i[t](e);
                }
            });
        }
    }
    P.on(document, En, '[data-bs-toggle="modal"]', function(t) {
        const e = R.getElementFromSelector(this);
        [
            "A",
            "AREA"
        ].includes(this.tagName) && t.preventDefault(), P.one(e, _n, (t)=>{
            t.defaultPrevented || P.one(e, gn, ()=>{
                l(this) && this.focus();
            });
        });
        const i = R.findOne(".modal.show");
        i && Ln.getInstance(i).hide(), Ln.getOrCreateInstance(e).toggle(this);
    }), q(Ln), g(Ln);
    const Sn = ".bs.offcanvas", Dn = ".data-api", $n = `load${Sn}${Dn}`, In = "show", Nn = "showing", Pn = "hiding", jn = ".offcanvas.show", Mn = `show${Sn}`, Fn = `shown${Sn}`, Hn = `hide${Sn}`, Wn = `hidePrevented${Sn}`, Bn = `hidden${Sn}`, zn = `resize${Sn}`, Rn = `click${Sn}${Dn}`, qn = `keydown.dismiss${Sn}`, Vn = {
        backdrop: !0,
        keyboard: !0,
        scroll: !1
    }, Kn = {
        backdrop: "(boolean|string)",
        keyboard: "boolean",
        scroll: "boolean"
    };
    class Qn extends B {
        constructor(t, e){
            super(t, e), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners();
        }
        static get Default() {
            return Vn;
        }
        static get DefaultType() {
            return Kn;
        }
        static get NAME() {
            return "offcanvas";
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t);
        }
        show(t) {
            this._isShown || P.trigger(this._element, Mn, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._backdrop.show(), this._config.scroll || (new un).hide(), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add(Nn), this._queueCallback(()=>{
                this._config.scroll && !this._config.backdrop || this._focustrap.activate(), this._element.classList.add(In), this._element.classList.remove(Nn), P.trigger(this._element, Fn, {
                    relatedTarget: t
                });
            }, this._element, !0));
        }
        hide() {
            this._isShown && (P.trigger(this._element, Hn).defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.add(Pn), this._backdrop.hide(), this._queueCallback(()=>{
                this._element.classList.remove(In, Pn), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || (new un).reset(), P.trigger(this._element, Bn);
            }, this._element, !0)));
        }
        dispose() {
            this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
        }
        _initializeBackDrop() {
            const t = Boolean(this._config.backdrop);
            return new Zi({
                className: "offcanvas-backdrop",
                isVisible: t,
                isAnimated: !0,
                rootElement: this._element.parentNode,
                clickCallback: t ? ()=>{
                    "static" !== this._config.backdrop ? this.hide() : P.trigger(this._element, Wn);
                } : null
            });
        }
        _initializeFocusTrap() {
            return new an({
                trapElement: this._element
            });
        }
        _addEventListeners() {
            P.on(this._element, qn, (t)=>{
                "Escape" === t.key && (this._config.keyboard ? this.hide() : P.trigger(this._element, Wn));
            });
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Qn.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t](this);
                }
            });
        }
    }
    P.on(document, Rn, '[data-bs-toggle="offcanvas"]', function(t) {
        const e = R.getElementFromSelector(this);
        if ([
            "A",
            "AREA"
        ].includes(this.tagName) && t.preventDefault(), c(this)) return;
        P.one(e, Bn, ()=>{
            l(this) && this.focus();
        });
        const i = R.findOne(jn);
        i && i !== e && Qn.getInstance(i).hide(), Qn.getOrCreateInstance(e).toggle(this);
    }), P.on(window, $n, ()=>{
        for (const t of R.find(jn))Qn.getOrCreateInstance(t).show();
    }), P.on(window, zn, ()=>{
        for (const t of R.find("[aria-modal][class*=show][class*=offcanvas-]"))"fixed" !== getComputedStyle(t).position && Qn.getOrCreateInstance(t).hide();
    }), q(Qn), g(Qn);
    const Xn = {
        "*": [
            "class",
            "dir",
            "id",
            "lang",
            "role",
            /^aria-[\w-]*$/i
        ],
        a: [
            "target",
            "href",
            "title",
            "rel"
        ],
        area: [],
        b: [],
        br: [],
        col: [],
        code: [],
        dd: [],
        div: [],
        dl: [],
        dt: [],
        em: [],
        hr: [],
        h1: [],
        h2: [],
        h3: [],
        h4: [],
        h5: [],
        h6: [],
        i: [],
        img: [
            "src",
            "srcset",
            "alt",
            "title",
            "width",
            "height"
        ],
        li: [],
        ol: [],
        p: [],
        pre: [],
        s: [],
        small: [],
        span: [],
        sub: [],
        sup: [],
        strong: [],
        u: [],
        ul: []
    }, Yn = new Set([
        "background",
        "cite",
        "href",
        "itemtype",
        "longdesc",
        "poster",
        "src",
        "xlink:href"
    ]), Un = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i, Gn = (t, e)=>{
        const i = t.nodeName.toLowerCase();
        return e.includes(i) ? !Yn.has(i) || Boolean(Un.test(t.nodeValue)) : e.filter((t)=>t instanceof RegExp).some((t)=>t.test(i));
    }, Jn = {
        allowList: Xn,
        content: {},
        extraClass: "",
        html: !1,
        sanitize: !0,
        sanitizeFn: null,
        template: "<div></div>"
    }, Zn = {
        allowList: "object",
        content: "object",
        extraClass: "(string|function)",
        html: "boolean",
        sanitize: "boolean",
        sanitizeFn: "(null|function)",
        template: "string"
    }, ts = {
        entry: "(string|element|function|null)",
        selector: "(string|element)"
    };
    class es extends W {
        constructor(t){
            super(), this._config = this._getConfig(t);
        }
        static get Default() {
            return Jn;
        }
        static get DefaultType() {
            return Zn;
        }
        static get NAME() {
            return "TemplateFactory";
        }
        getContent() {
            return Object.values(this._config.content).map((t)=>this._resolvePossibleFunction(t)).filter(Boolean);
        }
        hasContent() {
            return this.getContent().length > 0;
        }
        changeContent(t) {
            return this._checkContent(t), this._config.content = {
                ...this._config.content,
                ...t
            }, this;
        }
        toHtml() {
            const t = document.createElement("div");
            t.innerHTML = this._maybeSanitize(this._config.template);
            for (const [e, i] of Object.entries(this._config.content))this._setContent(t, i, e);
            const e = t.children[0], i = this._resolvePossibleFunction(this._config.extraClass);
            return i && e.classList.add(...i.split(" ")), e;
        }
        _typeCheckConfig(t) {
            super._typeCheckConfig(t), this._checkContent(t.content);
        }
        _checkContent(t) {
            for (const [e, i] of Object.entries(t))super._typeCheckConfig({
                selector: e,
                entry: i
            }, ts);
        }
        _setContent(t, e, i) {
            const n = R.findOne(i, t);
            n && ((e = this._resolvePossibleFunction(e)) ? r(e) ? this._putElementInTemplate(a(e), n) : this._config.html ? n.innerHTML = this._maybeSanitize(e) : n.textContent = e : n.remove());
        }
        _maybeSanitize(t) {
            return this._config.sanitize ? function(t, e, i) {
                if (!t.length) return t;
                if (i && "function" == typeof i) return i(t);
                const n = (new window.DOMParser).parseFromString(t, "text/html"), s = [].concat(...n.body.querySelectorAll("*"));
                for (const t of s){
                    const i = t.nodeName.toLowerCase();
                    if (!Object.keys(e).includes(i)) {
                        t.remove();
                        continue;
                    }
                    const n = [].concat(...t.attributes), s = [].concat(e["*"] || [], e[i] || []);
                    for (const e of n)Gn(e, s) || t.removeAttribute(e.nodeName);
                }
                return n.body.innerHTML;
            }(t, this._config.allowList, this._config.sanitizeFn) : t;
        }
        _resolvePossibleFunction(t) {
            return _(t, [
                void 0,
                this
            ]);
        }
        _putElementInTemplate(t, e) {
            if (this._config.html) return e.innerHTML = "", void e.append(t);
            e.textContent = t.textContent;
        }
    }
    const is = new Set([
        "sanitize",
        "allowList",
        "sanitizeFn"
    ]), ns = "fade", ss = "show", os = ".tooltip-inner", rs = ".modal", as = "hide.bs.modal", ls = "hover", cs = "focus", hs = "click", ds = {
        AUTO: "auto",
        TOP: "top",
        RIGHT: m() ? "left" : "right",
        BOTTOM: "bottom",
        LEFT: m() ? "right" : "left"
    }, us = {
        allowList: Xn,
        animation: !0,
        boundary: "clippingParents",
        container: !1,
        customClass: "",
        delay: 0,
        fallbackPlacements: [
            "top",
            "right",
            "bottom",
            "left"
        ],
        html: !1,
        offset: [
            0,
            6
        ],
        placement: "top",
        popperConfig: null,
        sanitize: !0,
        sanitizeFn: null,
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        title: "",
        trigger: "hover focus"
    }, fs = {
        allowList: "object",
        animation: "boolean",
        boundary: "(string|element)",
        container: "(string|element|boolean)",
        customClass: "(string|function)",
        delay: "(number|object)",
        fallbackPlacements: "array",
        html: "boolean",
        offset: "(array|string|function)",
        placement: "(string|function)",
        popperConfig: "(null|object|function)",
        sanitize: "boolean",
        sanitizeFn: "(null|function)",
        selector: "(string|boolean)",
        template: "string",
        title: "(string|element|function)",
        trigger: "string"
    };
    class ps extends B {
        constructor(t, e){
            if (void 0 === Ai) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)");
            super(t, e), this._isEnabled = !0, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle();
        }
        static get Default() {
            return us;
        }
        static get DefaultType() {
            return fs;
        }
        static get NAME() {
            return "tooltip";
        }
        enable() {
            this._isEnabled = !0;
        }
        disable() {
            this._isEnabled = !1;
        }
        toggleEnabled() {
            this._isEnabled = !this._isEnabled;
        }
        toggle() {
            this._isEnabled && (this._isShown() ? this._leave() : this._enter());
        }
        dispose() {
            clearTimeout(this._timeout), P.off(this._element.closest(rs), as, this._hideModalHandler), this._element.getAttribute("data-bs-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-bs-original-title")), this._disposePopper(), super.dispose();
        }
        show() {
            if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
            if (!this._isWithContent() || !this._isEnabled) return;
            const t = P.trigger(this._element, this.constructor.eventName("show")), e = (h(this._element) || this._element.ownerDocument.documentElement).contains(this._element);
            if (t.defaultPrevented || !e) return;
            this._disposePopper();
            const i = this._getTipElement();
            this._element.setAttribute("aria-describedby", i.getAttribute("id"));
            const { container: n } = this._config;
            if (this._element.ownerDocument.documentElement.contains(this.tip) || (n.append(i), P.trigger(this._element, this.constructor.eventName("inserted"))), this._popper = this._createPopper(i), i.classList.add(ss), "ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children))P.on(t, "mouseover", d);
            this._queueCallback(()=>{
                P.trigger(this._element, this.constructor.eventName("shown")), !1 === this._isHovered && this._leave(), this._isHovered = !1;
            }, this.tip, this._isAnimated());
        }
        hide() {
            if (this._isShown() && !P.trigger(this._element, this.constructor.eventName("hide")).defaultPrevented) {
                if (this._getTipElement().classList.remove(ss), "ontouchstart" in document.documentElement) for (const t of [].concat(...document.body.children))P.off(t, "mouseover", d);
                this._activeTrigger[hs] = !1, this._activeTrigger[cs] = !1, this._activeTrigger[ls] = !1, this._isHovered = null, this._queueCallback(()=>{
                    this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), P.trigger(this._element, this.constructor.eventName("hidden")));
                }, this.tip, this._isAnimated());
            }
        }
        update() {
            this._popper && this._popper.update();
        }
        _isWithContent() {
            return Boolean(this._getTitle());
        }
        _getTipElement() {
            return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip;
        }
        _createTipElement(t) {
            const e = this._getTemplateFactory(t).toHtml();
            if (!e) return null;
            e.classList.remove(ns, ss), e.classList.add(`bs-${this.constructor.NAME}-auto`);
            const i = ((t)=>{
                do {
                    t += Math.floor(1e6 * Math.random());
                }while (document.getElementById(t))
                return t;
            })(this.constructor.NAME).toString();
            return e.setAttribute("id", i), this._isAnimated() && e.classList.add(ns), e;
        }
        setContent(t) {
            this._newContent = t, this._isShown() && (this._disposePopper(), this.show());
        }
        _getTemplateFactory(t) {
            return this._templateFactory ? this._templateFactory.changeContent(t) : this._templateFactory = new es({
                ...this._config,
                content: t,
                extraClass: this._resolvePossibleFunction(this._config.customClass)
            }), this._templateFactory;
        }
        _getContentForTemplate() {
            return {
                [os]: this._getTitle()
            };
        }
        _getTitle() {
            return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-bs-original-title");
        }
        _initializeOnDelegatedTarget(t) {
            return this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig());
        }
        _isAnimated() {
            return this._config.animation || this.tip && this.tip.classList.contains(ns);
        }
        _isShown() {
            return this.tip && this.tip.classList.contains(ss);
        }
        _createPopper(t) {
            const e = _(this._config.placement, [
                this,
                t,
                this._element
            ]), i = ds[e.toUpperCase()];
            return wi(this._element, t, this._getPopperConfig(i));
        }
        _getOffset() {
            const { offset: t } = this._config;
            return "string" == typeof t ? t.split(",").map((t)=>Number.parseInt(t, 10)) : "function" == typeof t ? (e)=>t(e, this._element) : t;
        }
        _resolvePossibleFunction(t) {
            return _(t, [
                this._element,
                this._element
            ]);
        }
        _getPopperConfig(t) {
            const e = {
                placement: t,
                modifiers: [
                    {
                        name: "flip",
                        options: {
                            fallbackPlacements: this._config.fallbackPlacements
                        }
                    },
                    {
                        name: "offset",
                        options: {
                            offset: this._getOffset()
                        }
                    },
                    {
                        name: "preventOverflow",
                        options: {
                            boundary: this._config.boundary
                        }
                    },
                    {
                        name: "arrow",
                        options: {
                            element: `.${this.constructor.NAME}-arrow`
                        }
                    },
                    {
                        name: "preSetPlacement",
                        enabled: !0,
                        phase: "beforeMain",
                        fn: (t)=>{
                            this._getTipElement().setAttribute("data-popper-placement", t.state.placement);
                        }
                    }
                ]
            };
            return {
                ...e,
                ..._(this._config.popperConfig, [
                    void 0,
                    e
                ])
            };
        }
        _setListeners() {
            const t = this._config.trigger.split(" ");
            for (const e of t)if ("click" === e) P.on(this._element, this.constructor.eventName("click"), this._config.selector, (t)=>{
                const e = this._initializeOnDelegatedTarget(t);
                e._activeTrigger[hs] = !(e._isShown() && e._activeTrigger[hs]), e.toggle();
            });
            else if ("manual" !== e) {
                const t = e === ls ? this.constructor.eventName("mouseenter") : this.constructor.eventName("focusin"), i = e === ls ? this.constructor.eventName("mouseleave") : this.constructor.eventName("focusout");
                P.on(this._element, t, this._config.selector, (t)=>{
                    const e = this._initializeOnDelegatedTarget(t);
                    e._activeTrigger["focusin" === t.type ? cs : ls] = !0, e._enter();
                }), P.on(this._element, i, this._config.selector, (t)=>{
                    const e = this._initializeOnDelegatedTarget(t);
                    e._activeTrigger["focusout" === t.type ? cs : ls] = e._element.contains(t.relatedTarget), e._leave();
                });
            }
            this._hideModalHandler = ()=>{
                this._element && this.hide();
            }, P.on(this._element.closest(rs), as, this._hideModalHandler);
        }
        _fixTitle() {
            const t = this._element.getAttribute("title");
            t && (this._element.getAttribute("aria-label") || this._element.textContent.trim() || this._element.setAttribute("aria-label", t), this._element.setAttribute("data-bs-original-title", t), this._element.removeAttribute("title"));
        }
        _enter() {
            this._isShown() || this._isHovered ? this._isHovered = !0 : (this._isHovered = !0, this._setTimeout(()=>{
                this._isHovered && this.show();
            }, this._config.delay.show));
        }
        _leave() {
            this._isWithActiveTrigger() || (this._isHovered = !1, this._setTimeout(()=>{
                this._isHovered || this.hide();
            }, this._config.delay.hide));
        }
        _setTimeout(t, e) {
            clearTimeout(this._timeout), this._timeout = setTimeout(t, e);
        }
        _isWithActiveTrigger() {
            return Object.values(this._activeTrigger).includes(!0);
        }
        _getConfig(t) {
            const e = H.getDataAttributes(this._element);
            for (const t of Object.keys(e))is.has(t) && delete e[t];
            return t = {
                ...e,
                ..."object" == typeof t && t ? t : {}
            }, t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
        }
        _configAfterMerge(t) {
            return t.container = !1 === t.container ? document.body : a(t.container), "number" == typeof t.delay && (t.delay = {
                show: t.delay,
                hide: t.delay
            }), "number" == typeof t.title && (t.title = t.title.toString()), "number" == typeof t.content && (t.content = t.content.toString()), t;
        }
        _getDelegateConfig() {
            const t = {};
            for (const [e, i] of Object.entries(this._config))this.constructor.Default[e] !== i && (t[e] = i);
            return t.selector = !1, t.trigger = "manual", t;
        }
        _disposePopper() {
            this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null);
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = ps.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]();
                }
            });
        }
    }
    g(ps);
    const ms = ".popover-header", gs = ".popover-body", _s = {
        ...ps.Default,
        content: "",
        offset: [
            0,
            8
        ],
        placement: "right",
        template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
        trigger: "click"
    }, bs = {
        ...ps.DefaultType,
        content: "(null|string|element|function)"
    };
    class vs extends ps {
        static get Default() {
            return _s;
        }
        static get DefaultType() {
            return bs;
        }
        static get NAME() {
            return "popover";
        }
        _isWithContent() {
            return this._getTitle() || this._getContent();
        }
        _getContentForTemplate() {
            return {
                [ms]: this._getTitle(),
                [gs]: this._getContent()
            };
        }
        _getContent() {
            return this._resolvePossibleFunction(this._config.content);
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = vs.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]();
                }
            });
        }
    }
    g(vs);
    const ys = ".bs.scrollspy", ws = `activate${ys}`, As = `click${ys}`, Es = `load${ys}.data-api`, Ts = "active", Cs = "[href]", Os = ".nav-link", xs = `${Os}, .nav-item > ${Os}, .list-group-item`, ks = {
        offset: null,
        rootMargin: "0px 0px -25%",
        smoothScroll: !1,
        target: null,
        threshold: [
            .1,
            .5,
            1
        ]
    }, Ls = {
        offset: "(number|null)",
        rootMargin: "string",
        smoothScroll: "boolean",
        target: "element",
        threshold: "array"
    };
    class Ss extends B {
        constructor(t, e){
            super(t, e), this._targetLinks = new Map, this._observableSections = new Map, this._rootElement = "visible" === getComputedStyle(this._element).overflowY ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = {
                visibleEntryTop: 0,
                parentScrollTop: 0
            }, this.refresh();
        }
        static get Default() {
            return ks;
        }
        static get DefaultType() {
            return Ls;
        }
        static get NAME() {
            return "scrollspy";
        }
        refresh() {
            this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
            for (const t of this._observableSections.values())this._observer.observe(t);
        }
        dispose() {
            this._observer.disconnect(), super.dispose();
        }
        _configAfterMerge(t) {
            return t.target = a(t.target) || document.body, t.rootMargin = t.offset ? `${t.offset}px 0px -30%` : t.rootMargin, "string" == typeof t.threshold && (t.threshold = t.threshold.split(",").map((t)=>Number.parseFloat(t))), t;
        }
        _maybeEnableSmoothScroll() {
            this._config.smoothScroll && (P.off(this._config.target, As), P.on(this._config.target, As, Cs, (t)=>{
                const e = this._observableSections.get(t.target.hash);
                if (e) {
                    t.preventDefault();
                    const i = this._rootElement || window, n = e.offsetTop - this._element.offsetTop;
                    if (i.scrollTo) return void i.scrollTo({
                        top: n,
                        behavior: "smooth"
                    });
                    i.scrollTop = n;
                }
            }));
        }
        _getNewObserver() {
            const t = {
                root: this._rootElement,
                threshold: this._config.threshold,
                rootMargin: this._config.rootMargin
            };
            return new IntersectionObserver((t)=>this._observerCallback(t), t);
        }
        _observerCallback(t) {
            const e = (t)=>this._targetLinks.get(`#${t.target.id}`), i = (t)=>{
                this._previousScrollData.visibleEntryTop = t.target.offsetTop, this._process(e(t));
            }, n = (this._rootElement || document.documentElement).scrollTop, s = n >= this._previousScrollData.parentScrollTop;
            this._previousScrollData.parentScrollTop = n;
            for (const o of t){
                if (!o.isIntersecting) {
                    this._activeTarget = null, this._clearActiveClass(e(o));
                    continue;
                }
                const t = o.target.offsetTop >= this._previousScrollData.visibleEntryTop;
                if (s && t) {
                    if (i(o), !n) return;
                } else s || t || i(o);
            }
        }
        _initializeTargetsAndObservables() {
            this._targetLinks = new Map, this._observableSections = new Map;
            const t = R.find(Cs, this._config.target);
            for (const e of t){
                if (!e.hash || c(e)) continue;
                const t = R.findOne(decodeURI(e.hash), this._element);
                l(t) && (this._targetLinks.set(decodeURI(e.hash), e), this._observableSections.set(e.hash, t));
            }
        }
        _process(t) {
            this._activeTarget !== t && (this._clearActiveClass(this._config.target), this._activeTarget = t, t.classList.add(Ts), this._activateParents(t), P.trigger(this._element, ws, {
                relatedTarget: t
            }));
        }
        _activateParents(t) {
            if (t.classList.contains("dropdown-item")) R.findOne(".dropdown-toggle", t.closest(".dropdown")).classList.add(Ts);
            else for (const e of R.parents(t, ".nav, .list-group"))for (const t of R.prev(e, xs))t.classList.add(Ts);
        }
        _clearActiveClass(t) {
            t.classList.remove(Ts);
            const e = R.find(`${Cs}.${Ts}`, t);
            for (const t of e)t.classList.remove(Ts);
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Ss.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t]();
                }
            });
        }
    }
    P.on(window, Es, ()=>{
        for (const t of R.find('[data-bs-spy="scroll"]'))Ss.getOrCreateInstance(t);
    }), g(Ss);
    const Ds = ".bs.tab", $s = `hide${Ds}`, Is = `hidden${Ds}`, Ns = `show${Ds}`, Ps = `shown${Ds}`, js = `click${Ds}`, Ms = `keydown${Ds}`, Fs = `load${Ds}`, Hs = "ArrowLeft", Ws = "ArrowRight", Bs = "ArrowUp", zs = "ArrowDown", Rs = "Home", qs = "End", Vs = "active", Ks = "fade", Qs = "show", Xs = ".dropdown-toggle", Ys = `:not(${Xs})`, Us = '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', Gs = `.nav-link${Ys}, .list-group-item${Ys}, [role="tab"]${Ys}, ${Us}`, Js = `.${Vs}[data-bs-toggle="tab"], .${Vs}[data-bs-toggle="pill"], .${Vs}[data-bs-toggle="list"]`;
    class Zs extends B {
        constructor(t){
            super(t), this._parent = this._element.closest('.list-group, .nav, [role="tablist"]'), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), P.on(this._element, Ms, (t)=>this._keydown(t)));
        }
        static get NAME() {
            return "tab";
        }
        show() {
            const t = this._element;
            if (this._elemIsActive(t)) return;
            const e = this._getActiveElem(), i = e ? P.trigger(e, $s, {
                relatedTarget: t
            }) : null;
            P.trigger(t, Ns, {
                relatedTarget: e
            }).defaultPrevented || i && i.defaultPrevented || (this._deactivate(e, t), this._activate(t, e));
        }
        _activate(t, e) {
            t && (t.classList.add(Vs), this._activate(R.getElementFromSelector(t)), this._queueCallback(()=>{
                "tab" === t.getAttribute("role") ? (t.removeAttribute("tabindex"), t.setAttribute("aria-selected", !0), this._toggleDropDown(t, !0), P.trigger(t, Ps, {
                    relatedTarget: e
                })) : t.classList.add(Qs);
            }, t, t.classList.contains(Ks)));
        }
        _deactivate(t, e) {
            t && (t.classList.remove(Vs), t.blur(), this._deactivate(R.getElementFromSelector(t)), this._queueCallback(()=>{
                "tab" === t.getAttribute("role") ? (t.setAttribute("aria-selected", !1), t.setAttribute("tabindex", "-1"), this._toggleDropDown(t, !1), P.trigger(t, Is, {
                    relatedTarget: e
                })) : t.classList.remove(Qs);
            }, t, t.classList.contains(Ks)));
        }
        _keydown(t) {
            if (![
                Hs,
                Ws,
                Bs,
                zs,
                Rs,
                qs
            ].includes(t.key)) return;
            t.stopPropagation(), t.preventDefault();
            const e = this._getChildren().filter((t)=>!c(t));
            let i;
            if ([
                Rs,
                qs
            ].includes(t.key)) i = e[t.key === Rs ? 0 : e.length - 1];
            else {
                const n = [
                    Ws,
                    zs
                ].includes(t.key);
                i = v(e, t.target, n, !0);
            }
            i && (i.focus({
                preventScroll: !0
            }), Zs.getOrCreateInstance(i).show());
        }
        _getChildren() {
            return R.find(Gs, this._parent);
        }
        _getActiveElem() {
            return this._getChildren().find((t)=>this._elemIsActive(t)) || null;
        }
        _setInitialAttributes(t, e) {
            this._setAttributeIfNotExists(t, "role", "tablist");
            for (const t of e)this._setInitialAttributesOnChild(t);
        }
        _setInitialAttributesOnChild(t) {
            t = this._getInnerElement(t);
            const e = this._elemIsActive(t), i = this._getOuterElement(t);
            t.setAttribute("aria-selected", e), i !== t && this._setAttributeIfNotExists(i, "role", "presentation"), e || t.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t, "role", "tab"), this._setInitialAttributesOnTargetPanel(t);
        }
        _setInitialAttributesOnTargetPanel(t) {
            const e = R.getElementFromSelector(t);
            e && (this._setAttributeIfNotExists(e, "role", "tabpanel"), t.id && this._setAttributeIfNotExists(e, "aria-labelledby", `${t.id}`));
        }
        _toggleDropDown(t, e) {
            const i = this._getOuterElement(t);
            if (!i.classList.contains("dropdown")) return;
            const n = (t, n)=>{
                const s = R.findOne(t, i);
                s && s.classList.toggle(n, e);
            };
            n(Xs, Vs), n(".dropdown-menu", Qs), i.setAttribute("aria-expanded", e);
        }
        _setAttributeIfNotExists(t, e, i) {
            t.hasAttribute(e) || t.setAttribute(e, i);
        }
        _elemIsActive(t) {
            return t.classList.contains(Vs);
        }
        _getInnerElement(t) {
            return t.matches(Gs) ? t : R.findOne(Gs, t);
        }
        _getOuterElement(t) {
            return t.closest(".nav-item, .list-group-item") || t;
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Zs.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t]();
                }
            });
        }
    }
    P.on(document, js, Us, function(t) {
        [
            "A",
            "AREA"
        ].includes(this.tagName) && t.preventDefault(), c(this) || Zs.getOrCreateInstance(this).show();
    }), P.on(window, Fs, ()=>{
        for (const t of R.find(Js))Zs.getOrCreateInstance(t);
    }), g(Zs);
    const to = ".bs.toast", eo = `mouseover${to}`, io = `mouseout${to}`, no = `focusin${to}`, so = `focusout${to}`, oo = `hide${to}`, ro = `hidden${to}`, ao = `show${to}`, lo = `shown${to}`, co = "hide", ho = "show", uo = "showing", fo = {
        animation: "boolean",
        autohide: "boolean",
        delay: "number"
    }, po = {
        animation: !0,
        autohide: !0,
        delay: 5e3
    };
    class mo extends B {
        constructor(t, e){
            super(t, e), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners();
        }
        static get Default() {
            return po;
        }
        static get DefaultType() {
            return fo;
        }
        static get NAME() {
            return "toast";
        }
        show() {
            P.trigger(this._element, ao).defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(co), u(this._element), this._element.classList.add(ho, uo), this._queueCallback(()=>{
                this._element.classList.remove(uo), P.trigger(this._element, lo), this._maybeScheduleHide();
            }, this._element, this._config.animation));
        }
        hide() {
            this.isShown() && (P.trigger(this._element, oo).defaultPrevented || (this._element.classList.add(uo), this._queueCallback(()=>{
                this._element.classList.add(co), this._element.classList.remove(uo, ho), P.trigger(this._element, ro);
            }, this._element, this._config.animation)));
        }
        dispose() {
            this._clearTimeout(), this.isShown() && this._element.classList.remove(ho), super.dispose();
        }
        isShown() {
            return this._element.classList.contains(ho);
        }
        _maybeScheduleHide() {
            this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(()=>{
                this.hide();
            }, this._config.delay)));
        }
        _onInteraction(t, e) {
            switch(t.type){
                case "mouseover":
                case "mouseout":
                    this._hasMouseInteraction = e;
                    break;
                case "focusin":
                case "focusout":
                    this._hasKeyboardInteraction = e;
            }
            if (e) return void this._clearTimeout();
            const i = t.relatedTarget;
            this._element === i || this._element.contains(i) || this._maybeScheduleHide();
        }
        _setListeners() {
            P.on(this._element, eo, (t)=>this._onInteraction(t, !0)), P.on(this._element, io, (t)=>this._onInteraction(t, !1)), P.on(this._element, no, (t)=>this._onInteraction(t, !0)), P.on(this._element, so, (t)=>this._onInteraction(t, !1));
        }
        _clearTimeout() {
            clearTimeout(this._timeout), this._timeout = null;
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = mo.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t](this);
                }
            });
        }
    }
    return q(mo), g(mo), {
        Alert: X,
        Button: U,
        Carousel: St,
        Collapse: qt,
        Dropdown: Qi,
        Modal: Ln,
        Offcanvas: Qn,
        Popover: vs,
        ScrollSpy: Ss,
        Tab: Zs,
        Toast: mo,
        Tooltip: ps
    };
}); //# sourceMappingURL=bootstrap.bundle.min.js.map
}),
]);

//# sourceMappingURL=a8942_699fb257._.js.map