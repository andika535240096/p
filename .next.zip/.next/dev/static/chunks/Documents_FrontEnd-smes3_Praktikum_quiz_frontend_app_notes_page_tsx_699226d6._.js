(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a8942_d042a61d._.js",
  "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_app_notes_page_tsx_3860fa77._.js"
],
    source: "dynamic"
});
