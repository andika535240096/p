(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a8942_next_dist_compiled_9e1aa802._.js",
  "static/chunks/a8942_next_dist_shared_lib_ca5ede18._.js",
  "static/chunks/a8942_next_dist_client_b0e52915._.js",
  "static/chunks/a8942_next_dist_5de6d23f._.js",
  "static/chunks/a8942_next_app_cedce651.js",
  "static/chunks/[next]_entry_page-loader_ts_0d07f343._.js",
  "static/chunks/a8942_react-dom_4ce5ac5e._.js",
  "static/chunks/a8942_000d830d._.js",
  "static/chunks/[root-of-the-server]__0e56b255._.js"
],
    source: "entry"
});
