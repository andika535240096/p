(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a8942_dd97c28f._.js",
  "static/chunks/80b94_FrontEnd-smes3_Praktikum_quiz_frontend_app_notes_[id]_page_tsx_8fd4d70b._.js"
],
    source: "dynamic"
});
