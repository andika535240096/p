(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript) <export default as Card>");
'use client';
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
        className: "mt-5",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
            className: "justify-content-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                md: 8,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                    bg: "secondary",
                    text: "white",
                    className: "shadow-lg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Header, {
                            as: "h2",
                            className: "text-center",
                            children: "Informasi Project"
                        }, void 0, false, {
                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                            lineNumber: 10,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Title, {
                                    as: "h4",
                                    children: "Data Mahasiswa"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                    lineNumber: 12,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "list-group list-group-flush mb-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "list-group-item bg-secondary text-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: "Nama:"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                                    lineNumber: 15,
                                                    columnNumber: 19
                                                }, this),
                                                " Andika Halim"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                            lineNumber: 14,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "list-group-item bg-secondary text-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: "NIM:"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                                    lineNumber: 18,
                                                    columnNumber: 19
                                                }, this),
                                                " 535240096"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                            lineNumber: 17,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                    lineNumber: 13,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Aplikasi Catatan Sederhana (Simple Note App) Untuk Kamu!"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                        lineNumber: 22,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                    lineNumber: 21,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Kamu bisa nulis apa aja tentang diri kamu atau pekerjaan kamu ataupun menjadi catatan kalau kamu sedang di sekolah atau kampus, gausah takut ini gabakal di upload kemana mana hanya di laptop kamu saja jadi tenang aja ya, Semangat!!!"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                                    lineNumber: 24,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                            lineNumber: 11,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                    lineNumber: 9,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
                lineNumber: 8,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/page.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const Row = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'div', ...props }, ref)=>{
    const decoratedBsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'row');
    const breakpoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapBreakpoints"])();
    const minBreakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapMinBreakpoint"])();
    const sizePrefix = `${decoratedBsPrefix}-cols`;
    const classes = [];
    breakpoints.forEach((brkPoint)=>{
        const propValue = props[brkPoint];
        delete props[brkPoint];
        let cols;
        if (propValue != null && typeof propValue === 'object') {
            ({ cols } = propValue);
        } else {
            cols = propValue;
        }
        const infix = brkPoint !== minBreakpoint ? `-${brkPoint}` : '';
        if (cols != null) classes.push(`${sizePrefix}${infix}-${cols}`);
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, decoratedBsPrefix, ...classes)
    });
});
Row.displayName = 'Row';
const __TURBOPACK__default__export__ = Row;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Row",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useCol",
    ()=>useCol
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function useCol({ as, bsPrefix, className, ...props }) {
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'col');
    const breakpoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapBreakpoints"])();
    const minBreakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapMinBreakpoint"])();
    const spans = [];
    const classes = [];
    breakpoints.forEach((brkPoint)=>{
        const propValue = props[brkPoint];
        delete props[brkPoint];
        let span;
        let offset;
        let order;
        if (typeof propValue === 'object' && propValue != null) {
            ({ span, offset, order } = propValue);
        } else {
            span = propValue;
        }
        const infix = brkPoint !== minBreakpoint ? `-${brkPoint}` : '';
        if (span) spans.push(span === true ? `${bsPrefix}${infix}` : `${bsPrefix}${infix}-${span}`);
        if (order != null) classes.push(`order${infix}-${order}`);
        if (offset != null) classes.push(`offset${infix}-${offset}`);
    });
    return [
        {
            ...props,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, ...spans, ...classes)
        },
        {
            as,
            bsPrefix,
            spans
        }
    ];
}
const Col = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](// Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
(props, ref)=>{
    const [{ className, ...colProps }, { as: Component = 'div', bsPrefix, spans }] = useCol(props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...colProps,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, !spans.length && bsPrefix)
    });
});
Col.displayName = 'Col';
const __TURBOPACK__default__export__ = Col;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Col",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardBody.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardBody = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'div', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-body');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardBody.displayName = 'CardBody';
const __TURBOPACK__default__export__ = CardBody;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardFooter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'div', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-footer');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardFooter.displayName = 'CardFooter';
const __TURBOPACK__default__export__ = CardFooter;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeaderContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardHeaderContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'div', ...props }, ref)=>{
    const prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-header');
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CardHeader.useMemo[contextValue]": ()=>({
                cardHeaderBsPrefix: prefix
            })
    }["CardHeader.useMemo[contextValue]"], [
        prefix
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeaderContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: contextValue,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
            ref: ref,
            ...props,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, prefix)
        })
    });
});
CardHeader.displayName = 'CardHeader';
const __TURBOPACK__default__export__ = CardHeader;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardImg.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardImg = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](// Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
({ bsPrefix, className, variant, as: Component = 'img', ...props }, ref)=>{
    const prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-img');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(variant ? `${prefix}-${variant}` : prefix, className),
        ...props
    });
});
CardImg.displayName = 'CardImg';
const __TURBOPACK__default__export__ = CardImg;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardImgOverlay.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardImgOverlay = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'div', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-img-overlay');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardImgOverlay.displayName = 'CardImgOverlay';
const __TURBOPACK__default__export__ = CardImgOverlay;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardLink.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardLink = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'a', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-link');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardLink.displayName = 'CardLink';
const __TURBOPACK__default__export__ = CardLink;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardSubtitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/divWithClassName.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const DivStyledAsH6 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h6');
const CardSubtitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = DivStyledAsH6, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-subtitle');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardSubtitle.displayName = 'CardSubtitle';
const __TURBOPACK__default__export__ = CardSubtitle;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardText.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const CardText = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = 'p', ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-text');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardText.displayName = 'CardText';
const __TURBOPACK__default__export__ = CardText;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardTitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/divWithClassName.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const DivStyledAsH5 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$divWithClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h5');
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ className, bsPrefix, as: Component = DivStyledAsH5, ...props }, ref)=>{
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card-title');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, bsPrefix),
        ...props
    });
});
CardTitle.displayName = 'CardTitle';
const __TURBOPACK__default__export__ = CardTitle;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardBody.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardFooter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardImg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardImg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardImgOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardImgOverlay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardLink.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardSubtitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardSubtitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/CardTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, bg, text, border, body = false, children, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'div', ...props }, ref)=>{
    const prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'card');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, prefix, bg && `bg-${bg}`, text && `text-${text}`, border && `border-${border}`),
        children: body ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: children
        }) : children
    });
});
Card.displayName = 'Card';
const __TURBOPACK__default__export__ = Object.assign(Card, {
    Img: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardImg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Title: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Subtitle: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardSubtitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Body: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Link: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Text: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Header: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    Footer: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    ImgOverlay: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$CardImgOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript) <export default as Card>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=Documents_FrontEnd-smes3_Praktikum_quiz_frontend_3abe2fa2._.js.map