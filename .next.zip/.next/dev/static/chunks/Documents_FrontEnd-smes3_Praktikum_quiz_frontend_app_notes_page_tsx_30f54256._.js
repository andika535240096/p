(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a8942_8ebc0f79._.js",
  "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_393058af._.js"
],
    source: "dynamic"
});
