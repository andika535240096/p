(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
'use client';
;
;
function DeleteConfirmation({ show, onHide, onConfirm, noteTitle }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        show: show,
        onHide: onHide,
        centered: true,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Header, {
                closeButton: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Title, {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                            className: "bi bi-exclamation-triangle-fill text-danger me-2"
                        }, void 0, false, {
                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        "Konfirmasi Hapus"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Apakah Anda yakin ingin menghapus catatan ini?"
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-muted",
                        children: [
                            "Judul: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: noteTitle
                            }, void 0, false, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                                lineNumber: 25,
                                columnNumber: 18
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Tindakan ini tidak dapat dibatalkan."
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "secondary",
                        onClick: onHide,
                        children: "Batal"
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        variant: "danger",
                        onClick: onConfirm,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "bi bi-trash me-2"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this),
                            "Ya, Hapus"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = DeleteConfirmation;
const __TURBOPACK__default__export__ = DeleteConfirmation;
var _c;
__turbopack_context__.k.register(_c, "DeleteConfirmation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Form.js [app-client] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ListGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListGroup$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ListGroup.js [app-client] (ecmascript) <export default as ListGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$components$2f$DeleteConfirmation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/components/DeleteConfirmation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const NOTES_STORAGE_KEY = 'my-nextjs-notes';
const MAX_CONTENT_LENGTH = 500;
function NotesPage() {
    _s();
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [newNoteTitle, setNewNoteTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newNoteContent, setNewNoteContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [errorAlert, setErrorAlert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showDeleteModal, setShowDeleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [noteToDelete, setNoteToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesPage.useEffect": ()=>{
            setIsClient(true);
            try {
                const items = localStorage.getItem(NOTES_STORAGE_KEY);
                if (items) {
                    setNotes(JSON.parse(items));
                }
            } catch (error) {
                console.error("Gagal memuat catatan dari localStorage:", error);
            }
        }
    }["NotesPage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesPage.useEffect": ()=>{
            if (isClient) {
                try {
                    localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes));
                } catch (error) {
                    console.error("Gagal menyimpan catatan ke localStorage:", error);
                }
            }
        }
    }["NotesPage.useEffect"], [
        notes,
        isClient
    ]);
    const handleAddNote = (e)=>{
        e.preventDefault();
        setErrorAlert(null);
        if (!newNoteTitle.trim() || !newNoteContent.trim()) {
            setErrorAlert("Judul dan Konten tidak boleh kosong!");
            return;
        }
        const newNote = {
            id: crypto.randomUUID(),
            title: newNoteTitle,
            content: newNoteContent,
            createdAt: new Date().toISOString()
        };
        setNotes([
            newNote,
            ...notes
        ]);
        setNewNoteTitle('');
        setNewNoteContent('');
    };
    const openDeleteModal = (note)=>{
        setNoteToDelete(note);
        setShowDeleteModal(true);
    };
    const confirmDeleteNote = ()=>{
        if (!noteToDelete) return;
        setNotes(notes.filter((note)=>note.id !== noteToDelete.id));
        // Reset state modal
        setShowDeleteModal(false);
        setNoteToDelete(null);
    };
    // (3) Fungsi untuk MENUTUP modal
    const closeDeleteModal = ()=>{
        setShowDeleteModal(false);
        setNoteToDelete(null);
    };
    if (!isClient) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
            className: "text-center mt-5",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "spinner-border text-primary",
                role: "status",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "visually-hidden",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                    lineNumber: 96,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                lineNumber: 95,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
            lineNumber: 94,
            columnNumber: 7
        }, this);
    }
    const charsRemaining = MAX_CONTENT_LENGTH - newNoteContent.length;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
        className: "mt-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                        md: 4,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                            className: "shadow-sm mb-4 position-sticky",
                            style: {
                                top: '5rem'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Header, {
                                    as: "h4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "bi bi-pencil-square me-2"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 110,
                                            columnNumber: 34
                                        }, this),
                                        "Buat Catatan Baru"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                    lineNumber: 110,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                                    children: [
                                        errorAlert && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                            variant: "danger",
                                            onClose: ()=>setErrorAlert(null),
                                            dismissible: true,
                                            children: errorAlert
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 113,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
                                            onSubmit: handleAddNote,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                                    className: "mb-3",
                                                    controlId: "noteTitle",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                            children: "Judul Catatan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 120,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                                                            type: "text",
                                                            placeholder: "Masukkan judul...",
                                                            value: newNoteTitle,
                                                            onChange: (e)=>setNewNoteTitle(e.target.value),
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 121,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Group, {
                                                    className: "mb-3",
                                                    controlId: "noteContent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Label, {
                                                            children: "Isi Catatan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 131,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Control, {
                                                            as: "textarea",
                                                            rows: 4,
                                                            placeholder: "Masukkan isi catatan...",
                                                            value: newNoteContent,
                                                            onChange: (e)=>setNewNoteContent(e.target.value),
                                                            maxLength: MAX_CONTENT_LENGTH,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 132,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Text, {
                                                            className: charsRemaining < 0 ? 'text-danger' : 'text-muted',
                                                            children: [
                                                                "Sisa karakter: ",
                                                                charsRemaining
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                    lineNumber: 130,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                    variant: "primary",
                                                    type: "submit",
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                            className: "bi bi-plus-circle me-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 147,
                                                            columnNumber: 19
                                                        }, this),
                                                        "Tambah Catatan"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 118,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                    lineNumber: 111,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                        md: 8,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "bi bi-collection me-2"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                        lineNumber: 156,
                                        columnNumber: 32
                                    }, this),
                                    "Daftar Catatan"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                lineNumber: 156,
                                columnNumber: 11
                            }, this),
                            notes.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                                className: "text-center p-5 bg-light border-dashed",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"].Body, {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "bi bi-journal-plus",
                                            style: {
                                                fontSize: '3rem',
                                                color: '#6c757d'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 160,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                            className: "mt-3",
                                            children: "Belum ada catatan"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 161,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-muted",
                                            children: "Mulai buat catatan baru di formulir sebelah kiri."
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                            lineNumber: 162,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                    lineNumber: 159,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                lineNumber: 158,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ListGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListGroup$3e$__["ListGroup"], {
                                children: notes.map((note)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ListGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListGroup$3e$__["ListGroup"].Item, {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: `/notes/${note.id}`,
                                                className: "card-link-trigger w-100",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "fw-bold",
                                                            children: note.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 176,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                            className: "text-muted",
                                                            children: [
                                                                "Dibuat pada: ",
                                                                new Date(note.createdAt).toLocaleString()
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                            lineNumber: 177,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                    lineNumber: 175,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                lineNumber: 174,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                variant: "outline-danger",
                                                size: "sm",
                                                onClick: ()=>openDeleteModal(note),
                                                title: "Hapus catatan",
                                                className: "ms-3",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                    className: "bi bi-trash"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                    lineNumber: 189,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                                lineNumber: 182,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, note.id, true, {
                                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                        lineNumber: 170,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                                lineNumber: 168,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                        lineNumber: 155,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$components$2f$DeleteConfirmation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                show: showDeleteModal,
                onHide: closeDeleteModal,
                onConfirm: confirmDeleteNote,
                noteTitle: noteToDelete?.title || ""
            }, void 0, false, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
                lineNumber: 198,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/notes/page.tsx",
        lineNumber: 106,
        columnNumber: 5
    }, this);
}
_s(NotesPage, "13lwlJJrSIKE36YqFbYHcJN1ZIQ=");
_c = NotesPage;
var _c;
__turbopack_context__.k.register(_c, "NotesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Documents_FrontEnd-smes3_Praktikum_quiz_frontend_393058af._.js.map