(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f7c06c35._.css",
  "static/chunks/a8942_699fb257._.js",
  "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_components_c5584216._.js"
],
    source: "dynamic"
});
