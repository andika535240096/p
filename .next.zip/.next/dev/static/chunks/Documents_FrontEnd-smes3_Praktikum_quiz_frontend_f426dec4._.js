(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotFound
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>");
'use client';
;
;
function NotFound() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
        className: "mt-5 text-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
            className: "justify-content-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                md: 8,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "display-1 fw-bold",
                        children: "404"
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                        lineNumber: 9,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "display-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "bi bi-compass-fill text-warning me-3"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                                lineNumber: 11,
                                columnNumber: 13
                            }, this),
                            "Halaman Tersesat"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                        lineNumber: 10,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "lead mt-4",
                        children: "Maaf, halaman yang Anda cari sepertinya tidak ada di alam semesta ini. Mungkin ia sedang berlibur."
                    }, void 0, false, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                        lineNumber: 14,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "primary",
                                size: "lg",
                                as: "a",
                                href: "/",
                                className: "me-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "bi bi-house me-2"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                                        lineNumber: 26,
                                        columnNumber: 15
                                    }, this),
                                    "Bawa Saya Pulang"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                                lineNumber: 19,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "outline-secondary",
                                size: "lg",
                                onClick: ()=>window.history.back(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "bi bi-arrow-left me-2"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                                        lineNumber: 34,
                                        columnNumber: 15
                                    }, this),
                                    "Kembali"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                                lineNumber: 29,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                        lineNumber: 18,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
                lineNumber: 8,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/app/not-found.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = NotFound;
var _c;
__turbopack_context__.k.register(_c, "NotFound");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
const Row = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ bsPrefix, className, // Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
as: Component = 'div', ...props }, ref)=>{
    const decoratedBsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'row');
    const breakpoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapBreakpoints"])();
    const minBreakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapMinBreakpoint"])();
    const sizePrefix = `${decoratedBsPrefix}-cols`;
    const classes = [];
    breakpoints.forEach((brkPoint)=>{
        const propValue = props[brkPoint];
        delete props[brkPoint];
        let cols;
        if (propValue != null && typeof propValue === 'object') {
            ({ cols } = propValue);
        } else {
            cols = propValue;
        }
        const infix = brkPoint !== minBreakpoint ? `-${brkPoint}` : '';
        if (cols != null) classes.push(`${sizePrefix}${infix}-${cols}`);
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, decoratedBsPrefix, ...classes)
    });
});
Row.displayName = 'Row';
const __TURBOPACK__default__export__ = Row;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript) <export default as Row>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Row",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Row.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useCol",
    ()=>useCol
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function useCol({ as, bsPrefix, className, ...props }) {
    bsPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'col');
    const breakpoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapBreakpoints"])();
    const minBreakpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapMinBreakpoint"])();
    const spans = [];
    const classes = [];
    breakpoints.forEach((brkPoint)=>{
        const propValue = props[brkPoint];
        delete props[brkPoint];
        let span;
        let offset;
        let order;
        if (typeof propValue === 'object' && propValue != null) {
            ({ span, offset, order } = propValue);
        } else {
            span = propValue;
        }
        const infix = brkPoint !== minBreakpoint ? `-${brkPoint}` : '';
        if (span) spans.push(span === true ? `${bsPrefix}${infix}` : `${bsPrefix}${infix}-${span}`);
        if (order != null) classes.push(`order${infix}-${order}`);
        if (offset != null) classes.push(`offset${infix}-${offset}`);
    });
    return [
        {
            ...props,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, ...spans, ...classes)
        },
        {
            as,
            bsPrefix,
            spans
        }
    ];
}
const Col = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](// Need to define the default "as" during prop destructuring to be compatible with styled-components github.com/react-bootstrap/react-bootstrap/issues/3595
(props, ref)=>{
    const [{ className, ...colProps }, { as: Component = 'div', bsPrefix, spans }] = useCol(props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...colProps,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, !spans.length && bsPrefix)
    });
});
Col.displayName = 'Col';
const __TURBOPACK__default__export__ = Col;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript) <export default as Col>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Col",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Col$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Col.js [app-client] (ecmascript)");
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/classnames/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/@restart/ui/esm/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/ThemeProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](({ as, bsPrefix, variant = 'primary', size, active = false, disabled = false, className, ...props }, ref)=>{
    const prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBootstrapPrefix"])(bsPrefix, 'btn');
    const [buttonProps, { tagName }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f40$restart$2f$ui$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButtonProps"])({
        tagName: as,
        disabled,
        ...props
    });
    const Component = tagName;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Component, {
        ...buttonProps,
        ...props,
        ref: ref,
        disabled: disabled,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$classnames$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, prefix, active && 'active', variant && `${prefix}-${variant}`, size && `${prefix}-${size}`, props.href && disabled && 'disabled')
    });
});
Button.displayName = 'Button';
const __TURBOPACK__default__export__ = Button;
}),
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript) <export default as Button>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FrontEnd$2d$smes3$2f$Praktikum$2f$quiz_frontend$2f$node_modules$2f$react$2d$bootstrap$2f$esm$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/react-bootstrap/esm/Button.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=Documents_FrontEnd-smes3_Praktikum_quiz_frontend_f426dec4._.js.map