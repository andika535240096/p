(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a8942_3400e7f1._.js",
  "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_app_page_tsx_109e2125._.js"
],
    source: "dynamic"
});
