(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3ca6ba1c._.js",
  "static/chunks/a8942_next_dist_compiled_react-dom_cee85cb4._.js",
  "static/chunks/a8942_next_dist_compiled_react-server-dom-turbopack_3826bc9e._.js",
  "static/chunks/a8942_next_dist_compiled_next-devtools_index_8346b19e.js",
  "static/chunks/a8942_next_dist_compiled_0dfbd0ab._.js",
  "static/chunks/a8942_next_dist_client_da5579fb._.js",
  "static/chunks/a8942_next_dist_9a088bf4._.js",
  "static/chunks/a8942_@swc_helpers_cjs_b3bbbe34._.js"
],
    source: "entry"
});
