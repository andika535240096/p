(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_a49c2709._.js"
],
    source: "dynamic"
});
