var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/a8942_e400f778._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/a8942_154fcfdc._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/a8942_next_f9f761e6._.js")
R.m("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
