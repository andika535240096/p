globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a8942_next_dist_compiled_9e1aa802._.js",
      "static/chunks/a8942_next_dist_shared_lib_ca5ede18._.js",
      "static/chunks/a8942_next_dist_client_b0e52915._.js",
      "static/chunks/a8942_next_dist_5de6d23f._.js",
      "static/chunks/a8942_next_app_cedce651.js",
      "static/chunks/[next]_entry_page-loader_ts_0d07f343._.js",
      "static/chunks/a8942_react-dom_4ce5ac5e._.js",
      "static/chunks/a8942_000d830d._.js",
      "static/chunks/[root-of-the-server]__0e56b255._.js",
      "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_pages__app_2da965e7._.js",
      "static/chunks/turbopack-Documents_FrontEnd-smes3_Praktikum_quiz_frontend_pages__app_04e8d756._.js"
    ],
    "/_error": [
      "static/chunks/a8942_next_dist_compiled_9e1aa802._.js",
      "static/chunks/a8942_next_dist_shared_lib_93da45ad._.js",
      "static/chunks/a8942_next_dist_client_b0e52915._.js",
      "static/chunks/a8942_next_dist_d595fdff._.js",
      "static/chunks/a8942_next_error_cd7b6354.js",
      "static/chunks/[next]_entry_page-loader_ts_fd4ab157._.js",
      "static/chunks/a8942_react-dom_4ce5ac5e._.js",
      "static/chunks/a8942_000d830d._.js",
      "static/chunks/[root-of-the-server]__bc6a035d._.js",
      "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_pages__error_2da965e7._.js",
      "static/chunks/turbopack-Documents_FrontEnd-smes3_Praktikum_quiz_frontend_pages__error_c80cf84e._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a8942_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3ca6ba1c._.js",
    "static/chunks/a8942_next_dist_compiled_react-dom_cee85cb4._.js",
    "static/chunks/a8942_next_dist_compiled_react-server-dom-turbopack_3826bc9e._.js",
    "static/chunks/a8942_next_dist_compiled_next-devtools_index_8346b19e.js",
    "static/chunks/a8942_next_dist_compiled_0dfbd0ab._.js",
    "static/chunks/a8942_next_dist_client_da5579fb._.js",
    "static/chunks/a8942_next_dist_9a088bf4._.js",
    "static/chunks/a8942_@swc_helpers_cjs_b3bbbe34._.js",
    "static/chunks/Documents_FrontEnd-smes3_Praktikum_quiz_frontend_a0ff3932._.js",
    "static/chunks/turbopack-Documents_FrontEnd-smes3_Praktikum_quiz_frontend_eaa7ee69._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];