module.exports = [
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/.next-internal/server/app/notes/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=dde9a_quiz_frontend__next-internal_server_app_notes_%5Bid%5D_page_actions_b9fd0c26.js.map