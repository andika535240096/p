module.exports = [
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/.next-internal/server/app/notes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=24d41_Praktikum_quiz_frontend__next-internal_server_app_notes_page_actions_15bec806.js.map