module.exports = [
"[project]/Documents/FrontEnd-smes3/Praktikum/quiz_frontend/.next-internal/server/app/explore/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=24d41_Praktikum_quiz_frontend__next-internal_server_app_explore_page_actions_90405122.js.map